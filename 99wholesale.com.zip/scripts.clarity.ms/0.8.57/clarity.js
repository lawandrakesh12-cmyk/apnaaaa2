/* clarity-js v0.8.57: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t = Object.freeze({
            __proto__: null,
            get add() {
                return nr
            },
            get get() {
                return hr
            },
            get getId() {
                return er
            },
            get getNode() {
                return dr
            },
            get getValue() {
                return fr
            },
            get has() {
                return vr
            },
            get hashText() {
                return lr
            },
            get iframe() {
                return ir
            },
            get iframeContent() {
                return or
            },
            get lookup() {
                return pr
            },
            get parse() {
                return tr
            },
            get removeIFrame() {
                return ur
            },
            get sameorigin() {
                return rr
            },
            get start() {
                return Za
            },
            get stop() {
                return Qa
            },
            get update() {
                return ar
            },
            get updates() {
                return gr
            }
        }),
        e = Object.freeze({
            __proto__: null,
            get queue() {
                return li
            },
            get start() {
                return si
            },
            get stop() {
                return di
            },
            get track() {
                return ni
            }
        }),
        n = Object.freeze({
            __proto__: null,
            get data() {
                return Hi
            },
            get start() {
                return qi
            },
            get stop() {
                return Fi
            },
            get upgrade() {
                return Ui
            }
        }),
        a = Object.freeze({
            __proto__: null,
            get check() {
                return Ki
            },
            get compute() {
                return Gi
            },
            get data() {
                return Wi
            },
            get start() {
                return Bi
            },
            get stop() {
                return Zi
            },
            get trigger() {
                return Ji
            }
        }),
        r = Object.freeze({
            __proto__: null,
            get compute() {
                return ro
            },
            get data() {
                return Qi
            },
            get log() {
                return ao
            },
            get reset() {
                return io
            },
            get start() {
                return eo
            },
            get stop() {
                return no
            },
            get updates() {
                return $i
            }
        }),
        i = Object.freeze({
            __proto__: null,
            get compute() {
                return go
            },
            get config() {
                return fo
            },
            get consent() {
                return ho
            },
            get data() {
                return oo
            },
            get start() {
                return co
            },
            get stop() {
                return so
            },
            get trackConsentv2() {
                return vo
            }
        }),
        o = Object.freeze({
            __proto__: null,
            get callback() {
                return Po
            },
            get callbacks() {
                return yo
            },
            get clear() {
                return Do
            },
            get consent() {
                return No
            },
            get consentv2() {
                return xo
            },
            get data() {
                return mo
            },
            get electron() {
                return bo
            },
            get id() {
                return Mo
            },
            get metadata() {
                return _o
            },
            get save() {
                return Ro
            },
            get shortid() {
                return jo
            },
            get start() {
                return Oo
            },
            get stop() {
                return To
            }
        }),
        u = Object.freeze({
            __proto__: null,
            get data() {
                return zo
            },
            get envelope() {
                return qo
            },
            get start() {
                return Wo
            },
            get stop() {
                return Ho
            }
        }),
        c = {
            projectId: null,
            delay: 1e3,
            lean: !1,
            lite: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0,
            modules: [],
            diagnostics: !1
        };

    function s(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }
    var l = 0;

    function d() {
        return performance.now() + performance.timeOrigin
    }

    function f(t) {
        void 0 === t && (t = null);
        var e = 0 === l ? d() : l,
            n = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
            a = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
        return Math.max(Math.round(n + a - e), 0)
    }
    var h = "0.8.57";

    function p(t, e) {
        void 0 === e && (e = null);
        for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
            if (a = (a << 5) + a ^ t.charCodeAt(i), i + 1 < t.length) r = (r << 5) + r ^ t.charCodeAt(i + 1)
        }
        return n = Math.abs(a + 11579 * r), (e ? n % Math.pow(2, e) : n).toString(36)
    }
    var v = /\S/gi,
        g = 255,
        m = !0,
        y = null,
        b = null,
        w = null;

    function S(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e = -1,
                                    n = 0,
                                    a = !1,
                                    r = !1,
                                    i = !1,
                                    o = null;
                                M();
                                for (var u = 0; u < t.length; u++) {
                                    var c = t.charCodeAt(u);
                                    if (a = a || c >= 48 && c <= 57, r = r || 64 === c, i = 9 === c || 10 === c || 13 === c || 32 === c, 0 === u || u === t.length - 1 || i) {
                                        if (a || r) {
                                            null === o && (o = t.split(""));
                                            var s = t.substring(e + 1, i ? u : u + 1);
                                            s = m && null !== w ? s.match(w) ? s : T(s, "▪", "▫") : E(s), o.splice(e + 1 - n, s.length, s), n += s.length - 1
                                        }
                                        i && (a = !1, r = !1, e = u)
                                    }
                                }
                                return o ? o.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return _(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? O(t) : E(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                        case "href":
                        case "xlink:href":
                            return 3 === n ? (null == t ? void 0 : t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return _(t);
                        case "placeholder":
                            return E(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? O(t) : E(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return T(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function k(t, e, n) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        var a = t;
        if (e) a = "".concat("https://").concat("Electron");
        else {
            var r = c.drop;
            if (r && r.length > 0 && t && t.indexOf("?") > 0) {
                var i = t.split("?"),
                    o = i[0],
                    u = i[1];
                a = o + "?" + u.split("&").map((function(t) {
                    return r.some((function(e) {
                        return 0 === t.indexOf("".concat(e, "="))
                    })) ? "".concat(t.split("=")[0], "=").concat("*na*") : t
                })).join("&")
            }
        }
        return n && (a = a.substring(0, g)), a
    }

    function O(t) {
        var e = t.trim();
        if (e.length > 0) {
            var n = e[0],
                a = t.indexOf(n),
                r = t.substr(0, a),
                i = t.substr(a + e.length);
            return "".concat(r).concat(e.length.toString(36)).concat(i)
        }
        return t
    }

    function E(t) {
        return t.replace(v, "•")
    }

    function T(t, e, n) {
        return M(), t ? t.replace(b, e).replace(y, n) : t
    }

    function _(t) {
        for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++) n += a > 0 && a % 5 == 0 ? " " : "•";
        return n
    }

    function M() {
        if (m && null === y) try {
            y = new RegExp("\\p{N}", "gu"), b = new RegExp("\\p{L}", "gu"), w = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            m = !1
        }
    }
    var N = null,
        x = null,
        I = !1;

    function C() {
        I && (N = {
            time: f(),
            event: 4,
            data: {
                visible: x.visible,
                docWidth: x.docWidth,
                docHeight: x.docHeight,
                screenWidth: x.screenWidth,
                screenHeight: x.screenHeight,
                scrollX: x.scrollX,
                scrollY: x.scrollY,
                pointerX: x.pointerX,
                pointerY: x.pointerY,
                activityTime: x.activityTime,
                scrollTime: x.scrollTime,
                pointerTime: x.pointerTime,
                moveX: x.moveX,
                moveY: x.moveY,
                moveTime: x.moveTime,
                downX: x.downX,
                downY: x.downY,
                downTime: x.downTime,
                upX: x.upX,
                upY: x.upY,
                upTime: x.upTime,
                pointerPrevX: x.pointerPrevX,
                pointerPrevY: x.pointerPrevY,
                pointerPrevTime: x.pointerPrevTime,
                modules: x.modules
            }
        }), x = x || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0,
            modules: null
        }
    }

    function D(t, e, n, a) {
        switch (t) {
            case 8:
                x.docWidth = e, x.docHeight = n;
                break;
            case 11:
                x.screenWidth = e, x.screenHeight = n;
                break;
            case 10:
                x.scrollX = e, x.scrollY = n, x.scrollTime = a;
                break;
            case 12:
                x.moveX = e, x.moveY = n, x.moveTime = a, x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a;
                break;
            case 13:
                x.downX = e, x.downY = n, x.downTime = a, x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a;
                break;
            case 14:
                x.upX = e, x.upY = n, x.upTime = a, x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a;
                break;
            default:
                x.pointerPrevX = x.pointerX, x.pointerPrevY = x.pointerY, x.pointerPrevTime = x.pointerTime, x.pointerX = e, x.pointerY = n, x.pointerTime = a
        }
        I = !0
    }

    function P(t) {
        x.activityTime = t
    }

    function R(t, e) {
        x.visible = e, x.visible || P(t), I = !0
    }

    function Y(t) {
        x.modules = Array.from(t), I = !0
    }

    function j() {
        I && Vi(4)
    }
    var A = Object.freeze({
            __proto__: null,
            activity: P,
            compute: j,
            dynamic: Y,
            reset: C,
            start: function() {
                I = !1, C()
            },
            get state() {
                return N
            },
            stop: function() {
                C()
            },
            track: D,
            visibility: R
        }),
        X = null;

    function L(t, e) {
        lu() && t && "string" == typeof t && t.length < 255 && (X = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Vi(24))
    }
    var z, W = null,
        H = null;

    function q(t) {
        t in W || (W[t] = 0), t in H || (H[t] = 0), W[t]++, H[t]++
    }

    function U(t, e) {
        null !== e && (t in W || (W[t] = 0), t in H || (H[t] = 0), W[t] += e, H[t] += e)
    }

    function F(t, e) {
        null !== e && !1 === isNaN(e) && (t in W || (W[t] = 0), (e > W[t] || 0 === W[t]) && (H[t] = e, W[t] = e))
    }

    function V(t, e, n) {
        return window.setTimeout(Vo(t), e, n)
    }

    function B(t) {
        return window.clearTimeout(t)
    }
    var K = 0,
        J = 0,
        G = null;

    function Z() {
        G && B(G), G = V(Q, J), K = f()
    }

    function Q() {
        var t = f();
        z = {
            gap: t - K
        }, Vi(25), z.gap < 3e5 ? G = V(Q, J) : uu && (L("clarity", "suspend"), Yu(), ["mousemove", "touchstart"].forEach((function(t) {
            return Ko(document, t, du)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return Ko(window, t, du)
        })))
    }
    var $ = Object.freeze({
            __proto__: null,
            get data() {
                return z
            },
            reset: Z,
            start: function() {
                J = 6e4, K = 0
            },
            stop: function() {
                B(G), K = 0, J = 0
            }
        }),
        tt = null;

    function et(t, e) {
        if (t in tt) {
            var n = tt[t],
                a = n[n.length - 1];
            e - a[0] > 100 ? tt[t].push([e, 0]) : a[1] = e - a[0]
        } else tt[t] = [
            [e, 0]
        ]
    }

    function nt() {
        Vi(36)
    }

    function at() {
        tt = {}
    }
    var rt = Object.freeze({
        __proto__: null,
        compute: nt,
        get data() {
            return tt
        },
        reset: at,
        start: function() {
            tt = {}
        },
        stop: function() {
            tt = {}
        },
        track: et
    });

    function it(t, e, n, a) {
        return new(n || (n = Promise))((function(r, i) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    i(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    i(t)
                }
            }

            function c(t) {
                var e;
                t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function ot(t, e) {
        var n, a, r, i, o = {
            label: 0,
            sent: function() {
                if (1 & r[0]) throw r[1];
                return r[1]
            },
            trys: [],
            ops: []
        };
        return i = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this
        }), i;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; i && (i = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (r = 2 & u[0] ? a.return : u[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, u[1])).done) return r;
                        switch (a = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                            case 0:
                            case 1:
                                r = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(r = o.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < r[1]) {
                                    o.label = r[1], r = u;
                                    break
                                }
                                if (r && o.label < r[2]) {
                                    o.label = r[2], o.ops.push(u);
                                    break
                                }
                                r[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = r = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }
    var ut = "CompressionStream" in window;

    function ct(t) {
        return it(this, void 0, void 0, (function() {
            var e, n;
            return ot(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), ut ? (e = new ReadableStream({
                            start: function(e) {
                                return it(this, void 0, void 0, (function() {
                                    return ot(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, st(e)]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function st(t) {
        return it(this, void 0, void 0, (function() {
            var e, n, a, r, i;
            return ot(this, (function(o) {
                switch (o.label) {
                    case 0:
                        e = t.getReader(), n = [], a = !1, r = [], o.label = 1;
                    case 1:
                        return a ? [3, 3] : [4, e.read()];
                    case 2:
                        return i = o.sent(), a = i.done, r = i.value, a ? [2, n] : (n.push.apply(n, r), [3, 1]);
                    case 3:
                        return [2, n]
                }
            }))
        }))
    }
    var lt = null;

    function dt(t, e) {
        ht(t, "string" == typeof e ? [e] : e)
    }

    function ft(t, e, n, a) {
        return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), it(this, void 0, void 0, (function() {
            var r, i;
            return ot(this, (function(o) {
                switch (o.label) {
                    case 0:
                        return i = {}, [4, gt(t)];
                    case 1:
                        return i.userId = o.sent(), i.userHint = a || ((u = t) && u.length >= 5 ? "".concat(u.substring(0, 2)).concat(T(u.substring(2), "*", "*")) : T(u, "*", "*")), ht("userId", [(r = i).userId]), ht("userHint", [r.userHint]), ht("userType", [mt(t)]), e && (ht("sessionId", [e]), r.sessionId = e), n && (ht("pageId", [n]), r.pageId = n), [2, r]
                }
                var u
            }))
        }))
    }

    function ht(t, e) {
        if (lu() && t && e && "string" == typeof t && t.length < 255) {
            for (var n = (t in lt ? lt[t] : []), a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            lt[t] = n
        }
    }

    function pt() {
        Vi(34)
    }

    function vt() {
        lt = {}
    }

    function gt(t) {
        return it(this, void 0, void 0, (function() {
            var e;
            return ot(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function mt(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var yt = Object.freeze({
            __proto__: null,
            compute: pt,
            get data() {
                return lt
            },
            identify: ft,
            reset: vt,
            set: dt,
            start: function() {
                vt()
            },
            stop: function() {
                vt()
            }
        }),
        bt = {},
        wt = new Set,
        St = {},
        kt = {},
        Ot = {},
        Et = {};

    function Tt(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                n = e[0].split(/\|(.*)/),
                a = parseInt(n[0]),
                r = n.length > 1 ? n[1] : "",
                i = e.length > 1 ? JSON.parse(e[1]) : {};
            for (var o in St[a] = {}, kt[a] = {}, Ot[a] = {}, Et[a] = r, i) {
                var u = parseInt(o),
                    c = i[o],
                    s = 2;
                switch (c.startsWith("~") ? s = 0 : c.startsWith("!") && (s = 4), s) {
                    case 0:
                        var l = c.slice(1);
                        St[a][u] = It(l);
                        break;
                    case 2:
                        kt[a][u] = c;
                        break;
                    case 4:
                        var d = c.slice(1);
                        Ot[a][u] = d
                }
            }
        } catch (t) {
            ki(8, 1, t ? t.name : null)
        }
    }

    function _t(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function Mt() {
        try {
            for (var t in St) {
                var e = parseInt(t);
                if ("" == Et[e] || document.querySelector(Et[e])) {
                    var n = St[e];
                    for (var a in n) {
                        var r = parseInt(a),
                            i = (m = Ct(_t(n[r]))) ? JSON.stringify(m).slice(0, 1e4) : m;
                        i && xt(e, r, i)
                    }
                    var o = kt[e];
                    for (var u in o) {
                        var c = !1,
                            s = parseInt(u),
                            l = o[s];
                        l.startsWith("@") && (c = !0, l = l.slice(1));
                        var d = document.querySelectorAll(l);
                        if (d) {
                            var f = Array.from(d).map((function(t) {
                                return t.textContent
                            })).join("<SEP>");
                            xt(e, s, (c ? p(f).trim() : f).slice(0, 1e4))
                        }
                    }
                    var h = Ot[e];
                    for (var v in h) {
                        var g = parseInt(v);
                        xt(e, g, lr(h[g]).trim().slice(0, 1e4))
                    }
                }
            }
            wt.size > 0 && Vi(40)
        } catch (t) {
            ki(5, 1, t ? t.name : null)
        }
        var m
    }

    function Nt() {
        wt.clear()
    }

    function xt(t, e, n) {
        var a, r = !1;
        t in bt || (bt[t] = {}, r = !0), a = Ot[t], 0 == Object.keys(a).length || e in bt[t] && bt[t][e] == n || (r = !0), bt[t][e] = n, r && wt.add(t)
    }

    function It(t) {
        for (var e = [], n = t.split("."); n.length > 0;) {
            var a = n.shift(),
                r = a.indexOf("["),
                i = a.indexOf("{"),
                o = a.indexOf("}");
            e.push({
                name: r > 0 ? a.slice(0, r) : i > 0 ? a.slice(0, i) : a,
                type: r > 0 ? 1 : i > 0 ? 2 : 3,
                condition: i > 0 ? a.slice(i + 1, o) : null
            })
        }
        return e
    }

    function Ct(t, e) {
        if (void 0 === e && (e = window), 0 == t.length) return e;
        var n, a = t.shift();
        if (e && e[a.name]) {
            var r = e[a.name];
            if (1 !== a.type && Dt(r, a.condition)) n = Ct(t, r);
            else if (Array.isArray(r)) {
                for (var i = [], o = 0, u = r; o < u.length; o++) {
                    var c = u[o];
                    if (Dt(c, a.condition)) {
                        var s = Ct(t, c);
                        s && i.push(s)
                    }
                }
                n = i
            }
            return n
        }
        return null
    }

    function Dt(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }
    var Pt = Object.freeze({
        __proto__: null,
        clone: _t,
        compute: Mt,
        data: bt,
        keys: wt,
        reset: Nt,
        start: function() {
            Nt()
        },
        stop: function() {
            Nt()
        },
        trigger: Tt,
        update: xt
    });

    function Rt(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function Yt(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }
    var jt = null,
        At = "^";

    function Xt(t, e) {
        var n;
        if (void 0 === e && (e = !1), Rt(document, "cookie")) {
            var a = document.cookie.split(";");
            if (a)
                for (var r = 0; r < a.length; r++) {
                    var i = a[r].split("=");
                    if (i.length > 1 && i[0] && i[0].trim() === t) {
                        for (var o = Yt(i[1]), u = o[0], c = o[1]; u;) u = (n = Yt(c))[0], c = n[1];
                        return e ? c.endsWith("".concat("~", "1")) ? c.substring(0, c.length - 2) : null : c
                    }
                }
        }
        return null
    }

    function Lt(t, e, n) {
        if ((c.track || "" == e) && (navigator && navigator.cookieEnabled || Rt(document, "cookie"))) {
            var a = function(t) {
                    return encodeURIComponent(t)
                }(e),
                r = new Date;
            r.setDate(r.getDate() + n);
            var i = r ? "expires=" + r.toUTCString() : "",
                o = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
            try {
                if (null === jt) {
                    for (var u = location.hostname ? location.hostname.split(".") : [], s = u.length - 1; s >= 0; s--)
                        if (jt = ".".concat(u[s]).concat(jt || ""), s < u.length - 1 && (document.cookie = "".concat(o).concat(";").concat("domain=").concat(jt), Xt(t) === e)) return;
                    jt = ""
                }
            } catch (t) {
                jt = ""
            }
            document.cookie = jt ? "".concat(o).concat(";").concat("domain=").concat(jt) : o
        }
    }
    var zt = null;

    function Wt(t) {
        try {
            if (!zt) return;
            var e = function(t) {
                try {
                    return JSON.parse(t)
                } catch (t) {
                    return []
                }
            }(t);
            e.forEach((function(t) {
                zt(t)
            }))
        } catch (t) {}
    }
    var Ht = [A, r, yt, a, rt, Object.freeze({
        __proto__: null,
        COOKIE_SEP: At,
        getCookie: Xt,
        setCookie: Lt,
        start: function() {
            jt = null
        },
        stop: function() {
            jt = null
        }
    }), i, o, u, e, $, n, Pt];

    function qt() {
        W = {}, H = {}, q(5), Ht.forEach((function(t) {
            return Vo(t.start)()
        }))
    }

    function Ut() {
        Ht.slice().reverse().forEach((function(t) {
            return Vo(t.stop)()
        })), W = {}, H = {}
    }

    function Ft() {
        pt(), j(), ro(), Vi(0), nt(), Gi(), Mt(), go()
    }
    var Vt, Bt = [];

    function Kt(t, e, n) {
        c.fraud && null !== t && n && n.length >= 5 && (Vt = {
            id: t,
            target: e,
            checksum: p(n, 28)
        }, Bt.indexOf(Vt.checksum) < 0 && (Bt.push(Vt.checksum), bi(41)))
    }
    var Jt = ["address", "password", "contact"],
        Gt = ["radio", "checkbox", "range", "button", "reset", "submit"],
        Zt = ["password", "secret", "pass", "social", "ssn", "code", "hidden"],
        Qt = ["INPUT", "SELECT", "TEXTAREA"],
        $t = [];

    function te(t) {
        var e = Pr(t);
        if (e) {
            var n = e.value,
                a = n && n.length >= 5 && c.fraud && -1 === Zt.indexOf(e.type) ? p(n, 28) : "";
            $t.push({
                time: f(t),
                event: 42,
                data: {
                    target: Pr(t),
                    type: e.type,
                    value: n,
                    checksum: a
                }
            }), Ii(Yr.bind(this, 42))
        }
    }

    function ee() {
        $t = []
    }

    function ne(t) {
        var e = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                var n = t.offsetParent,
                    a = null === n ? ir(t.ownerDocument) : null;
                e.x += t.offsetLeft, e.y += t.offsetTop, t = a || n
            } while (t);
        return e
    }
    var ae = ["input", "textarea", "radio", "button", "canvas", "select"],
        re = /VM\d/,
        ie = [];

    function oe(t, e, n) {
        var a = ir(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = ne(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        var s = Pr(n),
            l = function(t) {
                for (; t && t !== document;) {
                    if (t.nodeType === Node.ELEMENT_NODE) {
                        var e = t;
                        if ("A" === e.tagName) return e
                    }
                    t = t.parentNode
                }
                return null
            }(s),
            d = se(s);
        0 === n.detail && d && (i = Math.round(d.x + d.w / 2), o = Math.round(d.y + d.h / 2));
        var h = function(t, e, n, a) {
                if (!a) return {
                    eX: 0,
                    eY: 0
                };
                var r = a,
                    i = t,
                    o = Math.max(Math.floor((e - r.x) / r.w * 32767), 0),
                    u = Math.max(Math.floor((n - r.y) / r.h * 32767), 0),
                    c = 0;
                for (;
                    (o > 32767 || u > 32767) && i.parentElement && c < 10;) c++, (r = se(i = i.parentElement)) && (o = Math.max(Math.floor((e - r.x) / r.w * 32767), 0), u = Math.max(Math.floor((n - r.y) / r.h * 32767), 0));
                return {
                    eX: o,
                    eY: u
                }
            }(s, i, o, d),
            p = h.eX,
            v = h.eY;
        if (null !== i && null !== o) {
            var g = function(t) {
                var e = null,
                    n = !1;
                if (t) {
                    var a = t.textContent || String(t.value || "") || t.alt;
                    if (a) {
                        var r = a.replace(/\s+/g, " ").trim();
                        n = (e = r.substring(0, 25)).length === r.length
                    }
                }
                return {
                    text: e,
                    isFullText: n ? 1 : 0
                }
            }(s);
            ie.push({
                time: f(n),
                event: t,
                data: {
                    target: s,
                    x: i,
                    y: o,
                    eX: p,
                    eY: v,
                    button: n.button,
                    reaction: ue(s),
                    context: le(l),
                    text: g.text,
                    link: l ? l.href : null,
                    hash: null,
                    trust: n.isTrusted ? 1 : 0,
                    isFullText: g.isFullText,
                    w: d ? d.w : 0,
                    h: d ? d.h : 0,
                    tag: ce(s, "tagName").substring(0, 10),
                    class: ce(s, "className").substring(0, 50),
                    id: ce(s, "id").substring(0, 25),
                    source: c.diagnostics && !n.isTrusted ? de() : 0
                }
            }), Ii(Yr.bind(this, t))
        }
    }

    function ue(t) {
        var e = ce(t, "tagName");
        return ae.indexOf(e) >= 0 ? 0 : 1
    }

    function ce(t, e) {
        if (t.nodeType === Node.ELEMENT_NODE) {
            var n = null == t ? void 0 : t[e];
            return "string" == typeof n ? null == n ? void 0 : n.toLowerCase() : ""
        }
        return ""
    }

    function se(t) {
        var e = null,
            n = t.ownerDocument || document,
            a = n.documentElement,
            r = n.defaultView || window;
        if ("function" == typeof t.getBoundingClientRect) {
            var i = t.getBoundingClientRect();
            if (i && i.width > 0 && i.height > 0) {
                var o = "pageXOffset" in r ? r.pageXOffset : a.scrollLeft,
                    u = "pageYOffset" in r ? r.pageYOffset : a.scrollTop;
                e = {
                    x: Math.floor(i.left + o),
                    y: Math.floor(i.top + u),
                    w: Math.floor(i.width),
                    h: Math.floor(i.height)
                };
                var c = ir(n);
                if (c) {
                    var s = ne(c);
                    e.x += Math.round(s.x), e.y += Math.round(s.y)
                }
            }
        }
        return e
    }

    function le(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function de() {
        de.dn = 1;
        try {
            for (var t = (new Error).stack || "", e = location.origin, n = 4, a = 0, r = t.split("\n"); a < r.length; a++) {
                var i = r[a];
                i.indexOf("://") >= 0 ? n = i.indexOf("extension") < 0 && i.indexOf(e) >= 0 ? 1 : 2 : (i.indexOf("eval") >= 0 || i.indexOf("Function") >= 0 || i.indexOf("<a") >= 0 || re.test(i)) && (n = 3)
            }
            return n
        } catch (t) {
            return 4
        }
    }

    function fe() {
        ie = []
    }
    var he = [];

    function pe(t, e) {
        he.push({
            time: f(e),
            event: 38,
            data: {
                target: Pr(e),
                action: t
            }
        }), Ii(Yr.bind(this, 38))
    }

    function ve() {
        he = []
    }
    var ge = null,
        me = [];

    function ye(t) {
        var e = Pr(t),
            n = hr(e);
        if (e && e.type && n) {
            var a = e.value,
                r = e.type;
            switch (e.type) {
                case "radio":
                case "checkbox":
                    a = e.checked ? "true" : "false"
            }
            var i = {
                target: e,
                value: a,
                type: r,
                trust: t.isTrusted ? 1 : 0
            };
            me.length > 0 && me[me.length - 1].data.target === i.target && me.pop(), me.push({
                time: f(t),
                event: 27,
                data: i
            }), B(ge), ge = V(be, 1e3, 27)
        }
    }

    function be(t) {
        Ii(Yr.bind(this, t))
    }

    function we() {
        me = []
    }
    var Se, ke = [],
        Oe = null,
        Ee = !1,
        Te = 0,
        _e = new Set;

    function Me(t, e, n) {
        var a = ir(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = ne(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        null !== i && null !== o && xe({
            time: f(n),
            event: t,
            data: {
                target: Pr(n),
                x: i,
                y: o
            }
        })
    }

    function Ne(t, e, n) {
        var a = ir(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = n.changedTouches,
            o = f(n);
        if (i)
            for (var u = 0; u < i.length; u++) {
                var c = i[u],
                    s = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
                    l = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
                s = s && a ? s + Math.round(a.offsetLeft) : s, l = l && a ? l + Math.round(a.offsetTop) : l;
                var d = "identifier" in c ? c.identifier : void 0;
                switch (t) {
                    case 17:
                        0 === _e.size && (Ee = !0, Te = d), _e.add(d);
                        break;
                    case 18:
                    case 20:
                        _e.delete(d)
                }
                var h = Ee && Te === d;
                null !== s && null !== l && xe({
                    time: o,
                    event: t,
                    data: {
                        target: Pr(n),
                        x: s,
                        y: l,
                        id: d,
                        isPrimary: h
                    }
                }), 20 !== t && 18 !== t || Te === d && (Ee = !1)
            }
    }

    function xe(t) {
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                var e = ke.length,
                    n = e > 1 ? ke[e - 2] : null;
                n && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        r = Math.sqrt(n * n + a * a),
                        i = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && r < 20 && i < 25 && u
                }(n, t) && ke.pop(), ke.push(t), B(Oe), Oe = V(Ie, 500, t.event);
                break;
            default:
                ke.push(t), Ie(t.event)
        }
    }

    function Ie(t) {
        Ii(Yr.bind(this, t))
    }

    function Ce() {
        ke = []
    }

    function De(t, e) {
        var n = 0,
            a = null,
            r = null;

        function i() {
            for (var i = this, o = [], u = 0; u < arguments.length; u++) o[u] = arguments[u];
            var c = performance.now(),
                s = c - n;
            if (0 !== n && s < e) {
                if (r = o, a) return;
                a = setTimeout((function() {
                    n = performance.now(), t.apply(i, r), r = null, a = null
                }), e - s)
            } else n = c, t.apply(this, o)
        }
        return i.cleanup = function() {
            a && (clearTimeout(a), a = null, r = null)
        }, i
    }
    var Pe = null,
        Re = !1,
        Ye = De(je, 500);

    function je() {
        var t = document.documentElement;
        Se = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, Re ? (B(Pe), Pe = V(Ae, 500, 11)) : (Yr(11), Re = !0)
    }

    function Ae(t) {
        Ii(Yr.bind(this, t))
    }

    function Xe() {
        Se = null, B(Pe), Ye.cleanup()
    }
    var Le = [],
        ze = null,
        We = null,
        He = null;

    function qe(t) {
        void 0 === t && (t = null);
        var e = window,
            n = document.documentElement,
            a = t ? Pr(t) : n;
        if (a) {
            if (a && a.nodeType === Node.DOCUMENT_NODE) {
                var r = ir(a);
                e = r ? r.contentWindow : e, a = n = a.documentElement
            }
            var i = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft),
                o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop),
                u = window.innerWidth,
                c = window.innerHeight,
                s = u / 3,
                l = u > c ? .15 * c : .2 * c,
                d = c - l,
                h = Fe(s, l),
                p = Fe(s, d),
                v = t && t.isTrusted ? 1 : 0,
                g = {
                    time: f(t),
                    event: 10,
                    data: {
                        target: a,
                        x: i,
                        y: o,
                        top: h,
                        bottom: p,
                        trust: v
                    }
                };
            if (null === t && 0 === i && 0 === o || null === i || null === o) return ze = h, void(We = p);
            var m = Le.length,
                y = m > 1 ? Le[m - 2] : null;
            y && function(t, e) {
                var n = t.data.x - e.data.x,
                    a = t.data.y - e.data.y;
                return n * n + a * a < 400 && e.time - t.time < 50
            }(y, g) && Le.pop(), Le.push(g), B(He), He = V(Ve, 500, 10)
        }
    }
    var Ue = De(qe, 25);

    function Fe(t, e) {
        var n, a, r;
        return "caretPositionFromPoint" in document ? r = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (r = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), r || (r = document.elementFromPoint(t, e)), r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode), r
    }

    function Ve(t) {
        Ii(Yr.bind(this, t))
    }

    function Be() {
        var t, e;
        if (ze) {
            var n = Rr(ze, null);
            ao(31, null === (t = null == n ? void 0 : n.hash) || void 0 === t ? void 0 : t.join("."))
        }
        if (We) {
            var a = Rr(We, null);
            ao(32, null === (e = null == a ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
        }
    }
    var Ke = null,
        Je = null,
        Ge = null;

    function Ze(t) {
        var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        if (null !== e && !(null === e.anchorNode && null === e.focusNode || e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)) {
            var n = Ke.start ? Ke.start : null;
            null !== Je && null !== Ke.start && n !== e.anchorNode && (B(Ge), Qe(21)), Ke = {
                start: e.anchorNode,
                startOffset: e.anchorOffset,
                end: e.focusNode,
                endOffset: e.focusOffset
            }, Je = e, B(Ge), Ge = V(Qe, 500, 21)
        }
    }

    function Qe(t) {
        Ii(Yr.bind(this, t))
    }

    function $e() {
        Je = null, Ke = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }
    var tn, en, nn, an = [];

    function rn(t) {
        an.push({
            time: f(t),
            event: 39,
            data: {
                target: Pr(t)
            }
        }), Ii(Yr.bind(this, 39))
    }

    function on() {
        an = []
    }

    function un(t) {
        tn = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, Yr(26, f(t)), Yu()
    }

    function cn() {
        tn = null
    }

    function sn(t) {
        if (void 0 === t && (t = null), "visibilityState" in document) {
            var e = "visible" === document.visibilityState ? 1 : 0;
            en = {
                visible: e
            }, Yr(28, f(t))
        }
    }

    function ln() {
        en = null
    }

    function dn() {
        nn = null
    }

    function fn(t) {
        nn = {
            focused: t
        }, Yr(50)
    }
    var hn = !1;

    function pn(t) {
        t && t.persisted && (Ru(), ki(11, 0))
    }

    function vn(t) {
        ! function(t) {
            var e = ir(t);
            Ko(e ? e.contentWindow : t === document ? window : t, "scroll", Ue, !0)
        }(t), t.nodeType === Node.DOCUMENT_NODE && (function(t) {
            Ko(t, "click", oe.bind(this, 9, t), !0), Ko(t, "contextmenu", oe.bind(this, 48, t), !0)
        }(t), function(t) {
            Ko(t, "cut", pe.bind(this, 0), !0), Ko(t, "copy", pe.bind(this, 1), !0), Ko(t, "paste", pe.bind(this, 2), !0)
        }(t), function(t) {
            Ko(t, "mousedown", Me.bind(this, 13, t), !0), Ko(t, "mouseup", Me.bind(this, 14, t), !0), Ko(t, "mousemove", Me.bind(this, 12, t), !0), Ko(t, "wheel", Me.bind(this, 15, t), !0), Ko(t, "dblclick", Me.bind(this, 16, t), !0), Ko(t, "touchstart", Ne.bind(this, 17, t), !0), Ko(t, "touchend", Ne.bind(this, 18, t), !0), Ko(t, "touchmove", Ne.bind(this, 19, t), !0), Ko(t, "touchcancel", Ne.bind(this, 20, t), !0)
        }(t), function(t) {
            Ko(t, "input", ye, !0)
        }(t), function(t) {
            Ko(t, "selectstart", Ze.bind(this, t), !0), Ko(t, "selectionchange", Ze.bind(this, t), !0)
        }(t), function(t) {
            Ko(t, "change", te, !0)
        }(t), function(t) {
            Ko(t, "submit", rn, !0)
        }(t))
    }
    var gn = Object.freeze({
        __proto__: null,
        observe: vn,
        start: function() {
            jr = [], Xr(), fe(), ve(), Ce(), we(), Re = !1, Ko(window, "resize", Ye), je(), Ko(document, "visibilitychange", sn), sn(), Ko(window, "focus", (function() {
                    return fn(1)
                })), Ko(window, "blur", (function() {
                    return fn(0)
                })),
                function() {
                    if (!hn) try {
                        window[s("addEventListener")]("pageshow", Vo(pn), {
                            capture: !1,
                            passive: !0
                        }), hn = !0
                    } catch (t) {}
                }(), Le = [], qe(), $e(), ee(), on(), Ko(window, "pagehide", un)
        },
        stop: function() {
            jr = [], Xr(), fe(), ve(), B(Oe), ke.length > 0 && Ie(ke[ke.length - 1].event), B(ge), we(), Xe(), ln(), dn(), B(He), Ue.cleanup(), Le = [], ze = null, We = null, $e(), B(Ge), ee(), on(), cn()
        }
    });

    function mn(t) {
        for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
            if ("string" == typeof t[i]) {
                var o = t[i],
                    u = n[o] || -1;
                u >= 0 ? r ? r.push(u) : (r = [u], e.push(r), a++) : (r = null, e.push(o), n[o] = a++)
            } else r = null, e.push(t[i]), a++;
        return e
    }
    var yn = [],
        bn = [],
        wn = "claritySheetId",
        Sn = {},
        kn = {},
        On = [],
        En = [];

    function Tn(t) {
        c.lean && c.lite || null == t || (t.clarityOverrides = t.clarityOverrides || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (void 0 === t.clarityOverrides.replace && (t.clarityOverrides.replace = t.CSSStyleSheet.prototype.replace, t.CSSStyleSheet.prototype.replace = function() {
            return lu() && En.indexOf(this[wn]) > -1 && xn(f(), this[wn], 1, arguments[0]), t.clarityOverrides.replace.apply(this, arguments)
        }), void 0 === t.clarityOverrides.replaceSync && (t.clarityOverrides.replaceSync = t.CSSStyleSheet.prototype.replaceSync, t.CSSStyleSheet.prototype.replaceSync = function() {
            return lu() && En.indexOf(this[wn]) > -1 && xn(f(), this[wn], 2, arguments[0]), t.clarityOverrides.replaceSync.apply(this, arguments)
        })))
    }

    function _n() {
        Tn(window)
    }

    function Mn(t, e) {
        if ((!c.lean || !c.lite) && (-1 === On.indexOf(t) && (On.push(t), t.defaultView && Tn(t.defaultView)), e = e || f(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
                var i = r[a];
                i[wn] && -1 !== En.indexOf(i[wn]) || (i[wn] = jo(), En.push(i[wn]), xn(e, i[wn], 0), xn(e, i[wn], 2, Ia(i))), n.push(i[wn])
            }
            var o = er(t, !0);
            Sn[o] || (Sn[o] = []),
                function(t, e) {
                    if (t.length !== e.length) return !1;
                    return t.every((function(t, n) {
                        return t === e[n]
                    }))
                }(n, Sn[o]) || (! function(t, e, n, a) {
                    bn.push({
                        time: t,
                        event: 45,
                        data: {
                            id: e,
                            operation: n,
                            newIds: a
                        }
                    }), Jn(45)
                }(e, t == document ? -1 : er(t), 3, n), Sn[o] = n, kn[o] = e)
        }
    }

    function Nn() {
        bn = [], yn = []
    }

    function xn(t, e, n, a) {
        yn.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), Jn(46)
    }
    var In = [],
        Cn = null,
        Dn = null,
        Pn = null,
        Rn = null,
        Yn = null,
        jn = null,
        An = "clarityAnimationId",
        Xn = "clarityOperationCount",
        Ln = 20;

    function zn() {
        In = []
    }

    function Wn(t, e, n, a, r, i, o) {
        In.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: r,
                targetId: i,
                timeline: o
            }
        }), Jn(44)
    }

    function Hn(t, e) {
        null === t && (t = Animation.prototype[e], Animation.prototype[e] = function() {
            return qn(this, e), t.apply(this, arguments)
        })
    }

    function qn(t, e) {
        if (lu()) {
            var n = t.effect,
                a = (null == n ? void 0 : n.target) ? er(n.target) : null;
            if (null !== a && n.getKeyframes && n.getTiming) {
                if (!t[An]) {
                    t[An] = jo(), t[Xn] = 0;
                    var r = n.getKeyframes(),
                        i = n.getTiming();
                    Wn(f(), t[An], 0, JSON.stringify(r), JSON.stringify(i), a)
                }
                if (t[Xn]++ < Ln) {
                    var o = null;
                    switch (e) {
                        case "play":
                            o = 1;
                            break;
                        case "pause":
                            o = 2;
                            break;
                        case "cancel":
                            o = 3;
                            break;
                        case "finish":
                            o = 4;
                            break;
                        case "commitStyles":
                            o = 5
                    }
                    o && Wn(f(), t[An], o)
                }
            }
        }
    }
    var Un, Fn = [],
        Vn = new Set;

    function Bn(t) {
        Vn.has(t) || (Vn.add(t), Fn.push(t), Ii(Jn.bind(this, 51)))
    }

    function Kn() {
        Fn.length = 0
    }

    function Jn(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), it(this, void 0, void 0, (function() {
            var a, r, i, o, u, s, l, d, h, p, v, g, m, y, b, w, k, O, E, T, _, M, N, x, I, C, R, Y, j, A, X, L;
            return ot(this, (function(z) {
                switch (z.label) {
                    case 0:
                        switch (a = n || f(), r = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5];
                            case 51:
                                return [3, 12]
                        }
                        return [3, 13];
                    case 1:
                        return i = Un, r.push(i.width), r.push(i.height), D(t, i.width, i.height), li(r), [3, 13];
                    case 2:
                        for (o = 0, u = wr; o < u.length; o++) s = u[o], (r = [s.time, 7]).push(s.data.id), r.push(s.data.interaction), r.push(s.data.visibility), r.push(s.data.name), li(r, !1);
                        return Dr(), [3, 13];
                    case 3:
                        for (l = 0, d = bn; l < d.length; l++) m = d[l], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.newIds), li(r);
                        for (h = 0, p = yn; h < p.length; h++) m = p[h], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.cssRules), li(r, !1);
                        return Nn(), [3, 13];
                    case 4:
                        for (v = 0, g = In; v < g.length; v++) m = g[v], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.keyFrames), r.push(m.data.timing), r.push(m.data.timeline), r.push(m.data.targetId), li(r);
                        return zn(), [3, 13];
                    case 5:
                        if (2 === Di(e)) return [3, 13];
                        if (!((y = gr()).length > 0)) return [3, 11];
                        b = 0, w = y, z.label = 6;
                    case 6:
                        return b < w.length ? (k = w[b], 0 !== (O = Di(e)) ? [3, 8] : [4, Yi(e)]) : [3, 10];
                    case 7:
                        O = z.sent(), z.label = 8;
                    case 8:
                        if (2 === O) return [3, 10];
                        for (E = k.data, T = k.metadata.active, _ = k.metadata.suspend, M = k.metadata.privacy, N = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(k), x = 0, I = T ? ["tag", "attributes", "value"] : ["tag"]; x < I.length; x++)
                            if (E[C = I[x]] || "" === E[C]) switch (C) {
                                case "tag":
                                    R = Gn(k), Y = N ? -1 : 1, r.push(k.id * Y), k.parent && T && (r.push(k.parent), k.previous && r.push(k.previous)), r.push(_ ? "*M" : E[C]), R && 2 === R.length && r.push("".concat("#").concat(Zn(R[0]), ".").concat(Zn(R[1])));
                                    break;
                                case "attributes":
                                    for (j in E[C]) void 0 !== E[C][j] && r.push(Qn(j, E[C][j], M, E.tag));
                                    break;
                                case "value":
                                    Kt(k.metadata.fraud, k.id, E[C]), r.push(S(E[C], E.tag, M, N))
                            }
                        z.label = 9;
                    case 9:
                        return b++, [3, 6];
                    case 10:
                        6 === t && P(a), li(mn(r), !c.lean), z.label = 11;
                    case 11:
                        return [3, 13];
                    case 12:
                        for (A = 0, X = Fn; A < X.length; A++) L = X[A], li([a, 51, L]);
                        return Kn(), [3, 13];
                    case 13:
                        return [2]
                }
            }))
        }))
    }

    function Gn(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = dr(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function Zn(t) {
        return t.toString(36)
    }

    function Qn(t, e, n, a) {
        return "href" === t && "LINK" === a ? "".concat(t, "=").concat(e) : "".concat(t, "=").concat(S(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }

    function $n() {
        Un = null
    }

    function ta() {
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            r = t ? t.offsetWidth : null,
            i = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, r, i, o, u),
            s = t ? t.clientHeight : null,
            l = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            h = e ? e.scrollHeight : null,
            p = e ? e.offsetHeight : null,
            v = Math.max(s, l, d, f, h, p);
        null !== Un && c === Un.width && v === Un.height || null === c || null === v || (Un = {
            width: c,
            height: v
        }, Jn(8))
    }

    function ea(t, e, n, a) {
        return it(this, void 0, void 0, (function() {
            var r, i, o, u, c;
            return ot(this, (function(s) {
                switch (s.label) {
                    case 0:
                        r = [t], s.label = 1;
                    case 1:
                        if (!(r.length > 0)) return [3, 4];
                        for (i = r.shift(), o = i.firstChild; o;) r.push(o), o = o.nextSibling;
                        return 0 !== (u = Di(e)) ? [3, 3] : [4, Yi(e)];
                    case 2:
                        u = s.sent(), s.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = _a(i, n, a)) && r.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }
    var na = new Set,
        aa = [],
        ra = {},
        ia = [],
        oa = null,
        ua = null,
        ca = null,
        sa = {},
        la = new WeakMap,
        da = ["data-google-query-id", "data-load-complete", "data-google-container-id"];

    function fa() {
        na = new Set, ia = [], oa = null, ca = 0, sa = {}, la = new WeakMap, wa(window)
    }

    function ha(t) {
        var e = f();
        et(6, e), aa.push({
            time: e,
            mutations: t
        }), Ii(va, 1).then((function() {
            V(ta), Vo(Nr)()
        }))
    }

    function pa(t, e, n, a) {
        return it(this, void 0, void 0, (function() {
            var r, i, o;
            return ot(this, (function(u) {
                switch (u.label) {
                    case 0:
                        return 0 !== (r = Di(t)) ? [3, 2] : [4, Yi(t)];
                    case 1:
                        r = u.sent(), u.label = 2;
                    case 2:
                        if (2 === r) return [2];
                        switch (i = e.target, o = c.throttleDom ? function(t, e, n, a) {
                            var r = t.target ? hr(t.target.parentNode) : null;
                            if (r && "HTML" !== r.data.tag) {
                                var i = a > ca,
                                    o = hr(t.target),
                                    u = o && o.selector ? o.selector.join() : t.target.nodeName,
                                    c = [r.selector ? r.selector.join() : "", u, t.attributeName, ga(t.addedNodes), ga(t.removedNodes)].join();
                                sa[c] = c in sa ? sa[c] : [0, n];
                                var s = sa[c];
                                if (!1 === i && s[0] >= 10 && ma(s[2], 2, e, a), s[0] = i ? s[1] === n ? s[0] : s[0] + 1 : 1, s[1] = n, s[0] >= 10) return s[2] = t.removedNodes, n > a + 3e3 ? t.type : (ra[c] = {
                                    mutation: t,
                                    timestamp: a
                                }, "throttle")
                            }
                            return t.type
                        }(e, t, n, a) : e.type, o && i && i.ownerDocument && tr(i.ownerDocument), o && i && i.nodeType == Node.DOCUMENT_FRAGMENT_NODE && i.host && tr(i), o) {
                            case "attributes":
                                da.indexOf(e.attributeName) < 0 && _a(i, 3, a);
                                break;
                            case "characterData":
                                _a(i, 4, a);
                                break;
                            case "childList":
                                ma(e.addedNodes, 1, t, a), ma(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function va() {
        return it(this, void 0, void 0, (function() {
            var t, e, n, a, r, i, o, u, c, s, l;
            return ot(this, (function(d) {
                switch (d.label) {
                    case 0:
                        Pi(t = {
                            id: Mo(),
                            cost: 3
                        }), d.label = 1;
                    case 1:
                        if (!(aa.length > 0)) return [3, 7];
                        e = aa.shift(), n = f(), a = 0, r = e.mutations, d.label = 2;
                    case 2:
                        return a < r.length ? (i = r[a], [4, pa(t, i, n, e.time)]) : [3, 5];
                    case 3:
                        d.sent(), d.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, Jn(6, t, e.time)];
                    case 6:
                        return d.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(ra), d.label = 8;
                    case 8:
                        return u < c.length ? (s = c[u], l = ra[s], delete ra[s], [4, pa(t, l.mutation, f(), l.timestamp)]) : [3, 11];
                    case 9:
                        d.sent(), o = !0, d.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(ra).length > 0 && function() {
                            ua && B(ua);
                            ua = V((function() {
                                Ii(va, 1)
                            }), 33)
                        }(), 0 === Object.keys(ra).length && o ? [4, Jn(6, t, f())] : [3, 13];
                    case 12:
                        d.sent(), d.label = 13;
                    case 13:
                        return function() {
                            var t = f();
                            Object.keys(sa).length > 1e4 && (sa = {}, q(38));
                            for (var e = 0, n = Object.keys(sa); e < n.length; e++) {
                                var a = n[e];
                                t > sa[a][1] + 3e4 && delete sa[a]
                            }
                        }(), Ri(t), [2]
                }
            }))
        }))
    }

    function ga(t) {
        for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
        return e.join()
    }

    function ma(t, e, n, a) {
        return it(this, void 0, void 0, (function() {
            var r, i, o, u;
            return ot(this, (function(c) {
                switch (c.label) {
                    case 0:
                        r = t ? t.length : 0, i = 0, c.label = 1;
                    case 1:
                        return i < r ? (o = t[i], 1 !== e ? [3, 2] : (ea(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = Di(n)) ? [3, 4] : [4, Yi(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        _a(o, e, a), c.label = 5;
                    case 5:
                        return i++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function ya(t) {
        return ia.indexOf(t) < 0 && ia.push(t), oa && B(oa), oa = V((function() {
            ! function() {
                for (var t = 0, e = ia; t < e.length; t++) {
                    var n = e[t];
                    if (n) {
                        var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
                        if (a && vr(n)) continue;
                        ba(n, a ? "childList" : "characterData")
                    }
                }
                ia = []
            }()
        }), 33), t
    }

    function ba(t, e) {
        Vo(ha)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function wa(t) {
        if (null != t && (t.clarityOverrides = t.clarityOverrides || {}, "CSSStyleSheet" in t && t.CSSStyleSheet && t.CSSStyleSheet.prototype && void 0 === t.clarityOverrides.InsertRule && (t.clarityOverrides.InsertRule = t.CSSStyleSheet.prototype.insertRule, t.CSSStyleSheet.prototype.insertRule = function() {
                return lu() && ya(this.ownerNode), t.clarityOverrides.InsertRule.apply(this, arguments)
            }), "CSSMediaRule" in t && t.CSSMediaRule && t.CSSMediaRule.prototype && void 0 === t.clarityOverrides.MediaInsertRule && (t.clarityOverrides.MediaInsertRule = t.CSSMediaRule.prototype.insertRule, t.CSSMediaRule.prototype.insertRule = function() {
                return lu() && ya(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaInsertRule.apply(this, arguments)
            }), "CSSStyleSheet" in t && t.CSSStyleSheet && t.CSSStyleSheet.prototype && void 0 === t.clarityOverrides.DeleteRule && (t.clarityOverrides.DeleteRule = t.CSSStyleSheet.prototype.deleteRule, t.CSSStyleSheet.prototype.deleteRule = function() {
                return lu() && ya(this.ownerNode), t.clarityOverrides.DeleteRule.apply(this, arguments)
            }), "CSSMediaRule" in t && t.CSSMediaRule && t.CSSMediaRule.prototype && void 0 === t.clarityOverrides.MediaDeleteRule && (t.clarityOverrides.MediaDeleteRule = t.CSSMediaRule.prototype.deleteRule, t.CSSMediaRule.prototype.deleteRule = function() {
                return lu() && ya(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaDeleteRule.apply(this, arguments)
            }), "Element" in t && t.Element && t.Element.prototype && void 0 === t.clarityOverrides.AttachShadow)) {
            t.clarityOverrides.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return lu() ? ya(t.clarityOverrides.AttachShadow.apply(this, arguments)) : t.clarityOverrides.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.clarityOverrides.AttachShadow = null
            }
        }
    }
    var Sa = /[^0-9\.]/g;

    function ka(t) {
        for (var e = 0, n = Object.keys(t); e < n.length; e++) {
            var a = n[e],
                r = t[a];
            if ("@type" === a && "string" == typeof r) switch (r = (r = r.toLowerCase()).indexOf("article") >= 0 || r.indexOf("posting") >= 0 ? "article" : r) {
                case "article":
                case "recipe":
                    ao(5, t[a]), ao(8, t.creator), ao(18, t.headline);
                    break;
                case "product":
                    ao(5, t[a]), ao(10, t.name), ao(12, t.sku), t.brand && ao(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && (F(11, Oa(t.ratingValue, 100)), F(18, Oa(t.bestRating)), F(19, Oa(t.worstRating))), F(12, Oa(t.ratingCount)), F(17, Oa(t.reviewCount));
                    break;
                case "offer":
                    ao(7, t.availability), ao(14, t.itemCondition), ao(13, t.priceCurrency), ao(12, t.sku), F(13, Oa(t.price));
                    break;
                case "brand":
                    ao(6, t.name)
            }
            null !== r && "object" == typeof r && ka(r)
        }
    }

    function Oa(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(Sa, "")) * e)
        }
        return null
    }
    var Ea = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"],
        Ta = /[\r\n]+/g;

    function _a(e, n, a) {
        var r, i = null;
        if (2 === n && !1 === vr(e)) return i;
        0 !== n && e.nodeType === Node.TEXT_NODE && e.parentElement && "STYLE" === e.parentElement.tagName && (e = e.parentNode);
        var o = !1 === vr(e) ? "add" : "update",
            u = e.parentElement ? e.parentElement : null,
            c = e.ownerDocument !== document;
        switch (e.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                u = c && e.parentNode ? ir(e.parentNode) : u;
                var s = e,
                    l = {
                        tag: (c ? "iframe:" : "") + "*D",
                        attributes: {
                            name: s.name ? s.name : "HTML",
                            publicId: s.publicId,
                            systemId: s.systemId
                        }
                    };
                t[o](e, u, l, n);
                break;
            case Node.DOCUMENT_NODE:
                e === document && tr(document), Mn(e, a), Ma(e);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                var d = e;
                if (d.host) {
                    if (tr(d), "function" === typeof d.constructor && d.constructor.toString().indexOf("[native code]") >= 0) {
                        Ma(d);
                        var f = {
                            tag: "*S",
                            attributes: {
                                style: ""
                            }
                        };
                        t[o](e, d.host, f, n)
                    } else t[o](e, d.host, {
                        tag: "*P",
                        attributes: {}
                    }, n);
                    Mn(e, a)
                }
                break;
            case Node.TEXT_NODE:
                if (u = u || e.parentNode, "update" === o || u && vr(u) && "STYLE" !== u.tagName && "NOSCRIPT" !== u.tagName) {
                    var h = {
                        tag: "*T",
                        value: e.nodeValue
                    };
                    t[o](e, u, h, n)
                }
                break;
            case Node.ELEMENT_NODE:
                var p = e,
                    v = p.tagName,
                    g = function(t) {
                        var e = {},
                            n = t.attributes;
                        if (n && n.length > 0)
                            for (var a = 0; a < n.length; a++) {
                                var r = n[a].name;
                                Ea.indexOf(r) < 0 && (e[r] = n[a].value)
                            }
                        "INPUT" === t.tagName && !("value" in e) && t.value && (e.value = t.value);
                        return e
                    }(p);
                switch (u = e.parentElement ? e.parentElement : e.parentNode ? e.parentNode : null, "http://www.w3.org/2000/svg" === p.namespaceURI && (v = "svg:" + v), v) {
                    case "HTML":
                        u = c && u ? ir(u) : u;
                        var m = {
                            tag: (c ? "iframe:" : "") + v,
                            attributes: g
                        };
                        t[o](e, u, m, n);
                        break;
                    case "SCRIPT":
                        if ("type" in g && "application/ld+json" === g.type) try {
                            ka(JSON.parse(p.text.replace(Ta, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        var y = {
                            tag: v,
                            attributes: {},
                            value: ""
                        };
                        t[o](e, u, y, n);
                        break;
                    case "META":
                        var b = "property" in g ? "property" : "name" in g ? "name" : null;
                        if (b && "content" in g) {
                            var w = g.content;
                            switch (g[b]) {
                                case "og:title":
                                    ao(20, w);
                                    break;
                                case "og:type":
                                    ao(19, w);
                                    break;
                                case "generator":
                                    ao(21, w)
                            }
                        }
                        break;
                    case "HEAD":
                        var S = {
                                tag: v,
                                attributes: g
                            },
                            k = c && (null === (r = e.ownerDocument) || void 0 === r ? void 0 : r.location) ? e.ownerDocument.location : location;
                        S.attributes["*B"] = k.protocol + "//" + k.host + k.pathname, t[o](e, u, S, n);
                        break;
                    case "BASE":
                        var O = hr(e.parentElement);
                        if (O) {
                            var E = document.createElement("a");
                            E.href = g.href, O.data.attributes["*B"] = E.protocol + "//" + E.host + E.pathname
                        }
                        break;
                    case "STYLE":
                        var T = {
                            tag: v,
                            attributes: g,
                            value: xa(p)
                        };
                        t[o](e, u, T, n);
                        break;
                    case "IFRAME":
                        var _ = e,
                            M = {
                                tag: v,
                                attributes: g
                            };
                        rr(_) && (! function(t) {
                            !1 === vr(t) && Ko(t, "load", ba.bind(this, t, "childList"), !0)
                        }(_), M.attributes["*O"] = "true", _.contentDocument && _.contentWindow && "loading" !== _.contentDocument.readyState && (i = _.contentDocument)), 2 === n && Na(_), t[o](e, u, M, n);
                        break;
                    case "LINK":
                        if (bo && "stylesheet" === g.rel) {
                            for (var N in Object.keys(document.styleSheets)) {
                                var x = document.styleSheets[N];
                                if (x.ownerNode == p) {
                                    var I = {
                                        tag: "STYLE",
                                        attributes: g,
                                        value: Ia(x)
                                    };
                                    t[o](e, u, I, n);
                                    break
                                }
                            }
                            break
                        }
                        var C = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, C, n);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in g && g.src.startsWith("data:") && (g.src = "");
                        var D = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, D, n);
                        break;
                    default:
                        ! function(t) {
                            var e;
                            (null === (e = window.customElements) || void 0 === e ? void 0 : e.get) && window.customElements.get(t) && Bn(t)
                        }(p.localName);
                        var P = {
                            tag: v,
                            attributes: g
                        };
                        p.shadowRoot && (i = p.shadowRoot), t[o](e, u, P, n)
                }
        }
        return i
    }

    function Ma(t) {
        vr(t) || Zo(t) || (! function(t) {
            try {
                var e = s("MutationObserver"),
                    n = e in window ? new window[e](Vo(ha)) : null;
                n && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), la.set(t, n), na.add(n)), t.defaultView && wa(t.defaultView)
            } catch (t) {
                ki(2, 0, t ? t.name : null)
            }
        }(t), vn(t))
    }

    function Na(t) {
        Go(t);
        var e, n, a = or(t) || {},
            r = a.doc,
            i = void 0 === r ? null : r,
            o = a.win,
            u = void 0 === o ? null : o;
        u && Go(u), i && (Go(i), e = i, (n = la.get(e)) && (n.disconnect(), na.delete(n), la.delete(e)), ur(t, i))
    }

    function xa(t) {
        var e = t.textContent ? t.textContent.trim() : "",
            n = t.dataset ? Object.keys(t.dataset).length : 0;
        return (0 === e.length || n > 0 || t.id.length > 0) && (e = Ia(t.sheet)), e
    }

    function Ia(t) {
        var e = "",
            n = null;
        try {
            n = t ? t.cssRules : []
        } catch (t) {
            if (ki(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== n)
            for (var a = 0; a < n.length; a++) e += n[a].cssText;
        return e
    }
    var Ca = ["load", "active", "fixed", "visible", "focus", "show", "collaps", "animat"],
        Da = {};

    function Pa(t, e) {
        var n = t.attributes,
            a = t.prefix ? t.prefix[e] : null,
            r = 0 === e ? "".concat("~").concat(t.position - 1) : ":nth-of-type(".concat(t.position, ")");
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (null === a) return "";
                a = "".concat(a).concat(">"), t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag;
                var i = "".concat(a).concat(t.tag).concat(r),
                    o = "id" in n && n.id.length > 0 ? n.id : null,
                    u = "BODY" !== t.tag && "class" in n && n.class.length > 0 ? n.class.trim().split(/\s+/).filter((function(t) {
                        return Ra(t)
                    })).join(".") : null;
                if (u && u.length > 0)
                    if (0 === e) {
                        var c = "".concat(function(t) {
                            for (var e = t.split(">"), n = 0; n < e.length; n++) {
                                var a = e[n].indexOf("~"),
                                    r = e[n].indexOf(".");
                                e[n] = e[n].substring(0, r > 0 ? r : a > 0 ? a : e[n].length)
                            }
                            return e.join(">")
                        }(a)).concat(t.tag).concat(".").concat(u);
                        c in Da || (Da[c] = []), Da[c].indexOf(t.id) < 0 && Da[c].push(t.id), i = "".concat(c).concat("~").concat(Da[c].indexOf(t.id))
                    } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
                return i = o && Ra(o) ? "".concat(function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                    if (a < 0) return "";
                    return t.substring(0, t.indexOf(">", a) + 1)
                }(a)).concat("#").concat(o) : i, i
        }
    }

    function Ra(t) {
        if (!t) return !1;
        if (Ca.some((function(e) {
                return t.toLowerCase().indexOf(e) >= 0
            }))) return !1;
        for (var e = 0; e < t.length; e++) {
            var n = t.charCodeAt(e);
            if (n >= 48 && n <= 57) return !1
        }
        return !0
    }
    var Ya = 1,
        ja = null,
        Aa = [],
        Xa = [],
        La = {},
        za = [],
        Wa = [],
        Ha = [],
        qa = [],
        Ua = [],
        Fa = [],
        Va = null,
        Ba = null,
        Ka = null,
        Ja = null,
        Ga = null;

    function Za() {
        $a(), tr(document, !0)
    }

    function Qa() {
        $a()
    }

    function $a() {
        Ya = 1, Aa = [], Xa = [], La = {}, za = [], Wa = [], Ha = Jt, qa = Zt, Ua = Gt, Fa = Qt, ja = new Map, Va = new WeakMap, Ba = new WeakMap, Ka = new WeakMap, Ja = new WeakMap, Ga = new WeakMap, Da = {}
    }

    function tr(t, e) {
        void 0 === e && (e = !1);
        try {
            e && c.unmask.forEach((function(t) {
                return t.indexOf("!") < 0 ? Wa.push(t) : za.push(t.substr(1))
            })), "querySelectorAll" in t && (c.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return _r(t, "".concat(e[0]))
                }))
            })), c.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return Ja.set(t, 3)
                }))
            })), c.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Ga.set(t, e[0])
                }))
            })), Wa.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return Ja.set(t, 0)
                }))
            })))
        } catch (t) {
            ki(5, 1, t ? t.name : null)
        }
    }

    function er(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = Va.get(t);
        return !n && e && (n = Ya++, Va.set(t, n)), n || null
    }

    function nr(t, e, n, a) {
        var r = e ? er(e) : null;
        if (e && r || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
            var i = er(t, !0),
                o = yr(t),
                u = null,
                s = Mr(t) ? i : null,
                l = Ga.has(t) ? Ga.get(t) : null,
                d = c.content ? 1 : 3;
            r >= 0 && Aa[r] && ((u = Aa[r]).children.push(i), s = null === s ? u.region : s, l = null === l ? u.metadata.fraud : l, d = u.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (_r(t, n.attributes["data-clarity-region"]), s = i), ja.set(i, t), Aa[i] = {
                    id: i,
                    parent: r,
                    previous: o,
                    children: [],
                    data: n,
                    selector: null,
                    hash: null,
                    region: s,
                    metadata: {
                        active: !0,
                        suspend: !1,
                        privacy: d,
                        position: null,
                        fraud: l,
                        size: null
                    }
                },
                function(t, e, n) {
                    var a, r = e.data,
                        i = e.metadata,
                        o = i.privacy,
                        u = r.attributes || {},
                        c = r.tag.toUpperCase();
                    switch (!0) {
                        case Fa.indexOf(c) >= 0:
                            var s = u.type,
                                l = "",
                                d = ["class", "style"];
                            Object.keys(u).filter((function(t) {
                                return !d.includes(t)
                            })).forEach((function(t) {
                                return l += u[t].toLowerCase()
                            }));
                            var f = qa.some((function(t) {
                                return l.indexOf(t) >= 0
                            }));
                            i.privacy = "INPUT" === c && Ua.indexOf(s) >= 0 ? o : f ? 4 : 2;
                            break;
                        case "data-clarity-mask" in u:
                            i.privacy = 3;
                            break;
                        case "data-clarity-unmask" in u:
                            i.privacy = 0;
                            break;
                        case Ja.has(t):
                            i.privacy = Ja.get(t);
                            break;
                        case Ga.has(t):
                            i.privacy = 2;
                            break;
                        case "*T" === c:
                            var h = n && n.data ? n.data.tag : "",
                                p = n && n.selector ? n.selector[1] : "",
                                v = ["STYLE", "TITLE", "svg:style"];
                            i.privacy = v.includes(h) || za.some((function(t) {
                                return p.indexOf(t) >= 0
                            })) ? 0 : o;
                            break;
                        case 1 === o:
                            i.privacy = function(t, e, n) {
                                if (t && e.some((function(e) {
                                        return t.indexOf(e) >= 0
                                    }))) return 2;
                                return n.privacy
                            }(u.class, Ha, i);
                            break;
                        case "IMG" === c:
                            (null === (a = u.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (i.privacy = 3)
                    }
                }(t, Aa[i], u), sr(Aa[i]),
                function(t) {
                    if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                        var e = dr(t.id);
                        !e || e.complete && 0 !== e.naturalWidth || Ko(e, "load", (function() {
                            e.setAttribute("data-clarity-loaded", "".concat(jo()))
                        })), t.metadata.size = []
                    }
                }(Aa[i]), br(i, a)
        }
    }

    function ar(t, e, n, a) {
        var r = er(t),
            i = e ? er(e) : null,
            o = yr(t),
            u = !1,
            c = !1;
        if (r in Aa) {
            var s = Aa[r];
            if (s.metadata.active = !0, s.previous !== o && (u = !0, s.previous = o), s.parent !== i) {
                u = !0;
                var l = s.parent;
                if (s.parent = i, null !== i && i >= 0) {
                    var d = null === o ? 0 : Aa[i].children.indexOf(o) + 1;
                    Aa[i].children.splice(d, 0, r), s.region = Mr(t) ? r : Aa[i].region
                } else ! function(t, e) {
                    if (t in Aa) {
                        var n = Aa[t];
                        n.metadata.active = !1, n.parent = null, br(t, e), mr(t)
                    }
                }(r, a);
                if (null !== l && l >= 0) {
                    var f = Aa[l].children.indexOf(r);
                    f >= 0 && Aa[l].children.splice(f, 1)
                }
                c = !0
            }
            for (var h in n) cr(s.data, n, h) && (u = !0, s.data[h] = n[h]);
            sr(s), br(r, a, u, c)
        }
    }

    function rr(t) {
        var e = !1;
        if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
            var n = t;
            try {
                n.contentDocument && (Ba.set(n.contentDocument, n), Ka.set(n, {
                    doc: n.contentDocument,
                    win: n.contentWindow
                }), e = !0)
            } catch (t) {}
        }
        return e
    }

    function ir(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && Ba.has(e) ? Ba.get(e) : null
    }

    function or(t) {
        return Ka.has(t) ? Ka.get(t) : null
    }

    function ur(t, e) {
        Ka.delete(t), Ba.delete(e)
    }

    function cr(t, e, n) {
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (var a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (var a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function sr(t) {
        var e = t.parent && t.parent in Aa ? Aa[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            r = function(t, e) {
                e.metadata.position = 1;
                for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0;) {
                    var a = Aa[t.children[n]];
                    if (e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                }
                return e.metadata.position
            }(e, t),
            i = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: r,
                attributes: a.attributes
            };
        t.selector = [Pa(i, 0), Pa(i, 1)], t.hash = t.selector.map((function(t) {
            return t ? p(t) : null
        })), t.hash.forEach((function(e) {
            return La[e] = t.id
        }))
    }

    function lr(t) {
        var e = dr(pr(t));
        return null !== e && null !== e.textContent ? e.textContent.substr(0, 25) : ""
    }

    function dr(t) {
        return ja.has(t) ? ja.get(t) : null
    }

    function fr(t) {
        return t in Aa ? Aa[t] : null
    }

    function hr(t) {
        var e = er(t);
        return e in Aa ? Aa[e] : null
    }

    function pr(t) {
        return t in La ? La[t] : null
    }

    function vr(t) {
        return ja.has(er(t))
    }

    function gr() {
        for (var t = [], e = 0, n = Xa; e < n.length; e++) {
            var a = n[e];
            a in Aa && t.push(Aa[a])
        }
        return Xa = [], t
    }

    function mr(t) {
        var e = ja.get(t);
        if ((null == e ? void 0 : e.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE) {
            if (e && (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && "IFRAME" === e.tagName) Na(e);
            ja.delete(t);
            var n = t in Aa ? Aa[t] : null;
            if (n && n.children)
                for (var a = 0, r = n.children; a < r.length; a++) {
                    mr(r[a])
                }
        }
    }

    function yr(t) {
        for (var e = null; null === e && t.previousSibling;) e = er(t.previousSibling), t = t.previousSibling;
        return e
    }

    function br(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !c.lean || !c.lite) {
            var r = Xa.indexOf(t);
            r >= 0 && 1 === e && a ? (Xa.splice(r, 1), Xa.push(t)) : -1 === r && n && Xa.push(t)
        }
    }
    var wr = [],
        Sr = null,
        kr = {},
        Or = [],
        Er = !1,
        Tr = null;

    function _r(t, e) {
        !1 === Sr.has(t) && (Sr.set(t, e), (Tr = null === Tr && Er ? new IntersectionObserver(xr, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : Tr) && t && t.nodeType === Node.ELEMENT_NODE && Tr.observe(t))
    }

    function Mr(t) {
        return Sr && Sr.has(t)
    }

    function Nr() {
        for (var t = [], e = 0, n = Or; e < n.length; e++) {
            var a = n[e],
                r = er(a.node);
            r ? (a.state.data.id = r, kr[r] = a.state.data, wr.push(a.state)) : t.push(a)
        }
        Or = t, wr.length > 0 && Jn(7)
    }

    function xr(t) {
        for (var e = 0, n = t; e < n.length; e++) {
            var a = n[e],
                r = a.target,
                i = a.boundingClientRect,
                o = a.intersectionRect,
                u = a.rootBounds;
            if (Sr.has(r) && i.width + i.height > 0 && u && u.width > 0 && u.height > 0) {
                var c = r ? er(r) : null,
                    s = c in kr ? kr[c] : {
                        id: c,
                        name: Sr.get(r),
                        interaction: 16,
                        visibility: 0
                    },
                    l = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8,
                    d = (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
                Ir(r, s, s.interaction, d ? 13 : l ? 10 : 0), s.visibility >= 13 && Tr && Tr.unobserve(r)
            }
        }
        wr.length > 0 && Jn(7)
    }

    function Ir(t, e, n, a) {
        var r = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in kr && r || !(e.id in kr)) && (kr[e.id] = e, wr.push(Cr(e))) : Or.push({
            node: t,
            state: Cr(e)
        })
    }

    function Cr(t) {
        return {
            time: f(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function Dr() {
        wr = []
    }

    function Pr(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return ca = f() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function Rr(t, e, n) {
        void 0 === n && (n = null);
        var a = {
            id: 0,
            hash: null,
            privacy: 2
        };
        if (t) {
            var r = hr(t);
            if (null !== r) {
                var i = r.metadata;
                a.id = r.id, a.hash = r.hash, a.privacy = i.privacy, r.region && function(t, e) {
                    var n = dr(t),
                        a = t in kr ? kr[t] : {
                            id: t,
                            visibility: 0,
                            interaction: 16,
                            name: Sr.get(n)
                        },
                        r = 16;
                    switch (e) {
                        case 9:
                            r = 20;
                            break;
                        case 27:
                            r = 30
                    }
                    Ir(n, a, r, a.visibility)
                }(r.region, e), i.fraud && Kt(i.fraud, r.id, n || r.data.value)
            }
        }
        return a
    }

    function Yr(t, e) {
        return void 0 === e && (e = null), it(this, void 0, void 0, (function() {
            var n, a, r, i, o, u, c, s, l, d, h, p, v, g, m, y, b, w, O, E, T, _, M, N, x, I, C, P, Y, j, A, X, L, z, W, H;
            return ot(this, (function(q) {
                switch (n = e || f(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (r = 0, i = ke; r < i.length; r++) z = i[r], (o = Rr(z.data.target, z.event)).id > 0 && ((a = [z.time, z.event]).push(o.id), a.push(z.data.x), a.push(z.data.y), void 0 !== z.data.id && (a.push(z.data.id), void 0 !== z.data.isPrimary && a.push(z.data.isPrimary.toString())), li(a), (void 0 === z.data.isPrimary || z.data.isPrimary) && D(z.event, z.data.x, z.data.y, z.time));
                        Ce();
                        break;
                    case 9:
                    case 48:
                        for (u = 0, c = ie; u < c.length; u++) z = c[u], s = Rr(z.data.target, z.event, z.data.text), a = [z.time, z.event], l = s.hash ? s.hash.join(".") : "", a.push(s.id), a.push(z.data.x), a.push(z.data.y), a.push(z.data.eX), a.push(z.data.eY), a.push(z.data.button), a.push(z.data.reaction), a.push(z.data.context), a.push(S(z.data.text, "click", s.privacy)), a.push(k(z.data.link)), a.push(l), a.push(z.data.trust), a.push(z.data.isFullText), a.push(z.data.w), a.push(z.data.h), a.push(z.data.tag), a.push(z.data.class), a.push(z.data.id), a.push(z.data.source), li(a), Lr(z.time, z.event, l, z.data.x, z.data.y, z.data.reaction, z.data.context);
                        fe();
                        break;
                    case 38:
                        for (d = 0, h = he; d < h.length; d++) z = h[d], a = [z.time, z.event], (A = Rr(z.data.target, z.event)).id > 0 && (a.push(A.id), a.push(z.data.action), li(a));
                        ve();
                        break;
                    case 11:
                        p = Se, a.push(p.width), a.push(p.height), D(t, p.width, p.height), Xe(), li(a);
                        break;
                    case 26:
                        v = tn, a.push(v.name), a.push(v.persisted), cn(), li(a);
                        break;
                    case 27:
                        for (g = 0, m = me; g < m.length; g++) z = m[g], y = Rr(z.data.target, z.event, z.data.value), (a = [z.time, z.event]).push(y.id), a.push(S(z.data.value, "input", y.privacy, !1, z.data.type)), a.push(z.data.trust), li(a);
                        we();
                        break;
                    case 21:
                        (b = Ke) && (w = Rr(b.start, t), O = Rr(b.end, t), a.push(w.id), a.push(b.startOffset), a.push(O.id), a.push(b.endOffset), $e(), li(a));
                        break;
                    case 10:
                        for (E = 0, T = Le; E < T.length; E++) z = T[E], _ = Rr(z.data.target, z.event), M = Rr(z.data.top, z.event), N = Rr(z.data.bottom, z.event), x = (null == M ? void 0 : M.hash) ? M.hash.join(".") : "", I = (null == N ? void 0 : N.hash) ? N.hash.join(".") : "", _.id > 0 && ((a = [z.time, z.event]).push(_.id), a.push(z.data.x), a.push(z.data.y), a.push(x), a.push(I), a.push(z.data.trust), li(a), D(z.event, z.data.x, z.data.y, z.time));
                        Le = [], ze = null, We = null;
                        break;
                    case 42:
                        for (C = 0, P = $t; C < P.length; C++) z = P[C], a = [z.time, z.event], (A = Rr(z.data.target, z.event)).id > 0 && ((a = [z.time, z.event]).push(A.id), a.push(z.data.type), a.push(S(z.data.value, "change", A.privacy)), a.push(S(z.data.checksum, "checksum", A.privacy)), li(a));
                        ee();
                        break;
                    case 39:
                        for (Y = 0, j = an; Y < j.length; Y++) z = j[Y], a = [z.time, z.event], (A = Rr(z.data.target, z.event)).id > 0 && (a.push(A.id), li(a));
                        on();
                        break;
                    case 22:
                        for (X = 0, L = Ar; X < L.length; X++) z = L[X], (a = [z.time, z.event]).push(z.data.type), a.push(z.data.hash), a.push(z.data.x), a.push(z.data.y), a.push(z.data.reaction), a.push(z.data.context), li(a, !1);
                        Xr();
                        break;
                    case 28:
                        W = en, a.push(W.visible), li(a), R(n, W.visible), ln();
                        break;
                    case 50:
                        H = nn, a.push(H.focused), li(a, !1), dn()
                }
                return [2]
            }))
        }))
    }
    var jr = [],
        Ar = [];

    function Xr() {
        Ar = []
    }

    function Lr(t, e, n, a, r, i, o) {
        void 0 === i && (i = 1), void 0 === o && (o = 0), jr.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: r,
                reaction: i,
                context: o
            }
        }), D(e, a, r, t)
    }

    function zr(t, e, n, a) {
        return "href" === t && "LINK" === a ? "".concat(t, "=").concat(e) : "".concat(t, "=").concat(S(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }
    var Wr = [],
        Hr = 1,
        qr = null;

    function Ur() {
        Wr = [],
            function(t) {
                var e = [t];
                for (; e.length > 0;) {
                    for (var n = null, a = null, r = null, i = e.shift(), o = i.firstChild, u = i.parentElement ? i.parentElement : i.parentNode ? i.parentNode : null; o;) e.push(o), o = o.nextSibling;
                    switch (i.nodeType) {
                        case Node.DOCUMENT_TYPE_NODE:
                            var c = i;
                            a = "*D", n = {
                                name: c.name,
                                publicId: c.publicId,
                                systemId: c.systemId
                            };
                            break;
                        case Node.TEXT_NODE:
                            r = i.nodeValue, a = qr.get(u) ? "*T" : a;
                            break;
                        case Node.ELEMENT_NODE:
                            var s = i;
                            n = Fr(s), a = ["NOSCRIPT", "SCRIPT", "STYLE"].indexOf(s.tagName) < 0 ? s.tagName : a
                    }
                    Vr(i, u, {
                        tag: a,
                        attributes: n,
                        value: r
                    })
                }
            }(document),
            function(t) {
                it(this, void 0, void 0, (function() {
                    var e, n, a, r, i, o, u, c, s, l, d, h, p;
                    return ot(this, (function(v) {
                        switch (e = f(), n = [e, t], t) {
                            case 8:
                                a = Un, n.push(a.width), n.push(a.height), D(t, a.width, a.height), li(n);
                                break;
                            case 43:
                                if ((r = Wr).length > 0) {
                                    for (i = 0, o = r; i < o.length; i++)
                                        for (u = o[i], c = u.metadata.privacy, s = u.data, l = 0, d = ["tag", "attributes", "value"]; l < d.length; l++)
                                            if (s[h = d[l]]) switch (h) {
                                                case "tag":
                                                    n.push(u.id), u.parent && n.push(u.parent), u.previous && n.push(u.previous), n.push(s[h]);
                                                    break;
                                                case "attributes":
                                                    for (p in s[h]) void 0 !== s[h][p] && n.push(zr(p, s[h][p], c, s.tag));
                                                    break;
                                                case "value":
                                                    n.push(S(s[h], s.tag, c))
                                            }
                                    li(mn(n), !0)
                                }
                        }
                        return [2]
                    }))
                }))
            }(43)
    }

    function Fr(t) {
        var e = {},
            n = t.attributes;
        if (n && n.length > 0)
            for (var a = 0; a < n.length; a++) e[n[a].name] = n[a].value;
        return e
    }

    function Vr(t, e, n) {
        if (t && n && n.tag) {
            var a = function(t) {
                    return null === t ? null : qr.has(t) ? qr.get(t) : (qr.set(t, Hr), Hr++)
                }(t),
                r = e ? qr.get(e) : null,
                i = t.previousSibling ? qr.get(t.previousSibling) : null;
            Wr.push({
                id: a,
                parent: r,
                previous: i,
                children: [],
                data: n,
                selector: null,
                hash: null,
                region: null,
                metadata: {
                    active: !0,
                    suspend: !1,
                    privacy: 5,
                    position: null,
                    fraud: null,
                    size: null
                }
            })
        }
    }
    var Br = [],
        Kr = !1,
        Jr = null;

    function Gr(t) {
        Kr && "function" == typeof t && Br.push(t)
    }

    function Zr(t) {
        if (Kr) {
            var e = t ? t.split(" ") : [""],
                n = e.length > 1 ? parseInt(e[1], 10) : null;
            n && Jr.has(n) || function(t, e) {
                try {
                    var n = document.createElement("script");
                    n.src = t, n.async = !0, n.onload = function() {
                        e && (Jr.add(e), Y(Jr))
                    }, n.onerror = function() {
                        Fo(new Error("".concat("MODULE", ": ").concat(t)))
                    }, document.head.appendChild(n)
                } catch (t) {}
            }(e[0], n)
        }
    }
    var Qr, $r, ti, ei, ni, ai = Object.freeze({
            __proto__: null,
            event: Zr,
            register: Gr,
            start: function() {
                Kr = !0, Jr = new Set, c.modules && c.modules.length > 0 && c.modules.forEach((function(t) {
                    Zr(t)
                }))
            },
            stop: function() {
                Br.reverse().forEach((function(t) {
                    try {
                        t()
                    } catch (t) {}
                })), Br = [], Kr = !1
            }
        }),
        ri = 0,
        ii = 0,
        oi = null,
        ui = 0,
        ci = !1;

    function si() {
        ei = !0, ri = 0, ii = 0, ci = !1, ui = 0, Qr = [], $r = [], ti = {}, ni = null
    }

    function li(t, e) {
        if (void 0 === e && (e = !0), ei) {
            var n = f(),
                a = t.length > 1 ? t[1] : null,
                r = JSON.stringify(t);
            switch (c.lean ? !ci && ii + r.length > 10485760 && (ki(10, 0), ci = !0) : ci = !1, a) {
                case 5:
                    if (ci) break;
                    ri += r.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                case 44:
                case 51:
                    if (ci) break;
                    ii += r.length, Qr.push(r);
                    break;
                default:
                    $r.push(r)
            }
            q(25);
            var i = function() {
                var t = !1 === c.lean && ri > 0 ? 100 : zo.sequence * c.delay;
                return "string" == typeof c.upload ? Math.max(Math.min(t, 3e4), 100) : c.delay
            }();
            n - ui > 2 * i && (B(oi), oi = null), e && null === oi && (25 !== a && Z(), oi = V(fi, i), ui = n, Ki(ii))
        }
    }

    function di() {
        B(oi), fi(!0), ri = 0, ii = 0, ci = !1, ui = 0, Qr = [], $r = [], ti = {}, ni = null, ei = !1
    }

    function fi(t) {
        return void 0 === t && (t = !1), it(this, void 0, void 0, (function() {
            var e, n, a, r, i, o, u, s;
            return ot(this, (function(l) {
                switch (l.label) {
                    case 0:
                        return ei ? (oi = null, (e = !1 === c.lean && ii > 0 && (ii < 1048576 || zo.sequence > 0)) && F(1, 1), Nr(), function() {
                            if (zo) {
                                var t = [];
                                Ar = [];
                                for (var e = (zo.start || 0) + (zo.duration || 0), n = Math.max(e - 2e3, 0), a = 0, r = jr; a < r.length; a++) {
                                    var i = r[a];
                                    i.time >= n && (i.time <= e && Ar.push(i), t.push(i))
                                }
                                jr = t, Yr(22)
                            }
                        }(), Ft(), function() {
                            for (var t = 0, e = On; t < e.length; t++) {
                                var n = e[t],
                                    a = n == document ? -1 : er(n);
                                Mn(n, a in kn ? kn[a] : null)
                            }
                        }(), n = !0 === t, zo ? (a = JSON.stringify(qo(n)), r = "[".concat($r.join(), "]"), i = e ? "[".concat(Qr.join(), "]") : "", n && i.length > 0 && a.length + r.length + i.length > 65536 && (i = ""), o = function(t) {
                            return t.p.length > 0 ? '{"e":'.concat(t.e, ',"a":').concat(t.a, ',"p":').concat(t.p, "}") : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}")
                        }({
                            e: a,
                            a: r,
                            p: i
                        }), n ? (s = null, [3, 3]) : [3, 1]) : [2]) : [2];
                    case 1:
                        return [4, ct(o)];
                    case 2:
                        s = l.sent(), l.label = 3;
                    case 3:
                        return U(2, (u = s) ? u.length : o.length), hi(o, u, zo.sequence, n), $r = [], e && (Qr = [], ii = 0, ri = 0, ci = !1), [2]
                }
            }))
        }))
    }

    function hi(t, e, n, a) {
        if (void 0 === a && (a = !1), "string" == typeof c.upload) {
            var r = c.upload,
                i = !1;
            if (a && navigator && navigator.sendBeacon) try {
                (i = navigator.sendBeacon.bind(navigator)(r, t)) && vi(n)
            } catch (t) {}
            if (!1 === i) {
                n in ti ? ti[n].attempts++ : ti[n] = {
                    data: t,
                    attempts: 1
                };
                var o = new XMLHttpRequest;
                o.open("POST", r, !0), o.timeout = 15e3, o.ontimeout = function() {
                    Fo(new Error("".concat("Timeout", " : ").concat(r)))
                }, null !== n && (o.onreadystatechange = function() {
                    Vo(pi)(o, n)
                }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t)
            }
        } else if (c.upload) {
            (0, c.upload)(t), vi(n)
        }
    }

    function pi(t, e) {
        var n = ti[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? Ji(6) : (0 === t.status && (c.upload = c.fallback ? c.fallback : c.upload), ni = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, Vi(2), hi(n.data, null, e)) : (ni = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Vi(2), 200 === t.status && t.responseText && function(t) {
            for (var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e; n < a.length; n++) {
                var r = a[n],
                    i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                    case "END":
                        Ji(6);
                        break;
                    case "UPGRADE":
                        Ui("Auto");
                        break;
                    case "ACTION":
                        c.action && i.length > 1 && c.action(i[1]);
                        break;
                    case "EXTRACT":
                        i.length > 1 && Tt(i[1]);
                        break;
                    case "SIGNAL":
                        i.length > 1 && Wt(i[1]);
                        break;
                    case "MODULE":
                        i.length > 1 && Zr(i[1]);
                        break;
                    case "SNAPSHOT":
                        c.lean = !1, Ur()
                }
            }
        }(t.responseText), 0 === t.status && (hi(n.data, null, e, !0), Ji(3)), t.status >= 200 && t.status <= 208 && vi(e), delete ti[e]))
    }

    function vi(t) {
        1 === t && (Ro(), Po())
    }
    var gi, mi = {};

    function yi(t) {
        var e = t.error || t;
        return e.message in mi || (mi[e.message] = 0), mi[e.message]++ >= 5 || e && e.message && (gi = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, bi(31)), !0
    }

    function bi(t) {
        return it(this, void 0, void 0, (function() {
            var e;
            return ot(this, (function(n) {
                switch (e = [f(), t], t) {
                    case 31:
                        e.push(gi.message), e.push(gi.line), e.push(gi.column), e.push(gi.stack), e.push(k(gi.source)), li(e);
                        break;
                    case 33:
                        wi && (e.push(wi.code), e.push(wi.name), e.push(wi.message), e.push(wi.stack), e.push(wi.severity), li(e, !1));
                        break;
                    case 41:
                        Vt && (e.push(Vt.id), e.push(Vt.target), e.push(Vt.checksum), li(e, !1))
                }
                return [2]
            }))
        }))
    }
    var wi, Si = {};

    function ki(t, e, n, a, r) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === r && (r = null);
        var i = n ? "".concat(n, "|").concat(a) : "";
        t in Si && Si[t].indexOf(i) >= 0 || (wi = {
            code: t,
            name: n,
            message: a,
            stack: r,
            severity: e
        }, t in Si ? Si[t].push(i) : Si[t] = [i], bi(33))
    }
    var Oi = 5e3,
        Ei = {},
        Ti = [],
        _i = null,
        Mi = null,
        Ni = null;

    function xi() {
        Ei = {}, Ti = [], _i = null, Mi = null
    }

    function Ii(t, e) {
        return void 0 === e && (e = 0), it(this, void 0, void 0, (function() {
            var n, a, r;
            return ot(this, (function(i) {
                for (n = 0, a = Ti; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return r = new Promise((function(n) {
                    Ti[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: Mo()
                    })
                })), null === _i && null === Mi && Ci(), [2, r]
            }))
        }))
    }

    function Ci() {
        var t = Ti.shift();
        t && (_i = t, t.task().then((function() {
            t.id === Mo() && (t.resolve(), _i = null, Ci())
        })).catch((function(e) {
            t.id === Mo() && (e && ki(0, 1, e.name, e.message, e.stack), _i = null, Ci())
        })))
    }

    function Di(t) {
        var e = ji(t);
        return e in Ei ? performance.now() - Ei[e].start > Ei[e].yield ? 0 : 1 : 2
    }

    function Pi(t) {
        Ei[ji(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function Ri(t) {
        var e = performance.now(),
            n = ji(t),
            a = e - Ei[n].start;
        U(t.cost, a), q(5), Ei[n].calls > 0 && U(4, a)
    }

    function Yi(t) {
        var e;
        return it(this, void 0, void 0, (function() {
            var n, a;
            return ot(this, (function(r) {
                switch (r.label) {
                    case 0:
                        return (n = ji(t)) in Ei ? (Ri(t), a = Ei[n], [4, Ai()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = r.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e = ji(t);
                                if (Ei && Ei[e]) {
                                    var n = Ei[e].calls,
                                        a = Ei[e].yield;
                                    Pi(t), Ei[e].calls = n + 1, Ei[e].yield = a
                                }
                            }(t), r.label = 2;
                    case 2:
                        return [2, n in Ei ? 1 : 2]
                }
            }))
        }))
    }

    function ji(t) {
        return "".concat(t.id, ".").concat(t.cost)
    }

    function Ai() {
        return it(this, void 0, void 0, (function() {
            return ot(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return Mi ? [4, Mi] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            Xi(t, {
                                timeout: Oi
                            })
                        }))]
                }
            }))
        }))
    }
    var Xi = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            r = a.port1,
            i = a.port2;
        r.onmessage = function(a) {
            var r = performance.now(),
                o = r - n,
                u = r - a.data;
            if (u > 30 && o < e.timeout) requestAnimationFrame((function() {
                i.postMessage(r)
            }));
            else {
                var c = o > e.timeout;
                t({
                    didTimeout: c,
                    timeRemaining: function() {
                        return c ? 30 : Math.max(0, 30 - u)
                    }
                })
            }
        }, requestAnimationFrame((function() {
            i.postMessage(performance.now())
        }))
    };

    function Li() {
        Ii(zi, 1).then((function() {
            Vo(ta)(), Vo(Nr)(), Vo(Be)()
        }))
    }

    function zi() {
        return it(this, void 0, void 0, (function() {
            var t, e;
            return ot(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = f(), Pi(e = {
                            id: Mo(),
                            cost: 3
                        }), [4, ea(document, e, 0, t)];
                    case 1:
                        return n.sent(), Mn(document, t), [4, Jn(5, e, t)];
                    case 2:
                        return n.sent(), Ri(e), [2]
                }
            }))
        }))
    }
    var Wi, Hi = null;

    function qi() {
        !c.lean && c.upgrade && c.upgrade("Config"), Hi = null
    }

    function Ui(t) {
        lu() && c.lean && (c.lean = !1, Hi = {
            key: t
        }, Po(), Ro(), c.upgrade && c.upgrade(t), Vi(3), c.lite && (Li(), _n()))
    }

    function Fi() {
        Hi = null
    }

    function Vi(t) {
        var e = [f(), t];
        switch (t) {
            case 4:
                var n = N;
                n && n.data && ((e = [n.time, n.event]).push(n.data.visible), e.push(n.data.docWidth), e.push(n.data.docHeight), e.push(n.data.screenWidth), e.push(n.data.screenHeight), e.push(n.data.scrollX), e.push(n.data.scrollY), e.push(n.data.pointerX), e.push(n.data.pointerY), e.push(n.data.activityTime), e.push(n.data.scrollTime), e.push(n.data.pointerTime), e.push(n.data.moveX), e.push(n.data.moveY), e.push(n.data.moveTime), e.push(n.data.downX), e.push(n.data.downY), e.push(n.data.downTime), e.push(n.data.upX), e.push(n.data.upY), e.push(n.data.upTime), e.push(n.data.pointerPrevX), e.push(n.data.pointerPrevY), e.push(n.data.pointerPrevTime), e.push(n.data.modules), li(e, !1)), C();
                break;
            case 25:
                e.push(z.gap), li(e);
                break;
            case 35:
                e.push(Wi.check), li(e, !1);
                break;
            case 3:
                e.push(Hi.key), li(e);
                break;
            case 2:
                e.push(ni.sequence), e.push(ni.attempts), e.push(ni.status), li(e, !1);
                break;
            case 24:
                X.key && e.push(X.key), e.push(X.value), li(e);
                break;
            case 34:
                var a = Object.keys(lt);
                if (a.length > 0) {
                    for (var r = 0, i = a; r < i.length; r++) {
                        var o = i[r];
                        e.push(o), e.push(lt[o])
                    }
                    vt(), li(e, !1)
                }
                break;
            case 0:
                var u = Object.keys(H);
                if (u.length > 0) {
                    for (var c = 0, s = u; c < s.length; c++) {
                        var l = s[c],
                            d = parseInt(l, 10);
                        e.push(d), e.push(Math.round(H[l]))
                    }
                    H = {}, li(e, !1)
                }
                break;
            case 1:
                var h = Object.keys($i);
                if (h.length > 0) {
                    for (var p = 0, v = h; p < v.length; p++) {
                        var g = v[p];
                        d = parseInt(g, 10);
                        e.push(d), e.push($i[g])
                    }
                    io(), li(e, !1)
                }
                break;
            case 36:
                var m = Object.keys(tt);
                if (m.length > 0) {
                    for (var y = 0, b = m; y < b.length; y++) {
                        var w = b[y];
                        d = parseInt(w, 10);
                        e.push(d), e.push([].concat.apply([], tt[w]))
                    }
                    at(), li(e, !1)
                }
                break;
            case 40:
                wt.forEach((function(t) {
                    e.push(t);
                    var n = [];
                    for (var a in bt[t]) {
                        var r = parseInt(a, 10);
                        n.push(r), n.push(bt[t][a])
                    }
                    e.push(n)
                })), Nt(), li(e, !1);
                break;
            case 47:
                e.push(oo.source), e.push(oo.ad_Storage), e.push(oo.analytics_Storage), li(e, !1)
        }
    }

    function Bi() {
        Wi = {
            check: 0
        }
    }

    function Ki(t) {
        if (0 === Wi.check) {
            var e = Wi.check;
            e = zo.sequence >= 128 ? 1 : e, e = zo.pageNum >= 128 ? 7 : e, e = f() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Wi.check && Ji(e)
        }
    }

    function Ji(t) {
        Wi.check = t, 5 !== t && (Do(), Yu())
    }

    function Gi() {
        0 !== Wi.check && Vi(35)
    }

    function Zi() {
        Wi = null
    }
    var Qi = null,
        $i = null,
        to = !1;

    function eo() {
        Qi = {}, $i = {}, to = !1
    }

    function no() {
        Qi = {}, $i = {}, to = !1
    }

    function ao(t, e) {
        if (e && (e = "".concat(e), t in Qi || (Qi[t] = []), Qi[t].indexOf(e) < 0)) {
            if (Qi[t].length > 128) return void(to || (to = !0, Ji(5)));
            Qi[t].push(e), t in $i || ($i[t] = []), $i[t].push(e)
        }
    }

    function ro() {
        Vi(1)
    }

    function io() {
        $i = {}, to = !1
    }
    var oo = null,
        uo = !0;

    function co() {
        var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        uo = !0, (null == e ? void 0 : e.addListener) && e.addListener(["ad_storage", "analytics_storage"], lo)
    }

    function so() {
        uo = !0
    }

    function lo() {
        var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        if (null == e ? void 0 : e.getConsentState) try {
            var n = e.getConsentState("analytics_storage");
            xo(function(t) {
                var e = {
                    source: 2,
                    ad_Storage: 1 === t.ad_Storage ? "granted" : "denied",
                    analytics_Storage: 1 === t.analytics_Storage ? "granted" : "denied"
                };
                return e
            }({
                ad_Storage: e.getConsentState("ad_storage"),
                analytics_Storage: n
            }))
        } catch (t) {
            return
        }
    }

    function fo(t) {
        po(t.analytics_Storage ? 1 : 0), oo = t
    }

    function ho() {
        po(2)
    }

    function po(t) {
        ao(36, t.toString())
    }

    function vo(t) {
        oo = t, Vi(47)
    }

    function go() {
        var t;
        if (uo && (Vi(47), uo = !1, !c.track)) {
            var e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
            (null == e ? void 0 : e.usedUpdate) && lo()
        }
    }
    var mo = null,
        yo = [],
        bo = 0,
        wo = null,
        So = !1,
        ko = {
            source: 7,
            ad_Storage: "denied",
            analytics_Storage: "denied"
        };

    function Oo() {
        var t, e, n, a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
            r = null !== (n = "undefined" != typeof Intl && (null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone)) && void 0 !== n ? n : "",
            i = (new Date).getTimezoneOffset().toString(),
            o = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
            u = document && document.title ? document.title : "";
        bo = a.indexOf("Electron") > 0 ? 1 : 0;
        var s = function() {
                var t = {
                        session: jo(),
                        ts: Math.round(Date.now()),
                        count: 1,
                        upgrade: null,
                        upload: ""
                    },
                    e = Xt("_clsk", !c.includeSubdomains);
                if (e) {
                    var n = e.includes("^") ? e.split("^") : e.split("|");
                    n.length >= 5 && t.ts - Ao(n[1]) < 18e5 && (t.session = n[0], t.count = Ao(n[2]) + 1, t.upgrade = Ao(n[3]), t.upload = n.length >= 6 ? "".concat("https://").concat(n[5], "/").concat(n[4]) : "".concat("https://").concat(n[4]))
                }
                return t
            }(),
            l = Xo(),
            d = c.projectId || p(location.host);
        mo = {
            projectId: d,
            userId: l.id,
            sessionId: s.session,
            pageNum: s.count
        }, c.lean = c.track && null !== s.upgrade ? 0 === s.upgrade : c.lean, c.upload = c.track && "string" == typeof c.upload && s.upload && s.upload.length > "https://".length ? s.upload : c.upload, ao(0, a), ao(3, u), ao(1, k(location.href, !!bo)), ao(2, document.referrer), ao(15, function() {
            var t = jo();
            if (c.track && Rt(window, "sessionStorage")) {
                var e = sessionStorage.getItem("_cltk");
                t = e || t, sessionStorage.setItem("_cltk", t)
            }
            return t
        }()), ao(16, document.documentElement.lang), ao(17, document.dir), ao(26, "".concat(window.devicePixelRatio)), ao(28, l.dob.toString()), ao(29, l.version.toString()), ao(33, o), ao(34, r), ao(35, i), F(0, s.ts), F(1, 0), F(35, bo);
        var f, h = null === window || void 0 === window ? void 0 : window.Zone;
        h && "__symbol__" in h && F(39, 1), navigator && (ao(9, navigator.language), F(33, navigator.hardwareConcurrency), F(32, navigator.maxTouchPoints), F(34, Math.round(navigator.deviceMemory)), (f = navigator.userAgentData) && f.getHighEntropyValues ? f.getHighEntropyValues(["model", "platform", "platformVersion", "uaFullVersion"]).then((function(t) {
            var e;
            ao(22, t.platform), ao(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                ao(24, t.name + "~" + t.version)
            })), ao(25, t.model), F(27, t.mobile ? 1 : 0)
        })) : ao(22, navigator.platform)), screen && (F(14, Math.round(screen.width)), F(15, Math.round(screen.height)), F(16, Math.round(screen.colorDepth))), null === wo && (wo = {
            source: l.consent ? 6 : 0,
            ad_Storage: c.track ? "granted" : "denied",
            analytics_Storage: c.track ? "granted" : "denied"
        }), Eo(), fo(Io(wo)), Yo(l)
    }

    function Eo() {
        if (!So && "granted" === (null == wo ? void 0 : wo.analytics_Storage) && "granted" === (null == wo ? void 0 : wo.ad_Storage)) {
            for (var t = 0, e = c.cookies; t < e.length; t++) {
                var n = e[t],
                    a = Xt(n);
                a && dt(n, a)
            }
            So = !0
        }
    }

    function To() {
        mo = null, So = !1, yo.forEach((function(t) {
            t.called = !1
        }))
    }

    function _o(t, e, n, a) {
        void 0 === e && (e = !0), void 0 === n && (n = !1), void 0 === a && (a = !1);
        var r = c.lean ? 0 : 1,
            i = !1;
        mo && (r || !1 === e) && (t(mo, !c.lean, a ? wo : void 0), i = !0), !n && i || yo.push({
            callback: t,
            wait: e,
            recall: n,
            called: i,
            consentInfo: a
        })
    }

    function Mo() {
        return mo ? [mo.userId, mo.sessionId, mo.pageNum].join(".") : ""
    }

    function No(t) {
        void 0 === t && (t = !0), xo(t ? {
            source: 4,
            ad_Storage: "granted",
            analytics_Storage: "granted"
        } : {
            source: 4,
            ad_Storage: "denied",
            analytics_Storage: "denied"
        })
    }

    function xo(t, e) {
        var n;
        if (void 0 === t && (t = ko), void 0 === e && (e = 5), lu()) {
            var a = {
                source: null !== (n = t.source) && void 0 !== n ? n : e,
                ad_Storage: Co(t.ad_Storage, null == wo ? void 0 : wo.ad_Storage),
                analytics_Storage: Co(t.analytics_Storage, null == wo ? void 0 : wo.analytics_Storage)
            };
            if (wo && a.ad_Storage === wo.ad_Storage && a.analytics_Storage === wo.analytics_Storage) return wo.source = a.source, vo(Io(wo)), void ho();
            wo = a, Po(!0);
            var r = Io(wo);
            if (!r.analytics_Storage && c.track) return c.track = !1, Do(!0), Yu(), void window.setTimeout(Ru, 250);
            lu() && r.analytics_Storage && (c.track = !0, Yo(Xo(), 1), Ro()), Eo(), vo(r), ho()
        }
    }

    function Io(t) {
        var e;
        return {
            source: null !== (e = t.source) && void 0 !== e ? e : 255,
            ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
            analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0
        }
    }

    function Co(t, e) {
        return void 0 === e && (e = "denied"), "string" == typeof t ? t.toLowerCase() : e
    }

    function Do(t) {
        void 0 === t && (t = !1), Lt("_clsk", "", 0), t && Lt("_clck", "", 0)
    }

    function Po(t) {
        void 0 === t && (t = !1),
            function(t, e) {
                void 0 === e && (e = !1);
                if (yo.length > 0)
                    for (var n = 0; n < yo.length; n++) {
                        var a = yo[n];
                        a.callback && (!a.called && !e || a.consentInfo && e) && (!a.wait || t) && (a.callback(mo, !c.lean, a.consentInfo ? wo : void 0), a.called = !0, a.recall || (yo.splice(n, 1), n--))
                    }
            }(c.lean ? 0 : 1, t)
    }

    function Ro() {
        if (mo && c.track) {
            var t = Math.round(Date.now()),
                e = c.upload && "string" == typeof c.upload ? c.upload.replace("https://", "") : "",
                n = c.lean ? 0 : 1;
            Lt("_clsk", [mo.sessionId, t, mo.pageNum, n, e].join(At), 1)
        }
    }

    function Yo(t, e) {
        void 0 === e && (e = null), e = null === e ? t.consent : e;
        var n = Math.ceil((Date.now() + 31536e6) / 864e5),
            a = 0 === t.dob ? null === c.dob ? 0 : c.dob : t.dob;
        (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && Lt("_clck", [mo.userId, 2, n.toString(36), e, a].join(At), 365)
    }

    function jo() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function Ao(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function Xo() {
        var t = {
                id: jo(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = Xt("_clck", !c.includeSubdomains);
        if (e && e.length > 0) {
            var n = e.includes("^") ? e.split("^") : e.split("|");
            n.length > 1 && (t.version = Ao(n[1])), n.length > 2 && (t.expiry = Ao(n[2], 36)), n.length > 3 && 1 === Ao(n[3]) && (t.consent = 1), n.length > 4 && Ao(n[1]) > 1 && (t.dob = Ao(n[4])), c.track = c.track || 1 === t.consent, t.id = c.track ? n[0] : t.id
        }
        return t
    }
    var Lo, zo = null;

    function Wo() {
        var t = mo;
        zo = {
            version: h,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function Ho() {
        zo = null
    }

    function qo(t) {
        return zo.start = zo.start + zo.duration, zo.duration = f() - zo.start, zo.sequence++, zo.upload = t && "sendBeacon" in navigator ? 1 : 0, zo.end = t ? 1 : 0, zo.applicationPlatform = 0, zo.url = k(location.href, !1, !0), [zo.version, zo.sequence, zo.start, zo.duration, zo.projectId, zo.userId, zo.sessionId, zo.pageNum, zo.upload, zo.end, zo.applicationPlatform, zo.url]
    }

    function Uo() {
        Lo = []
    }

    function Fo(t) {
        if (Lo && -1 === Lo.indexOf(t.message)) {
            var e = c.report;
            if (e && e.length > 0 && zo) {
                var n = {
                    v: zo.version,
                    p: zo.projectId,
                    u: zo.userId,
                    s: zo.sessionId,
                    n: zo.pageNum
                };
                t.message && (n.m = t.message), t.stack && (n.e = t.stack);
                var a = new XMLHttpRequest;
                a.open("POST", e, !0), a.send(JSON.stringify(n)), Lo.push(t.message)
            }
        }
        return t
    }

    function Vo(t) {
        return function() {
            var e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw Fo(t)
            }
            var n = performance.now() - e;
            U(4, n), n > 30 && (q(7), F(6, n), t.dn && ki(9, 0, "".concat(t.dn, "-").concat(n)))
        }
    }
    var Bo = new Map;

    function Ko(t, e, n, a, r) {
        void 0 === a && (a = !1), void 0 === r && (r = !0), n = Vo(n);
        try {
            t[s("addEventListener")](e, n, {
                capture: a,
                passive: r
            }), Zo(t) || Bo.set(t, []), Bo.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: r
                }
            })
        } catch (t) {}
    }

    function Jo() {
        Bo.forEach((function(t, e) {
            Qo(t, e)
        })), Bo = new Map
    }

    function Go(t) {
        Zo(t) && Qo(Bo.get(t), t)
    }

    function Zo(t) {
        return Bo.has(t)
    }

    function Qo(t, e) {
        t.forEach((function(t) {
            try {
                e[s("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), Bo.delete(e)
    }
    var $o = null,
        tu = null,
        eu = null,
        nu = 0;

    function au() {
        return !(nu++ > 20) || (ki(4, 0), !1)
    }

    function ru() {
        nu = 0, eu !== ou() && (Yu(), window.setTimeout(iu, 250))
    }

    function iu() {
        Ru(), F(29, 1)
    }

    function ou() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }
    var uu = !1;

    function cu() {
        uu = !0, l = d(), xi(), Jo(), Uo(),
            function() {
                if (eu = ou(), nu = 0, Ko(window, "popstate", ru), null === $o) try {
                    $o = history.pushState, history.pushState = function() {
                        $o.apply(this, arguments), lu() && au() && ru()
                    }
                } catch (t) {
                    $o = null
                }
                if (null === tu) try {
                    tu = history.replaceState, history.replaceState = function() {
                        tu.apply(this, arguments), lu() && au() && ru()
                    }
                } catch (t) {
                    tu = null
                }
            }()
    }

    function su() {
        eu = null, nu = 0, Uo(), Jo(), xi(), l = 0, uu = !1
    }

    function lu() {
        return uu
    }

    function du() {
        Ru(), L("clarity", "restart")
    }
    var fu = Object.freeze({
        __proto__: null,
        start: function() {
            ! function() {
                Bt = [], F(26, navigator.webdriver ? 1 : 0);
                try {
                    F(31, window.top == window.self || window.top == window ? 1 : 2)
                } catch (t) {
                    F(31, 0)
                }
            }(), Ko(window, "error", yi), mi = {}, Si = {}
        },
        stop: function() {
            Si = {}
        }
    });
    var hu = Object.freeze({
        __proto__: null,
        hashText: lr,
        start: function() {
            $n(), ta(), Dr(), Tr = null, Sr = new WeakMap, kr = {}, Or = [], Er = !!window.IntersectionObserver, Za(), c.delayDom ? Ko(window, "load", (function() {
                    fa()
                })) : fa(),
                function() {
                    var t;
                    try {
                        window.clarityOverrides = window.clarityOverrides || {}, (null === (t = window.customElements) || void 0 === t ? void 0 : t.define) && !window.clarityOverrides.define && (window.clarityOverrides.define = window.customElements.define, window.customElements.define = function() {
                            return lu() && Bn(arguments[0]), window.clarityOverrides.define.apply(this, arguments)
                        })
                    } catch (t) {}
                }(), Li(), _n(),
                function() {
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (zn(), Hn(Dn, "play"), Hn(Pn, "pause"), Hn(Rn, "commitStyles"), Hn(Yn, "cancel"), Hn(jn, "finish"), null === Cn && (Cn = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = Cn.apply(this, arguments);
                            return qn(t, "play"), t
                        }), document.getAnimations))
                        for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
                            var n = e[t];
                            "finished" === n.playState ? qn(n, "finish") : "paused" === n.playState || "idle" === n.playState ? qn(n, "pause") : "running" === n.playState && qn(n, "play")
                        }
                }()
        },
        stop: function() {
            Dr(), Sr = null, kr = {}, Or = [], Tr && (Tr.disconnect(), Tr = null), Er = !1, Qa(),
                function() {
                    for (var t = 0, e = Array.from(na); t < e.length; t++) {
                        var n = e[t];
                        n && n.disconnect()
                    }
                    na = new Set, sa = {}, aa = [], ra = {}, ia = [], ca = 0, oa = null, la = new WeakMap
                }(), $n(), Sn = {}, kn = {}, On = [], En = [], Nn(), zn(), Kn(), Vn.clear()
        }
    });
    var pu = null;

    function vu() {
        pu = null
    }

    function gu(t) {
        pu = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                it(this, void 0, void 0, (function() {
                    var e, n;
                    return ot(this, (function(a) {
                        return e = f(), n = [e, t], 29 === t && (n.push(pu.fetchStart), n.push(pu.connectStart), n.push(pu.connectEnd), n.push(pu.requestStart), n.push(pu.responseStart), n.push(pu.responseEnd), n.push(pu.domInteractive), n.push(pu.domComplete), n.push(pu.loadEventStart), n.push(pu.loadEventEnd), n.push(pu.redirectCount), n.push(pu.size), n.push(pu.type), n.push(pu.protocol), n.push(pu.encodedSize), n.push(pu.decodedSize), vu(), li(n)), [2]
                    }))
                }))
            }(29)
    }
    var mu, yu = 0,
        bu = 1 / 0,
        wu = 0,
        Su = 0,
        ku = [],
        Ou = new Map,
        Eu = function() {
            return yu || 0
        },
        Tu = function() {
            if (!ku.length) return -1;
            var t = Math.min(ku.length - 1, Math.floor((Eu() - Su) / 50));
            return ku[t].latency
        },
        _u = function() {
            Su = Eu(), ku.length = 0, Ou.clear()
        },
        Mu = function(t) {
            if (t.interactionId && !(t.duration < 40)) {
                ! function(t) {
                    "interactionCount" in performance ? yu = performance.interactionCount : t.interactionId && (bu = Math.min(bu, t.interactionId), wu = Math.max(wu, t.interactionId), yu = wu ? (wu - bu) / 7 + 1 : 0)
                }(t);
                var e = ku[ku.length - 1],
                    n = Ou.get(t.interactionId);
                if (n || ku.length < 10 || t.duration > (null == e ? void 0 : e.latency)) {
                    if (n) t.duration > n.latency && (n.latency = t.duration);
                    else {
                        var a = {
                            id: t.interactionId,
                            latency: t.duration
                        };
                        Ou.set(a.id, a), ku.push(a)
                    }
                    ku.sort((function(t, e) {
                        return e.latency - t.latency
                    })), ku.length > 10 && ku.splice(10).forEach((function(t) {
                        return Ou.delete(t.id)
                    }))
                }
            }
        },
        Nu = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"];

    function xu() {
        try {
            mu && mu.disconnect(), mu = new PerformanceObserver(Vo(Iu));
            for (var t = 0, e = Nu; t < e.length; t++) {
                var n = e[t];
                PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 && ("layout-shift" === n && U(9, 0), mu.observe({
                    type: n,
                    buffered: !0
                }))
            }
        } catch (t) {
            ki(3, 1)
        }
    }

    function Iu(t) {
        ! function(t) {
            for (var e = (!("visibilityState" in document) || "visible" === document.visibilityState), n = 0; n < t.length; n++) {
                var a = t[n];
                switch (a.entryType) {
                    case "navigation":
                        gu(a);
                        break;
                    case "resource":
                        var r = a.name;
                        ao(4, Du(r)), r !== c.upload && r !== c.fallback || F(28, a.duration);
                        break;
                    case "longtask":
                        q(7);
                        break;
                    case "first-input":
                        e && F(10, a.processingStart - a.startTime);
                        break;
                    case "event":
                        e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (Mu(a), ao(37, Tu().toString()));
                        break;
                    case "layout-shift":
                        e && !a.hadRecentInput && U(9, 1e3 * a.value);
                        break;
                    case "largest-contentful-paint":
                        e && F(8, a.startTime)
                }
            }
        }(t.getEntries())
    }
    var Cu = null;

    function Du(t) {
        return Cu || (Cu = document.createElement("a")), Cu.href = t, Cu.host
    }
    var Pu = [fu, hu, gn, Object.freeze({
        __proto__: null,
        start: function() {
            vu(),
                function() {
                    navigator && navigator.connection && ao(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? Ko(window, "load", V.bind(this, xu, 0)) : xu() : ki(3, 0)
                }()
        },
        stop: function() {
            mu && mu.disconnect(), mu = null, _u(), Cu = null, vu()
        }
    }), ai];

    function Ru(t) {
        void 0 === t && (t = null),
            function() {
                try {
                    var t = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === uu && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && !t
                } catch (t) {
                    return !1
                }
            }() && (! function(t) {
                if (null === t || uu) return !1;
                for (var e in t) e in c && (c[e] = t[e])
            }(t), cu(), qt(), Pu.forEach((function(t) {
                return Vo(t.start)()
            })), null === t && Lu())
    }

    function Yu() {
        lu() && (Pu.slice().reverse().forEach((function(t) {
            return Vo(t.stop)()
        })), Ut(), su(), void 0 !== Au && (Au[Xu] = function() {
            (Au[Xu].q = Au[Xu].q || []).push(arguments), "start" === arguments[0] && Au[Xu].q.unshift(Au[Xu].q.pop()) && Lu()
        }))
    }
    var ju = Object.freeze({
            __proto__: null,
            consent: No,
            consentv2: xo,
            dlog: ao,
            event: L,
            hashText: lr,
            identify: ft,
            maxMetric: F,
            measure: Vo,
            metadata: _o,
            pause: function() {
                lu() && (L("clarity", "pause"), null === Mi && (Mi = new Promise((function(t) {
                    Ni = t
                }))))
            },
            queue: li,
            register: Gr,
            resume: function() {
                lu() && (Mi && (Ni(), Mi = null, null === _i && Ci()), L("clarity", "resume"))
            },
            schedule: Ii,
            set: dt,
            signal: function(t) {
                zt = t
            },
            start: Ru,
            stop: Yu,
            time: f,
            upgrade: Ui,
            version: h
        }),
        Au = window,
        Xu = "clarity";

    function Lu() {
        if (void 0 !== Au) {
            if (Au[Xu] && Au[Xu].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = Au[Xu] && Au[Xu].q || [];
            for (Au[Xu] = function(t) {
                    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                    return ju[t].apply(ju, e)
                }, Au[Xu].v = h; t.length > 0;) Au[Xu].apply(Au, t.shift())
        }
    }
    Lu()
}();