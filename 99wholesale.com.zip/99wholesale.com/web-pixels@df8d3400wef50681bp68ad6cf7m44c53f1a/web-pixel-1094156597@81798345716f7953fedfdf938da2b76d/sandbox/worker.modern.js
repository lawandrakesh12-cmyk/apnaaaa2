importScripts('https://99wholesale.com/cdn/wpm/sdf8d3400wef50681bp68ad6cf7m44c53f1am.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('1094156597', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-1094156597@81798345716f7953fedfdf938da2b76d.js');