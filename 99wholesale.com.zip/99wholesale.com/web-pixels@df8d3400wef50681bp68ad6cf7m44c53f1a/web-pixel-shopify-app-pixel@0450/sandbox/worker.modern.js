importScripts('https://99wholesale.com/cdn/wpm/sdf8d3400wef50681bp68ad6cf7m44c53f1am.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('shopify-app-pixel', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-shopify-app-pixel@0450.js');