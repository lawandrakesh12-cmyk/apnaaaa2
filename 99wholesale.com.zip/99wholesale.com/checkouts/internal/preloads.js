(function() {
    var cdnOrigin = "https://cdn.shopify.com";
    var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.CgsWKOqO.js", "/cdn/shopifycloud/checkout-web/assets/c1/app.BgepeXY0.js", "/cdn/shopifycloud/checkout-web/assets/c1/vendor.CEwna6Mj.js", "/cdn/shopifycloud/checkout-web/assets/c1/browser.C6_VtRiV.js", "/cdn/shopifycloud/checkout-web/assets/c1/FullScreenBackground.BBFDt2zo.js", "/cdn/shopifycloud/checkout-web/assets/c1/shop-discount-offer.DeQM5uY5.js", "/cdn/shopifycloud/checkout-web/assets/c1/alternativePaymentCurrency.CnYi1kcS.js", "/cdn/shopifycloud/checkout-web/assets/c1/proposal.Sn3V3Bk9.js", "/cdn/shopifycloud/checkout-web/assets/c1/useHasOrdersFromMultipleShops.BDqqfiv5.js", "/cdn/shopifycloud/checkout-web/assets/c1/locale-en.Cvpq0CyL.js", "/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage.Cu25-Kzn.js", "/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons.DZ2k-qWL.js", "/cdn/shopifycloud/checkout-web/assets/c1/LocalPickup.B65-Tg8T.js", "/cdn/shopifycloud/checkout-web/assets/c1/MarketsProDisclaimer.DgO_axgw.js", "/cdn/shopifycloud/checkout-web/assets/c1/useForceShopPayUrl.CJxH-9Et.js", "/cdn/shopifycloud/checkout-web/assets/c1/ShopPayLogo.Cedd6fmC.js", "/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment.DhwoMeG-.js", "/cdn/shopifycloud/checkout-web/assets/c1/PendingShipping.h8cPa2N7.js", "/cdn/shopifycloud/checkout-web/assets/c1/PickupPointCarrierLogo.CJqbSMPL.js", "/cdn/shopifycloud/checkout-web/assets/c1/hooks.9dXtAwj2.js", "/cdn/shopifycloud/checkout-web/assets/c1/AddDiscountButton.CA2VJqXI.js", "/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText.CfF6qWSl.js", "/cdn/shopifycloud/checkout-web/assets/c1/ShopPayOptInDisclaimer.BhxnBxtP.js", "/cdn/shopifycloud/checkout-web/assets/c1/MobileOrderSummary.CzxCxRwV.js", "/cdn/shopifycloud/checkout-web/assets/c1/OrderEditVaultedDelivery.DOJGC7Y6.js", "/cdn/shopifycloud/checkout-web/assets/c1/SeparatePaymentsNotice.B7pBPxsW.js", "/cdn/shopifycloud/checkout-web/assets/c1/StockProblemsLineItemList.DNVjx0Gr.js", "/cdn/shopifycloud/checkout-web/assets/c1/flags.R5tqu7T9.js", "/cdn/shopifycloud/checkout-web/assets/c1/DutyOptions.DKRjcic9.js", "/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown.c9TvxP6V.js", "/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal.CX-s4zQ-.js"];
    var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.D7EkV1ZR.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/FullScreenBackground.B_iZlQze.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/useHasOrdersFromMultipleShops.BvnVxzyh.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.CKTqepKH.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/LocalPickup.BhtheElV.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/AddDiscountButton.CZ33y7Va.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/MobileOrderSummary.7lB-c-sA.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/ShopPayLogo.BrcQzLuH.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/DutyOptions.D6OuIVjc.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/VaultedPayment.OxMVm7u-.css", "/cdn/shopifycloud/checkout-web/assets/c1/assets/PickupPointCarrierLogo.DuZuWHqZ.css"];
    var fontPreconnectUrls = [];
    var fontPrefetchUrls = [];
    var imgPrefetchUrls = ["https://cdn.shopify.com/s/files/1/0925/0203/2693/files/99wholesale-logo_x320.jpg?v=1735970559"];

    function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
    }

    function preconnectAssets() {
        var resources = [cdnOrigin].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
            var res = resources[index++];
            if (res) preconnect(res, next);
        })();
    }

    function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
            link.rel = 'prefetch';
            link.fetchPriority = 'low';
            link.as = as;
            if (as === 'font') link.type = 'font/woff2';
            link.href = url;
            link.crossOrigin = '';
            link.onload = link.onerror = callback;
            document.head.appendChild(link);
        } else {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.onloadend = callback;
            xhr.send();
        }
    }

    function prefetchAssets() {
        var resources = [].concat(
            scripts.map(function(url) {
                return [url, 'script'];
            }),
            styles.map(function(url) {
                return [url, 'style'];
            }),
            fontPrefetchUrls.map(function(url) {
                return [url, 'font'];
            }),
            imgPrefetchUrls.map(function(url) {
                return [url, 'image'];
            })
        );
        var index = 0;

        function run() {
            var res = resources[index++];
            if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
    }

    function onLoaded() {
        try {
            if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
                preconnectAssets();
                prefetchAssets();
            }
        } catch (e) {}
    }

    if (document.readyState === 'complete') {
        onLoaded();
    } else {
        addEventListener('load', onLoaded);
    }
})();