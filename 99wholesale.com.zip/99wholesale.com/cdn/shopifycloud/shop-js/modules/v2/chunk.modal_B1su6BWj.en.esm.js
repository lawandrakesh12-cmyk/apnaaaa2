import {
    i as e,
    A as t,
    y as n,
    d as o,
    a as r,
    q as i,
    T as l,
    u as s,
    b as a,
    c,
    e as u,
    f as d,
    g as f,
    h as m,
    $ as p,
    F as h,
    j as g,
    P as v,
    k as y,
    D as w,
    l as x,
    m as b,
    n as T,
    o as E,
    p as R,
    r as L,
    s as O,
    t as _,
    S as C,
    v as M,
    I as D,
    w as P,
    _ as k,
    x as S,
    z as A,
    B as z
} from "./chunk.common_QsV4w3tJ.en.esm.js";
const I = Math.min,
    F = Math.max,
    j = Math.round,
    H = Math.floor,
    N = e => ({
        x: e,
        y: e
    }),
    V = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    },
    W = {
        start: "end",
        end: "start"
    };

function B(e, t, n) {
    return F(e, I(t, n))
}

function q(e, t) {
    return "function" == typeof e ? e(t) : e
}

function $(e) {
    return e.split("-")[0]
}

function U(e) {
    return e.split("-")[1]
}

function X(e) {
    return "x" === e ? "y" : "x"
}

function Y(e) {
    return "y" === e ? "height" : "width"
}

function Z(e) {
    return ["top", "bottom"].includes($(e)) ? "y" : "x"
}

function G(e) {
    return X(Z(e))
}

function J(e) {
    return e.replace(/start|end/g, (e => W[e]))
}

function K(e) {
    return e.replace(/left|right|bottom|top/g, (e => V[e]))
}

function Q(e) {
    return "number" != typeof e ? function(e) {
        return {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            ...e
        }
    }(e) : {
        top: e,
        right: e,
        bottom: e,
        left: e
    }
}

function ee(e) {
    const {
        x: t,
        y: n,
        width: o,
        height: r
    } = e;
    return {
        width: o,
        height: r,
        top: n,
        left: t,
        right: t + o,
        bottom: n + r,
        x: t,
        y: n
    }
}

function te(e, t, n) {
    let {
        reference: o,
        floating: r
    } = e;
    const i = Z(t),
        l = G(t),
        s = Y(l),
        a = $(t),
        c = "y" === i,
        u = o.x + o.width / 2 - r.width / 2,
        d = o.y + o.height / 2 - r.height / 2,
        f = o[s] / 2 - r[s] / 2;
    let m;
    switch (a) {
        case "top":
            m = {
                x: u,
                y: o.y - r.height
            };
            break;
        case "bottom":
            m = {
                x: u,
                y: o.y + o.height
            };
            break;
        case "right":
            m = {
                x: o.x + o.width,
                y: d
            };
            break;
        case "left":
            m = {
                x: o.x - r.width,
                y: d
            };
            break;
        default:
            m = {
                x: o.x,
                y: o.y
            }
    }
    switch (U(t)) {
        case "start":
            m[l] -= f * (n && c ? -1 : 1);
            break;
        case "end":
            m[l] += f * (n && c ? -1 : 1)
    }
    return m
}
async function ne(e, t) {
    var n;
    void 0 === t && (t = {});
    const {
        x: o,
        y: r,
        platform: i,
        rects: l,
        elements: s,
        strategy: a
    } = e, {
        boundary: c = "clippingAncestors",
        rootBoundary: u = "viewport",
        elementContext: d = "floating",
        altBoundary: f = !1,
        padding: m = 0
    } = q(t, e), p = Q(m), h = s[f ? "floating" === d ? "reference" : "floating" : d], g = ee(await i.getClippingRect({
        element: null == (n = await (null == i.isElement ? void 0 : i.isElement(h))) || n ? h : h.contextElement || await (null == i.getDocumentElement ? void 0 : i.getDocumentElement(s.floating)),
        boundary: c,
        rootBoundary: u,
        strategy: a
    })), v = "floating" === d ? {
        x: o,
        y: r,
        width: l.floating.width,
        height: l.floating.height
    } : l.reference, y = await (null == i.getOffsetParent ? void 0 : i.getOffsetParent(s.floating)), w = await (null == i.isElement ? void 0 : i.isElement(y)) && await (null == i.getScale ? void 0 : i.getScale(y)) || {
        x: 1,
        y: 1
    }, x = ee(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
        elements: s,
        rect: v,
        offsetParent: y,
        strategy: a
    }) : v);
    return {
        top: (g.top - x.top + p.top) / w.y,
        bottom: (x.bottom - g.bottom + p.bottom) / w.y,
        left: (g.left - x.left + p.left) / w.x,
        right: (x.right - g.right + p.right) / w.x
    }
}

function oe() {
    return "undefined" != typeof window
}

function re(e) {
    return se(e) ? (e.nodeName || "").toLowerCase() : "#document"
}

function ie(e) {
    var t;
    return (null == e || null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
}

function le(e) {
    var t;
    return null == (t = (se(e) ? e.ownerDocument : e.document) || window.document) ? void 0 : t.documentElement
}

function se(e) {
    return !!oe() && (e instanceof Node || e instanceof ie(e).Node)
}

function ae(e) {
    return !!oe() && (e instanceof Element || e instanceof ie(e).Element)
}

function ce(e) {
    return !!oe() && (e instanceof HTMLElement || e instanceof ie(e).HTMLElement)
}

function ue(e) {
    return !(!oe() || "undefined" == typeof ShadowRoot) && (e instanceof ShadowRoot || e instanceof ie(e).ShadowRoot)
}

function de(e) {
    const {
        overflow: t,
        overflowX: n,
        overflowY: o,
        display: r
    } = ve(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + o + n) && !["inline", "contents"].includes(r)
}

function fe(e) {
    return ["table", "td", "th"].includes(re(e))
}

function me(e) {
    return [":popover-open", ":modal"].some((t => {
        try {
            return e.matches(t)
        } catch (e) {
            return !1
        }
    }))
}

function pe(e) {
    const t = he(),
        n = ae(e) ? ve(e) : e;
    return ["transform", "translate", "scale", "rotate", "perspective"].some((e => !!n[e] && "none" !== n[e])) || !!n.containerType && "normal" !== n.containerType || !t && !!n.backdropFilter && "none" !== n.backdropFilter || !t && !!n.filter && "none" !== n.filter || ["transform", "translate", "scale", "rotate", "perspective", "filter"].some((e => (n.willChange || "").includes(e))) || ["paint", "layout", "strict", "content"].some((e => (n.contain || "").includes(e)))
}

function he() {
    return !("undefined" == typeof CSS || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none")
}

function ge(e) {
    return ["html", "body", "#document"].includes(re(e))
}

function ve(e) {
    return ie(e).getComputedStyle(e)
}

function ye(e) {
    return ae(e) ? {
        scrollLeft: e.scrollLeft,
        scrollTop: e.scrollTop
    } : {
        scrollLeft: e.scrollX,
        scrollTop: e.scrollY
    }
}

function we(e) {
    if ("html" === re(e)) return e;
    const t = e.assignedSlot || e.parentNode || ue(e) && e.host || le(e);
    return ue(t) ? t.host : t
}

function xe(e) {
    const t = we(e);
    return ge(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : ce(t) && de(t) ? t : xe(t)
}

function be(e, t, n) {
    var o;
    void 0 === t && (t = []), void 0 === n && (n = !0);
    const r = xe(e),
        i = r === (null == (o = e.ownerDocument) ? void 0 : o.body),
        l = ie(r);
    if (i) {
        const e = Te(l);
        return t.concat(l, l.visualViewport || [], de(r) ? r : [], e && n ? be(e) : [])
    }
    return t.concat(r, be(r, [], n))
}

function Te(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null
}

function Ee(e) {
    const t = ve(e);
    let n = parseFloat(t.width) || 0,
        o = parseFloat(t.height) || 0;
    const r = ce(e),
        i = r ? e.offsetWidth : n,
        l = r ? e.offsetHeight : o,
        s = j(n) !== i || j(o) !== l;
    return s && (n = i, o = l), {
        width: n,
        height: o,
        $: s
    }
}

function Re(e) {
    return ae(e) ? e : e.contextElement
}

function Le(e) {
    const t = Re(e);
    if (!ce(t)) return N(1);
    const n = t.getBoundingClientRect(),
        {
            width: o,
            height: r,
            $: i
        } = Ee(t);
    let l = (i ? j(n.width) : n.width) / o,
        s = (i ? j(n.height) : n.height) / r;
    return l && Number.isFinite(l) || (l = 1), s && Number.isFinite(s) || (s = 1), {
        x: l,
        y: s
    }
}
const Oe = N(0);

function _e(e) {
    const t = ie(e);
    return he() && t.visualViewport ? {
        x: t.visualViewport.offsetLeft,
        y: t.visualViewport.offsetTop
    } : Oe
}

function Ce(e, t, n, o) {
    void 0 === t && (t = !1), void 0 === n && (n = !1);
    const r = e.getBoundingClientRect(),
        i = Re(e);
    let l = N(1);
    t && (o ? ae(o) && (l = Le(o)) : l = Le(e));
    const s = function(e, t, n) {
        return void 0 === t && (t = !1), !(!n || t && n !== ie(e)) && t
    }(i, n, o) ? _e(i) : N(0);
    let a = (r.left + s.x) / l.x,
        c = (r.top + s.y) / l.y,
        u = r.width / l.x,
        d = r.height / l.y;
    if (i) {
        const e = ie(i),
            t = o && ae(o) ? ie(o) : o;
        let n = e,
            r = Te(n);
        for (; r && o && t !== n;) {
            const e = Le(r),
                t = r.getBoundingClientRect(),
                o = ve(r),
                i = t.left + (r.clientLeft + parseFloat(o.paddingLeft)) * e.x,
                l = t.top + (r.clientTop + parseFloat(o.paddingTop)) * e.y;
            a *= e.x, c *= e.y, u *= e.x, d *= e.y, a += i, c += l, n = ie(r), r = Te(n)
        }
    }
    return ee({
        width: u,
        height: d,
        x: a,
        y: c
    })
}

function Me(e, t) {
    const n = ye(e).scrollLeft;
    return t ? t.left + n : Ce(le(e)).left + n
}

function De(e, t, n) {
    void 0 === n && (n = !1);
    const o = e.getBoundingClientRect();
    return {
        x: o.left + t.scrollLeft - (n ? 0 : Me(e, o)),
        y: o.top + t.scrollTop
    }
}

function Pe(e, t, n) {
    let o;
    if ("viewport" === t) o = function(e, t) {
        const n = ie(e),
            o = le(e),
            r = n.visualViewport;
        let i = o.clientWidth,
            l = o.clientHeight,
            s = 0,
            a = 0;
        if (r) {
            i = r.width, l = r.height;
            const e = he();
            (!e || e && "fixed" === t) && (s = r.offsetLeft, a = r.offsetTop)
        }
        return {
            width: i,
            height: l,
            x: s,
            y: a
        }
    }(e, n);
    else if ("document" === t) o = function(e) {
        const t = le(e),
            n = ye(e),
            o = e.ownerDocument.body,
            r = F(t.scrollWidth, t.clientWidth, o.scrollWidth, o.clientWidth),
            i = F(t.scrollHeight, t.clientHeight, o.scrollHeight, o.clientHeight);
        let l = -n.scrollLeft + Me(e);
        const s = -n.scrollTop;
        return "rtl" === ve(o).direction && (l += F(t.clientWidth, o.clientWidth) - r), {
            width: r,
            height: i,
            x: l,
            y: s
        }
    }(le(e));
    else if (ae(t)) o = function(e, t) {
        const n = Ce(e, !0, "fixed" === t),
            o = n.top + e.clientTop,
            r = n.left + e.clientLeft,
            i = ce(e) ? Le(e) : N(1);
        return {
            width: e.clientWidth * i.x,
            height: e.clientHeight * i.y,
            x: r * i.x,
            y: o * i.y
        }
    }(t, n);
    else {
        const n = _e(e);
        o = {
            x: t.x - n.x,
            y: t.y - n.y,
            width: t.width,
            height: t.height
        }
    }
    return ee(o)
}

function ke(e, t) {
    const n = we(e);
    return !(n === t || !ae(n) || ge(n)) && ("fixed" === ve(n).position || ke(n, t))
}

function Se(e, t, n) {
    const o = ce(t),
        r = le(t),
        i = "fixed" === n,
        l = Ce(e, !0, i, t);
    let s = {
        scrollLeft: 0,
        scrollTop: 0
    };
    const a = N(0);
    if (o || !o && !i)
        if (("body" !== re(t) || de(r)) && (s = ye(t)), o) {
            const e = Ce(t, !0, i, t);
            a.x = e.x + t.clientLeft, a.y = e.y + t.clientTop
        } else r && (a.x = Me(r));
    const c = !r || o || i ? N(0) : De(r, s);
    return {
        x: l.left + s.scrollLeft - a.x - c.x,
        y: l.top + s.scrollTop - a.y - c.y,
        width: l.width,
        height: l.height
    }
}

function Ae(e) {
    return "static" === ve(e).position
}

function ze(e, t) {
    if (!ce(e) || "fixed" === ve(e).position) return null;
    if (t) return t(e);
    let n = e.offsetParent;
    return le(e) === n && (n = n.ownerDocument.body), n
}

function Ie(e, t) {
    const n = ie(e);
    if (me(e)) return n;
    if (!ce(e)) {
        let t = we(e);
        for (; t && !ge(t);) {
            if (ae(t) && !Ae(t)) return t;
            t = we(t)
        }
        return n
    }
    let o = ze(e, t);
    for (; o && fe(o) && Ae(o);) o = ze(o, t);
    return o && ge(o) && Ae(o) && !pe(o) ? n : o || function(e) {
        let t = we(e);
        for (; ce(t) && !ge(t);) {
            if (pe(t)) return t;
            if (me(t)) return null;
            t = we(t)
        }
        return null
    }(e) || n
}
const Fe = {
    convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
        let {
            elements: t,
            rect: n,
            offsetParent: o,
            strategy: r
        } = e;
        const i = "fixed" === r,
            l = le(o),
            s = !!t && me(t.floating);
        if (o === l || s && i) return n;
        let a = {
                scrollLeft: 0,
                scrollTop: 0
            },
            c = N(1);
        const u = N(0),
            d = ce(o);
        if ((d || !d && !i) && (("body" !== re(o) || de(l)) && (a = ye(o)), ce(o))) {
            const e = Ce(o);
            c = Le(o), u.x = e.x + o.clientLeft, u.y = e.y + o.clientTop
        }
        const f = !l || d || i ? N(0) : De(l, a, !0);
        return {
            width: n.width * c.x,
            height: n.height * c.y,
            x: n.x * c.x - a.scrollLeft * c.x + u.x + f.x,
            y: n.y * c.y - a.scrollTop * c.y + u.y + f.y
        }
    },
    getDocumentElement: le,
    getClippingRect: function(e) {
        let {
            element: t,
            boundary: n,
            rootBoundary: o,
            strategy: r
        } = e;
        const i = [..."clippingAncestors" === n ? me(t) ? [] : function(e, t) {
                const n = t.get(e);
                if (n) return n;
                let o = be(e, [], !1).filter((e => ae(e) && "body" !== re(e))),
                    r = null;
                const i = "fixed" === ve(e).position;
                let l = i ? we(e) : e;
                for (; ae(l) && !ge(l);) {
                    const t = ve(l),
                        n = pe(l);
                    n || "fixed" !== t.position || (r = null), (i ? !n && !r : !n && "static" === t.position && r && ["absolute", "fixed"].includes(r.position) || de(l) && !n && ke(e, l)) ? o = o.filter((e => e !== l)) : r = t, l = we(l)
                }
                return t.set(e, o), o
            }(t, this._c) : [].concat(n), o],
            l = i[0],
            s = i.reduce(((e, n) => {
                const o = Pe(t, n, r);
                return e.top = F(o.top, e.top), e.right = I(o.right, e.right), e.bottom = I(o.bottom, e.bottom), e.left = F(o.left, e.left), e
            }), Pe(t, l, r));
        return {
            width: s.right - s.left,
            height: s.bottom - s.top,
            x: s.left,
            y: s.top
        }
    },
    getOffsetParent: Ie,
    getElementRects: async function(e) {
        const t = this.getOffsetParent || Ie,
            n = this.getDimensions,
            o = await n(e.floating);
        return {
            reference: Se(e.reference, await t(e.floating), e.strategy),
            floating: {
                x: 0,
                y: 0,
                width: o.width,
                height: o.height
            }
        }
    },
    getClientRects: function(e) {
        return Array.from(e.getClientRects())
    },
    getDimensions: function(e) {
        const {
            width: t,
            height: n
        } = Ee(e);
        return {
            width: t,
            height: n
        }
    },
    getScale: Le,
    isElement: ae,
    isRTL: function(e) {
        return "rtl" === ve(e).direction
    }
};

function je(e, t) {
    return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height
}

function He(e, t, n, o) {
    void 0 === o && (o = {});
    const {
        ancestorScroll: r = !0,
        ancestorResize: i = !0,
        elementResize: l = "function" == typeof ResizeObserver,
        layoutShift: s = "function" == typeof IntersectionObserver,
        animationFrame: a = !1
    } = o, c = Re(e), u = r || i ? [...c ? be(c) : [], ...be(t)] : [];
    u.forEach((e => {
        r && e.addEventListener("scroll", n, {
            passive: !0
        }), i && e.addEventListener("resize", n)
    }));
    const d = c && s ? function(e, t) {
        let n, o = null;
        const r = le(e);

        function i() {
            var e;
            clearTimeout(n), null == (e = o) || e.disconnect(), o = null
        }
        return function l(s, a) {
            void 0 === s && (s = !1), void 0 === a && (a = 1), i();
            const c = e.getBoundingClientRect(),
                {
                    left: u,
                    top: d,
                    width: f,
                    height: m
                } = c;
            if (s || t(), !f || !m) return;
            const p = {
                rootMargin: -H(d) + "px " + -H(r.clientWidth - (u + f)) + "px " + -H(r.clientHeight - (d + m)) + "px " + -H(u) + "px",
                threshold: F(0, I(1, a)) || 1
            };
            let h = !0;

            function g(t) {
                const o = t[0].intersectionRatio;
                if (o !== a) {
                    if (!h) return l();
                    o ? l(!1, o) : n = setTimeout((() => {
                        l(!1, 1e-7)
                    }), 1e3)
                }
                1 !== o || je(c, e.getBoundingClientRect()) || l(), h = !1
            }
            try {
                o = new IntersectionObserver(g, { ...p,
                    root: r.ownerDocument
                })
            } catch (e) {
                o = new IntersectionObserver(g, p)
            }
            o.observe(e)
        }(!0), i
    }(c, n) : null;
    let f, m = -1,
        p = null;
    l && (p = new ResizeObserver((e => {
        let [o] = e;
        o && o.target === c && p && (p.unobserve(t), cancelAnimationFrame(m), m = requestAnimationFrame((() => {
            var e;
            null == (e = p) || e.observe(t)
        }))), n()
    })), c && !a && p.observe(c), p.observe(t));
    let h = a ? Ce(e) : null;
    return a && function t() {
        const o = Ce(e);
        h && !je(h, o) && n();
        h = o, f = requestAnimationFrame(t)
    }(), n(), () => {
        var e;
        u.forEach((e => {
            r && e.removeEventListener("scroll", n), i && e.removeEventListener("resize", n)
        })), null == d || d(), null == (e = p) || e.disconnect(), p = null, a && cancelAnimationFrame(f)
    }
}
const Ne = function(e) {
        return void 0 === e && (e = 0), {
            name: "offset",
            options: e,
            async fn(t) {
                var n, o;
                const {
                    x: r,
                    y: i,
                    placement: l,
                    middlewareData: s
                } = t, a = await async function(e, t) {
                    const {
                        placement: n,
                        platform: o,
                        elements: r
                    } = e, i = await (null == o.isRTL ? void 0 : o.isRTL(r.floating)), l = $(n), s = U(n), a = "y" === Z(n), c = ["left", "top"].includes(l) ? -1 : 1, u = i && a ? -1 : 1, d = q(t, e);
                    let {
                        mainAxis: f,
                        crossAxis: m,
                        alignmentAxis: p
                    } = "number" == typeof d ? {
                        mainAxis: d,
                        crossAxis: 0,
                        alignmentAxis: null
                    } : {
                        mainAxis: 0,
                        crossAxis: 0,
                        alignmentAxis: null,
                        ...d
                    };
                    return s && "number" == typeof p && (m = "end" === s ? -1 * p : p), a ? {
                        x: m * u,
                        y: f * c
                    } : {
                        x: f * c,
                        y: m * u
                    }
                }(t, e);
                return l === (null == (n = s.offset) ? void 0 : n.placement) && null != (o = s.arrow) && o.alignmentOffset ? {} : {
                    x: r + a.x,
                    y: i + a.y,
                    data: { ...a,
                        placement: l
                    }
                }
            }
        }
    },
    Ve = function(e) {
        return void 0 === e && (e = {}), {
            name: "shift",
            options: e,
            async fn(t) {
                const {
                    x: n,
                    y: o,
                    placement: r
                } = t, {
                    mainAxis: i = !0,
                    crossAxis: l = !1,
                    limiter: s = {
                        fn: e => {
                            let {
                                x: t,
                                y: n
                            } = e;
                            return {
                                x: t,
                                y: n
                            }
                        }
                    },
                    ...a
                } = q(e, t), c = {
                    x: n,
                    y: o
                }, u = await ne(t, a), d = Z($(r)), f = X(d);
                let m = c[f],
                    p = c[d];
                if (i) {
                    const e = "y" === f ? "bottom" : "right";
                    m = B(m + u["y" === f ? "top" : "left"], m, m - u[e])
                }
                if (l) {
                    const e = "y" === d ? "bottom" : "right";
                    p = B(p + u["y" === d ? "top" : "left"], p, p - u[e])
                }
                const h = s.fn({ ...t,
                    [f]: m,
                    [d]: p
                });
                return { ...h,
                    data: {
                        x: h.x - n,
                        y: h.y - o
                    }
                }
            }
        }
    },
    We = function(e) {
        return void 0 === e && (e = {}), {
            name: "flip",
            options: e,
            async fn(t) {
                var n, o;
                const {
                    placement: r,
                    middlewareData: i,
                    rects: l,
                    initialPlacement: s,
                    platform: a,
                    elements: c
                } = t, {
                    mainAxis: u = !0,
                    crossAxis: d = !0,
                    fallbackPlacements: f,
                    fallbackStrategy: m = "bestFit",
                    fallbackAxisSideDirection: p = "none",
                    flipAlignment: h = !0,
                    ...g
                } = q(e, t);
                if (null != (n = i.arrow) && n.alignmentOffset) return {};
                const v = $(r),
                    y = Z(s),
                    w = $(s) === s,
                    x = await (null == a.isRTL ? void 0 : a.isRTL(c.floating)),
                    b = f || (w || !h ? [K(s)] : function(e) {
                        const t = K(e);
                        return [J(e), t, J(t)]
                    }(s)),
                    T = "none" !== p;
                !f && T && b.push(... function(e, t, n, o) {
                    const r = U(e);
                    let i = function(e, t, n) {
                        const o = ["left", "right"],
                            r = ["right", "left"],
                            i = ["top", "bottom"],
                            l = ["bottom", "top"];
                        switch (e) {
                            case "top":
                            case "bottom":
                                return n ? t ? r : o : t ? o : r;
                            case "left":
                            case "right":
                                return t ? i : l;
                            default:
                                return []
                        }
                    }($(e), "start" === n, o);
                    return r && (i = i.map((e => e + "-" + r)), t && (i = i.concat(i.map(J)))), i
                }(s, h, p, x));
                const E = [s, ...b],
                    R = await ne(t, g),
                    L = [];
                let O = (null == (o = i.flip) ? void 0 : o.overflows) || [];
                if (u && L.push(R[v]), d) {
                    const e = function(e, t, n) {
                        void 0 === n && (n = !1);
                        const o = U(e),
                            r = G(e),
                            i = Y(r);
                        let l = "x" === r ? o === (n ? "end" : "start") ? "right" : "left" : "start" === o ? "bottom" : "top";
                        return t.reference[i] > t.floating[i] && (l = K(l)), [l, K(l)]
                    }(r, l, x);
                    L.push(R[e[0]], R[e[1]])
                }
                if (O = [...O, {
                        placement: r,
                        overflows: L
                    }], !L.every((e => e <= 0))) {
                    var _, C;
                    const e = ((null == (_ = i.flip) ? void 0 : _.index) || 0) + 1,
                        t = E[e];
                    if (t) return {
                        data: {
                            index: e,
                            overflows: O
                        },
                        reset: {
                            placement: t
                        }
                    };
                    let n = null == (C = O.filter((e => e.overflows[0] <= 0)).sort(((e, t) => e.overflows[1] - t.overflows[1]))[0]) ? void 0 : C.placement;
                    if (!n) switch (m) {
                        case "bestFit":
                            {
                                var M;
                                const e = null == (M = O.filter((e => {
                                    if (T) {
                                        const t = Z(e.placement);
                                        return t === y || "y" === t
                                    }
                                    return !0
                                })).map((e => [e.placement, e.overflows.filter((e => e > 0)).reduce(((e, t) => e + t), 0)])).sort(((e, t) => e[1] - t[1]))[0]) ? void 0 : M[0];e && (n = e);
                                break
                            }
                        case "initialPlacement":
                            n = s
                    }
                    if (r !== n) return {
                        reset: {
                            placement: n
                        }
                    }
                }
                return {}
            }
        }
    },
    Be = e => ({
        name: "arrow",
        options: e,
        async fn(t) {
            const {
                x: n,
                y: o,
                placement: r,
                rects: i,
                platform: l,
                elements: s,
                middlewareData: a
            } = t, {
                element: c,
                padding: u = 0
            } = q(e, t) || {};
            if (null == c) return {};
            const d = Q(u),
                f = {
                    x: n,
                    y: o
                },
                m = G(r),
                p = Y(m),
                h = await l.getDimensions(c),
                g = "y" === m,
                v = g ? "top" : "left",
                y = g ? "bottom" : "right",
                w = g ? "clientHeight" : "clientWidth",
                x = i.reference[p] + i.reference[m] - f[m] - i.floating[p],
                b = f[m] - i.reference[m],
                T = await (null == l.getOffsetParent ? void 0 : l.getOffsetParent(c));
            let E = T ? T[w] : 0;
            E && await (null == l.isElement ? void 0 : l.isElement(T)) || (E = s.floating[w] || i.floating[p]);
            const R = x / 2 - b / 2,
                L = E / 2 - h[p] / 2 - 1,
                O = I(d[v], L),
                _ = I(d[y], L),
                C = O,
                M = E - h[p] - _,
                D = E / 2 - h[p] / 2 + R,
                P = B(C, D, M),
                k = !a.arrow && null != U(r) && D !== P && i.reference[p] / 2 - (D < C ? O : _) - h[p] / 2 < 0,
                S = k ? D < C ? D - C : D - M : 0;
            return {
                [m]: f[m] + S,
                data: {
                    [m]: P,
                    centerOffset: D - P - S,
                    ...k && {
                        alignmentOffset: S
                    }
                },
                reset: k
            }
        }
    }),
    qe = (e, t, n) => {
        const o = new Map,
            r = {
                platform: Fe,
                ...n
            },
            i = { ...r.platform,
                _c: o
            };
        return (async (e, t, n) => {
            const {
                placement: o = "bottom",
                strategy: r = "absolute",
                middleware: i = [],
                platform: l
            } = n, s = i.filter(Boolean), a = await (null == l.isRTL ? void 0 : l.isRTL(t));
            let c = await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: r
                }),
                {
                    x: u,
                    y: d
                } = te(c, o, a),
                f = o,
                m = {},
                p = 0;
            for (let n = 0; n < s.length; n++) {
                const {
                    name: i,
                    fn: h
                } = s[n], {
                    x: g,
                    y: v,
                    data: y,
                    reset: w
                } = await h({
                    x: u,
                    y: d,
                    initialPlacement: o,
                    placement: f,
                    strategy: r,
                    middlewareData: m,
                    rects: c,
                    platform: l,
                    elements: {
                        reference: e,
                        floating: t
                    }
                });
                u = null != g ? g : u, d = null != v ? v : d, m = { ...m,
                    [i]: { ...m[i],
                        ...y
                    }
                }, w && p <= 50 && (p++, "object" == typeof w && (w.placement && (f = w.placement), w.rects && (c = !0 === w.rects ? await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: r
                }) : w.rects), ({
                    x: u,
                    y: d
                } = te(c, f, a))), n = -1)
            }
            return {
                x: u,
                y: d,
                placement: f,
                strategy: r,
                middlewareData: m
            }
        })(e, t, { ...r,
            platform: i
        })
    };

function $e(t) {
    return (t.ownerDocument.defaultView || e).devicePixelRatio || 1
}

function Ue(e, t) {
    const n = $e(e);
    return Math.round(t * n) / n
}

function Xe(e) {
    const o = t(e);
    return n((() => {
        o.current = e
    })), o
}
const Ye = ["right", "left", "bottom", "top"],
    Ze = ({
        anchorTo: y,
        children: w,
        headerLogo: x,
        headerTitle: b,
        hideHeader: T = !1,
        disableMinWidth: E = !1,
        key: R,
        modalTitle: L = "Sign in with Shop",
        onDismiss: O,
        onModalInViewport: _,
        popupDisabled: C,
        type: M,
        variant: D,
        visible: P
    }) => {
        var k, S, A;
        const {
            dispatch: z,
            modalDismissible: I
        } = s(), F = t(null), [j, H] = o(null), N = t(null), V = t(null), W = t(null), [B, q] = o(!1), {
            instanceId: $
        } = a(), U = t(null), {
            floatingStyles: X,
            middlewareData: Y,
            refs: Z,
            update: G
        } = function(e = {}) {
            const {
                placement: s = "bottom",
                strategy: a = "absolute",
                middleware: c = [],
                platform: u,
                elements: {
                    reference: d,
                    floating: f
                } = {},
                transform: m = !0,
                whileElementsMounted: p,
                open: h
            } = e, [g, v] = o({
                x: 0,
                y: 0,
                strategy: a,
                placement: s,
                middlewareData: {},
                isPositioned: !1
            }), [y, w] = o(c);
            r(y, c) || w(c);
            const [x, b] = o(null), [T, E] = o(null), R = i((e => {
                e !== C.current && (C.current = e, b(e))
            }), []), L = i((e => {
                e !== M.current && (M.current = e, E(e))
            }), []), O = d || x, _ = f || T, C = t(null), M = t(null), D = t(g), P = null != p, k = Xe(p), S = Xe(u), A = i((() => {
                if (!C.current || !M.current) return;
                const e = {
                    placement: s,
                    strategy: a,
                    middleware: y
                };
                S.current && (e.platform = S.current), qe(C.current, M.current, e).then((e => {
                    const t = Object.assign(Object.assign({}, e), {
                        isPositioned: !0
                    });
                    z.current && !r(D.current, t) && (D.current = t, v(t))
                })).catch((e => {
                    console.error("error caught during computePosition", e)
                }))
            }), [y, s, a, S]);
            n((() => {
                !1 === h && D.current.isPositioned && (D.current.isPositioned = !1, v((e => Object.assign(Object.assign({}, e), {
                    isPositioned: !1
                }))))
            }), [h]);
            const z = t(!1);
            n((() => (z.current = !0, () => {
                z.current = !1
            })), []), n((() => {
                if (O && (C.current = O), _ && (M.current = _), O && _) {
                    if (k.current) return k.current(O, _, A);
                    A()
                }
            }), [O, _, A, k, P]);
            const I = l((() => ({
                    reference: C,
                    floating: M,
                    setReference: R,
                    setFloating: L
                })), [R, L]),
                F = l((() => ({
                    reference: O,
                    floating: _
                })), [O, _]),
                j = l((() => {
                    const e = {
                        position: a,
                        left: 0,
                        top: 0
                    };
                    if (!F.floating) return e;
                    const t = Ue(F.floating, g.x),
                        n = Ue(F.floating, g.y);
                    return m ? Object.assign(Object.assign(Object.assign({}, e), {
                        transform: `translate(${t}px, ${n}px)`
                    }), $e(F.floating) >= 1.5 && {
                        willChange: "transform"
                    }) : {
                        position: a,
                        left: t,
                        top: n
                    }
                }), [a, m, F.floating, g.x, g.y]);
            return l((() => Object.assign(Object.assign({}, g), {
                update: A,
                refs: I,
                elements: F,
                floatingStyles: j
            })), [g, A, I, F, j])
        }({
            middleware: [We({
                crossAxis: !1,
                fallbackPlacements: Ye.slice(1)
            }), Ve({
                padding: 30
            }), Ne(30), (J = {
                element: N,
                padding: 28
            }, {
                name: "arrow",
                options: J,
                fn(e) {
                    const {
                        element: t,
                        padding: n
                    } = J;
                    return t && (o = t, {}.hasOwnProperty.call(o, "current")) ? null != t.current ? Be({
                        element: t.current,
                        padding: n
                    }).fn(e) : {} : t ? Be({
                        element: t,
                        padding: n
                    }).fn(e) : {};
                    var o
                }
            })],
            placement: Ye[0],
            whileElementsMounted: He
        });
        var J;
        n((() => {
            if (y) {
                let e;
                e = "string" == typeof y ? c.querySelector(y) : y.current, H(e), Z.setReference(e), G()
            }
        }), [y, Z, G]), null === U.current && (U.current = c.documentElement.style.overflow), !V.current && u() && (V.current = new IntersectionObserver((t => {
            for (const n of t) {
                n.boundingClientRect.top < 0 && e.scrollTo({
                    top: 0,
                    left: 0
                }), n.isIntersecting && (null == _ || _())
            }
        }))), !F.current && u() && (F.current = new IntersectionObserver((t => {
            var n;
            for (const o of t) {
                if (o.boundingClientRect.top < 0 && e.scrollTo({
                        top: 0,
                        left: 0
                    }), !o.isIntersecting && o.target.offsetTop) {
                    const t = ((null == j ? void 0 : j.offsetHeight) || 0) + ((null === (n = W.current) || void 0 === n ? void 0 : n.offsetHeight) || 0) / 2 + 30;
                    e.scrollTo({
                        top: o.target.offsetTop - t
                    })
                }
            }
        }))), n((() => () => {
            V.current && V.current.disconnect(), F.current && F.current.disconnect()
        }), []);
        const {
            isDesktop: K
        } = d(), Q = l((() => j && !C && K ? "dynamic" : "center"), [j, K, C]);
        n((() => {
            const e = c.documentElement,
                t = null == e ? void 0 : e.style.overflow;
            return () => {
                t && e ? e.style.overflow = t : e.style.removeProperty("overflow")
            }
        }), []);
        const ee = i((e => {
            I && (O(e), c.documentElement.style.overflow = U.current || "")
        }), [I, O]);
        n((() => {
            function t({
                key: e
            }) {
                "Escape" !== e && "Esc" !== e || ee("keyboard")
            }
            return e.addEventListener("keydown", t), () => {
                e.removeEventListener("keydown", t)
            }
        }), [ee]), n((() => {
            P ? (c.documentElement.style.overflow = "hidden", V.current && W.current && V.current.observe(W.current), F.current && j && F.current.observe(j)) : (V.current && W.current && V.current.unobserve(W.current), F.current && j && F.current.unobserve(j), c.documentElement.style.overflow = U.current || "")
        }), [j, ee, P]), n((() => {
            var e;
            if (!P) return void q(!1);
            const t = () => {
                q(!0)
            };
            return null === (e = W.current) || void 0 === e || e.addEventListener("transitionend", t, {
                once: !0
            }), () => {
                var e;
                null === (e = W.current) || void 0 === e || e.removeEventListener("transitionend", t)
            }
        }), [P]), n((() => {
            if (P) {
                const e = setTimeout((() => {
                    z({
                        type: "modalDismissible"
                    })
                }), 400);
                return () => {
                    clearTimeout(e)
                }
            }
        }), [z, P]);
        const te = f("fixed inset-0 z-10 bg-overlay transition-opacity duration-400 ease-cubic-modal motion-reduce_duration-0", P ? "opacity-100" : "opacity-0"),
            ne = f("fixed inset-0 z-max overflow-hidden", "center" === Q && "flex items-center justify-center", P ? "visible" : "pointer-events-none invisible");
        let oe = "";
        "checkoutModal" === D && (oe = "wide" === M ? "max-w-100 sm_max-w-none" : "max-w-85 sm_max-w-none");
        const re = f("relative z-50 bg-white transition duration-400 ease-cubic-modal will-change-transform focus_outline-none focus_outline-0 motion-reduce_duration-0 sm_absolute sm_inset-x-0 sm_bottom-0 sm_top-auto sm_rounded-b-none", P ? "opacity-100 sm_translate-y-0" : "opacity-0 sm_translate-y-full", "dynamic" === Q && P ? "scale-100" : "", "dynamic" !== Q || P ? "" : "scale-0 sm_scale-100", !E && ("wide" === M ? "min-w-100" : "min-w-85"), oe, !T && "rounded-xxl", !K && "max-h-full"),
            ie = l((() => {
                if (K) return {};
                let e = "calc(100vh - env(safe-area-inset-bottom, 0) - env(safe-area-inset-top, 0))";
                return "webkitTouchCallout" in c.documentElement.style && (e = "-webkit-fill-available"), {
                    maxHeight: e
                }
            }), [K]),
            le = f("relative flex flex-col sm_rounded-b-none"),
            se = f("flex-1 overflow-y-auto", K && "rounded-xxl"),
            ae = l((() => {
                var e, t, n, o, r, i, l, s;
                if ("center" === Q) return null;
                const a = {
                        right: {
                            top: null === (e = Y.arrow) || void 0 === e ? void 0 : e.y,
                            left: (null === (t = Y.arrow) || void 0 === t ? void 0 : t.x) || "-10px"
                        },
                        left: {
                            top: null === (n = Y.arrow) || void 0 === n ? void 0 : n.y,
                            right: (null === (o = Y.arrow) || void 0 === o ? void 0 : o.x) || "-10px"
                        },
                        bottom: {
                            top: "-10px",
                            left: (null === (r = Y.arrow) || void 0 === r ? void 0 : r.x) || "-10px"
                        },
                        top: {
                            bottom: "-10px",
                            left: (null === (i = Y.arrow) || void 0 === i ? void 0 : i.x) || "-10px"
                        }
                    },
                    c = Ye[(null === (s = null === (l = Y.flip) || void 0 === l ? void 0 : l.overflows) || void 0 === s ? void 0 : s.length) || 0],
                    u = a[c],
                    d = f("absolute z-30 block size-6 rotate-45 rounded-xs duration-400 ease-cubic-modal sm_hidden", "top" === c ? "bg-grayscale-l4" : "bg-white");
                return m("div", {
                    className: d,
                    "data-testid": "authorize-modal-arrow",
                    ref: N,
                    style: u
                })
            }), [null === (k = Y.arrow) || void 0 === k ? void 0 : k.x, null === (S = Y.arrow) || void 0 === S ? void 0 : S.y, null === (A = Y.flip) || void 0 === A ? void 0 : A.overflows, Q]),
            ce = "dynamic" === Q ? X : void 0,
            ue = P ? {} : {
                "aria-hidden": !0
            };
        return p(m(v, {
            instanceId: $,
            type: "modal",
            variant: D,
            children: m("div", {
                className: ne,
                "data-testid": "authorize-modal-container",
                "data-variant": M,
                children: [m("div", Object.assign({}, ue, {
                    className: te,
                    "data-testid": "authorize-modal-overlay",
                    onClick: () => ee("overlay")
                })), m(h, Object.assign({
                    as: "section",
                    disabled: !B,
                    "aria-modal": "true"
                }, ue, {
                    "aria-label": L,
                    className: re,
                    "data-testid": "authorize-modal",
                    "data-visible": P,
                    part: "modal",
                    ref: e => {
                        W.current = e, j && (Z.setFloating(e), G())
                    },
                    role: "dialog",
                    style: ce,
                    children: [m("div", {
                        "data-testid": "authorize-modal-content",
                        className: le,
                        style: ie,
                        children: [!T && m(g, {
                            headerTitle: b,
                            headerLogo: x,
                            onDismiss: ee
                        }), m("div", {
                            className: se,
                            children: w
                        })]
                    }), ae]
                }))]
            })
        }, R), c.body)
    },
    Ge = () => m(y, {
        children: [m("div", {
            class: "animate-pulse px-4 py-1 pb-6",
            "data-testid": "loading-skeleton",
            children: [m("div", {
                class: "flex items-center pb-3",
                children: [m("div", {
                    class: "mr-3 size-6 rounded-max bg-grayscale-l2"
                }), m("div", {
                    class: "mr-20 h-3 flex-1 rounded-md bg-grayscale-l2"
                })]
            }), m("div", {
                class: "h-10 rounded-md bg-grayscale-l2"
            })]
        }), m("div", {
            class: "h-10 animate-pulse bg-grayscale-l3"
        })]
    }),
    Je = ({
        children: e
    }) => {
        const {
            uiRendered: t
        } = s();
        return m(y, {
            children: [!t && m(Ge, {}), m("div", {
                children: e
            })]
        })
    },
    Ke = ["api_unavailable", "captcha_challenge", "retriable_server_error"],
    Qe = [/existing customer \d+ on shop \d+ has a conflicting provider subject associated: existing '([^']+)' != incoming '([^']+)'/, /no_prequalification_amount_available/];

function et(e, t) {
    return !(Ke.includes(e) || Qe.some((e => e.test(t))))
}
const tt = w((({
    activator: e,
    allowAttribute: o,
    anchorTo: r,
    autoOpen: l,
    disableDefaultIframeResizing: a = !1,
    insideModal: u = !0,
    keepModalOpen: d = !1,
    modalHeaderTitle: f,
    modalHeaderVisible: p = !0,
    onComplete: h,
    onCustomFlowSideEffect: g,
    onError: v,
    onLoaded: y,
    onModalVisibleChange: w,
    onResizeIframe: I,
    onPromptChange: F,
    onPromptContinue: j,
    proxy: H,
    renderInline: N = !1,
    sandbox: V = !1,
    scrolling: W,
    src: B,
    storefrontOrigin: q,
    modalType: $,
    variant: U
}, X) => {
    const {
        dispatch: Y,
        loaded: Z,
        modalVisible: G
    } = s(), {
        leaveBreadcrumb: J,
        notify: K
    } = x(), Q = b(), {
        clearLoadTimeout: ee,
        initLoadTimeout: te
    } = T(), {
        trackPageImpression: ne,
        trackPostMessageTransmission: oe
    } = E(), {
        recordCounter: re
    } = R(), ie = t(null), le = L(G), se = i((e => {
        Y({
            type: "showModal",
            reason: e
        })
    }), [Y]), ae = i((({
        dismissMethod: t,
        reason: n
    }) => {
        G && (Y({
            type: "hideModal",
            reason: n,
            dismissMethod: t
        }), (null == e ? void 0 : e.current) && nt(e) && e.current.focus())
    }), [e, Y, G]);
    n((() => {
        const t = z((function() {
                se("user_button_clicked")
            }), 150, !0),
            n = e;
        if ((null == n ? void 0 : n.current) && nt(n)) return n.current.addEventListener("click", t), () => {
            var e;
            null === (e = n.current) || void 0 === e || e.removeEventListener("click", t)
        }
    }), [e, se]);
    const ce = i((() => {
            P({
                iframe: ie.current,
                src: B
            })
        }), [B]),
        {
            destroy: ue,
            waitForMessage: de
        } = O({
            includeCore: H,
            onClose: () => ae({
                dismissMethod: "auto",
                reason: "event_close_requested"
            }),
            onComplete: e => k(void 0, void 0, void 0, (function*() {
                var t, n;
                !d && u && ae({
                    dismissMethod: "auto",
                    reason: "event_completed"
                });
                const o = Object.assign(Object.assign({}, e), {
                    shopSignIn: null !== (t = e.shopSignIn) && void 0 !== t ? t : e.loggedIn,
                    shopConsentedScopes: null !== (n = e.shopConsentedScopes) && void 0 !== n ? n : e.consentedScopes
                });
                yield null == h ? void 0 : h(o)
            })),
            onCustomFlowSideEffect: g,
            onError: e => {
                const {
                    message: t,
                    code: n
                } = e;
                et(n, t) ? (J("authorize error", {
                    code: n,
                    message: t
                }, "state"), K(new S(t, "AuthorizeError"))) : (re("shop_js_handle_silent_error", {
                    attributes: {
                        errorCode: n
                    }
                }), J("silent error", {
                    code: n
                }, "state")), ee(), null == v || v(e)
            },
            onLoaded: e => {
                Y({
                    type: "loaded",
                    payload: {
                        autoOpen: Boolean(l),
                        sessionDetected: e.userFound
                    }
                }), null == y || y(e), ee()
            },
            onUnloaded: () => {
                Y({
                    type: "reset"
                })
            },
            onResizeIframe: e => {
                a || ie.current && (ie.current.style.height = `${e.height}px`), e.height > 0 && Y({
                    type: "uiRendered"
                }), null == I || I(e)
            },
            onShopUserMatched: () => {
                Q("shopusermatched"), J("shop user matched", {}, "state")
            },
            onShopUserNotMatched: ({
                apiError: e
            }) => {
                Q("shopusernotmatched", e && {
                    apiError: e
                }), J("shop user not matched", {}, "state")
            },
            onPromptChange: () => {
                null == F || F()
            },
            onPromptContinue: () => {
                null == j || j()
            },
            source: ie,
            storefrontOrigin: q
        });
    n((() => () => {
        ie.current && ue()
    }), [ue]);
    const fe = i(((e, ...t) => k(void 0, [e, ...t], void 0, (function*(e, {
        afterLoaded: t = !1
    } = {}) {
        var n;
        t && !Z && (yield de("loaded")), A({
            contentWindow: null === (n = ie.current) || void 0 === n ? void 0 : n.contentWindow,
            event: e,
            onMessageSent: e => oe({
                direction: "outgoing",
                event: e
            })
        })
    }))), [Z, oe, de]);
    n((() => {
        var e;
        if (G !== le)
            if (G) {
                try {
                    fe({
                        type: "sheetmodalopened"
                    }, {
                        afterLoaded: !0
                    }), Q("modalopened")
                } catch (e) {
                    K(new Error(`Error before calling onModalVisibleChange(true): ${e}`))
                }
                null == w || w(!0)
            } else fe({
                type: "sheetmodalclosed"
            }, {
                afterLoaded: !0
            }), Q("modalclosed"), null == w || w(!1), null === (e = c.querySelector("com-1password-notification")) || void 0 === e || e.remove()
    }), [Q, G, K, w, fe, le]), _(X, (() => ({
        close: ae,
        iframeRef: ie,
        open: se,
        postMessage: fe,
        reload: ce,
        waitForMessage: de
    })), [ae, se, fe, ce, de]), n((() => {
        te(), J("Iframe url updated", {
            src: B
        }, "state")
    }), [te, J, B]), n((() => {
        G && ne({
            page: "AUTHORIZE_MODAL"
        })
    }), [G, ne]), n((() => {
        P({
            iframe: ie.current,
            src: B
        })
    }), [B]);
    const me = () => {
            ne({
                page: "AUTHORIZE_MODAL_IN_VIEWPORT",
                allowDuplicates: !0
            }), J("modal in viewport", {}, "state")
        },
        pe = m("iframe", {
            allow: o || "publickey-credentials-get *",
            className: "relative z-40 m-auto w-full border-none",
            ref: e => {
                e && (ie.current = e, e.getAttribute("src") || e.setAttribute("src", B))
            },
            tabIndex: 0,
            scrolling: W,
            "data-testid": "authorize-iframe",
            sandbox: V ? "allow-top-navigation allow-scripts allow-same-origin allow-forms" : void 0
        }),
        he = f ? m(C, {
            className: "size-8 text-purple-primary"
        }) : m(M, {
            className: "h-4-5 text-purple-primary"
        });
    return N ? m(D, {
        anchorTo: r,
        headerLogo: he,
        headerTitle: f,
        hideHeader: !p,
        onDismiss: e => ae({
            dismissMethod: e,
            reason: "user_dismissed"
        }),
        visible: G,
        children: m(Je, {
            children: pe
        })
    }) : u ? m(Ze, {
        anchorTo: r,
        headerLogo: he,
        headerTitle: f,
        hideHeader: !p,
        onDismiss: e => ae({
            dismissMethod: e,
            reason: "user_dismissed"
        }),
        onModalInViewport: me,
        type: $,
        variant: U,
        visible: G,
        children: m(Je, {
            children: pe
        })
    }) : pe
}));

function nt(e) {
    return Object.prototype.hasOwnProperty.call(e, "current")
}
tt.displayName = "AuthorizeIframe";
export {
    tt as A, Ze as M, et as i
};
//# sourceMappingURL=chunk.modal_B1su6BWj.en.esm.js.map