import {
    i as e
} from "./chunk.modal_B1su6BWj.en.esm.js";
const t = "show_sign_in_toast",
    n = "undefined" == typeof document ? {
        activeElement: null,
        addEventListener: () => {},
        appendChild: () => {},
        body: {},
        cookie: "",
        createElement: () => {},
        createTextNode: () => {},
        documentElement: {
            clientHeight: 0,
            clientWidth: 0,
            lang: "",
            style: {
                overflow: "",
                removeProperty: () => {}
            }
        },
        getElementById: () => null,
        head: {
            appendChild: () => {}
        },
        location: void 0,
        querySelector: () => {},
        querySelectorAll: () => [],
        removeEventListener: () => {},
        styleSheets: {}
    } : document,
    o = [];
for (let e = 0; e < 256; ++e) o.push((e + 256).toString(16).slice(1));
let r;
const i = new Uint8Array(16);
var a = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};

function s(e, t, n) {
    if (a.randomUUID && !t && !e) return a.randomUUID();
    const s = (e = e || {}).random ? ? e.rng ? .() ? ? function() {
        if (!r) {
            if ("undefined" == typeof crypto || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            r = crypto.getRandomValues.bind(crypto)
        }
        return r(i)
    }();
    if (s.length < 16) throw new Error("Random bytes length must be >= 16");
    return s[6] = 15 & s[6] | 64, s[8] = 63 & s[8] | 128,
        function(e, t = 0) {
            return (o[e[t + 0]] + o[e[t + 1]] + o[e[t + 2]] + o[e[t + 3]] + "-" + o[e[t + 4]] + o[e[t + 5]] + "-" + o[e[t + 6]] + o[e[t + 7]] + "-" + o[e[t + 8]] + o[e[t + 9]] + "-" + o[e[t + 10]] + o[e[t + 11]] + o[e[t + 12]] + o[e[t + 13]] + o[e[t + 14]] + o[e[t + 15]]).toLowerCase()
        }(s)
}
const l = {
        addEventListener: () => {},
        analytics: {},
        btoa: () => "",
        clearTimeout: () => {},
        CSS: {
            supports: (e, t) => !1
        },
        customElements: {},
        devicePixelRatio: 1,
        getComputedStyle: e => ({}),
        HTMLElement: {},
        innerHeight: 0,
        innerWidth: 0,
        localStorage: {
            getItem() {
                throw new Error("localStorage is not available")
            },
            setItem() {
                throw new Error("localStorage is not available")
            },
            removeItem() {
                throw new Error("localStorage is not available")
            }
        },
        sessionStorage: {
            getItem() {
                throw new Error("sessionStorage is not available")
            },
            setItem() {
                throw new Error("sessionStorage is not available")
            },
            removeItem() {
                throw new Error("sessionStorage is not available")
            }
        },
        location: {
            assign: () => {},
            hostname: "",
            href: "",
            origin: "",
            pathname: "",
            search: ""
        },
        matchMedia: () => ({
            matches: !1
        }),
        open: () => {},
        PublicKeyCredential: {
            isConditionalMediationAvailable: () => Promise.resolve(!1)
        },
        removeEventListener: () => {},
        ResizeObserver: void 0,
        screen: {
            availWidth: 0,
            height: 0,
            orientation: {
                type: ""
            },
            width: 0
        },
        screenLeft: 0,
        screenTop: 0,
        screenX: 0,
        screenY: 0,
        scrollTo: () => {},
        setTimeout: () => 0,
        Shopify: {},
        ShopifyAnalytics: {},
        top: {
            addEventListener: () => {},
            removeEventListener: () => {}
        },
        trekkie: {},
        URL: URL,
        visualViewport: {}
    },
    c = "undefined" == typeof window ? l : window;

function d(e) {
    const t = e ? "sessionStorage" : "localStorage";
    try {
        const e = c[t],
            n = "__storage_test__";
        return e.setItem(n, n), e.removeItem(n), !0
    } catch (e) {
        return !1
    }
}

function u(e, t, {
    session: n
} = {}) {
    if (!d(n)) return !1;
    return c[n ? "sessionStorage" : "localStorage"].setItem(e, t), !0
}

function p(e, {
    session: t
} = {}) {
    if (!d(t)) return null;
    return c[t ? "sessionStorage" : "localStorage"].getItem(e)
}
const h = "signInWithShop";

function f(e) {
    try {
        return JSON.parse(p(`${h}:${e}`, {
            session: !0
        }))
    } catch (e) {
        return null
    }
}

function m(e) {
    return Object.assign(Object.assign({}, e), {
        id: s()
    })
}

function v(e, t) {
    let n = t;
    t && (n = m(t)), u(`${h}:${e}`, JSON.stringify(n), {
        session: !0
    })
}

function g(e) {
    var t, n, o;
    null === (o = null === (n = null === (t = null == c ? void 0 : c.Shopify) || void 0 === t ? void 0 : t.SignInWithShop) || void 0 === n ? void 0 : n.renderToast) || void 0 === o || o.call(n, m(e))
}

function _(e, t) {
    var n = {};
    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var r = 0;
        for (o = Object.getOwnPropertySymbols(e); r < o.length; r++) t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]])
    }
    return n
}

function y(e, t, n, o) {
    return new(n || (n = Promise))((function(r, i) {
        function a(e) {
            try {
                l(o.next(e))
            } catch (e) {
                i(e)
            }
        }

        function s(e) {
            try {
                l(o.throw(e))
            } catch (e) {
                i(e)
            }
        }

        function l(e) {
            var t;
            e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                e(t)
            }))).then(a, s)
        }
        l((o = o.apply(e, t || [])).next())
    }))
}

function b(e, t, n, o) {
    if ("a" === n && !o) throw new TypeError("Private accessor was defined without a getter");
    if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return "m" === n ? o : "a" === n ? o.call(e) : o ? o.value : t.get(e)
}

function w(e, t, n, o, r) {
    if ("m" === o) throw new TypeError("Private method is not writable");
    if ("a" === o && !r) throw new TypeError("Private accessor was defined without a setter");
    if ("function" == typeof t ? e !== t || !r : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return "a" === o ? r.call(e, n) : r ? r.value = n : t.set(e, n), n
}
"function" == typeof SuppressedError && SuppressedError;
var x, k, E, S, P, M, j, C, O, T, I, N, A = {},
    L = [],
    R = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
    z = Array.isArray;

function D(e, t) {
    for (var n in t) e[n] = t[n];
    return e
}

function U(e) {
    e && e.parentNode && e.parentNode.removeChild(e)
}

function F(e, t, n) {
    var o, r, i, a = {};
    for (i in t) "key" == i ? o = t[i] : "ref" == i ? r = t[i] : a[i] = t[i];
    if (arguments.length > 2 && (a.children = arguments.length > 3 ? x.call(arguments, 2) : n), "function" == typeof e && null != e.defaultProps)
        for (i in e.defaultProps) void 0 === a[i] && (a[i] = e.defaultProps[i]);
    return $(e, a, o, r, null)
}

function $(e, t, n, o, r) {
    var i = {
        type: e,
        props: t,
        key: n,
        ref: o,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __c: null,
        constructor: void 0,
        __v: null == r ? ++E : r,
        __i: -1,
        __u: 0
    };
    return null == r && null != k.vnode && k.vnode(i), i
}

function B(e) {
    return e.children
}

function H(e, t) {
    this.props = e, this.context = t
}

function V(e, t) {
    if (null == t) return e.__ ? V(e.__, e.__i + 1) : null;
    for (var n; t < e.__k.length; t++)
        if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
    return "function" == typeof e.type ? V(e) : null
}

function W(e) {
    var t, n;
    if (null != (e = e.__) && null != e.__c) {
        for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
            if (null != (n = e.__k[t]) && null != n.__e) {
                e.__e = e.__c.base = n.__e;
                break
            }
        return W(e)
    }
}

function q(e) {
    (!e.__d && (e.__d = !0) && S.push(e) && !K.__r++ || P != k.debounceRendering) && ((P = k.debounceRendering) || M)(K)
}

function K() {
    for (var e, t, n, o, r, i, a, s = 1; S.length;) S.length > s && S.sort(j), e = S.shift(), s = S.length, e.__d && (n = void 0, r = (o = (t = e).__v).__e, i = [], a = [], t.__P && ((n = D({}, o)).__v = o.__v + 1, k.vnode && k.vnode(n), te(t.__P, n, o, t.__n, t.__P.namespaceURI, 32 & o.__u ? [r] : null, i, null == r ? V(o) : r, !!(32 & o.__u), a), n.__v = o.__v, n.__.__k[n.__i] = n, ne(i, n, a), n.__e != r && W(n)));
    K.__r = 0
}

function G(e, t, n, o, r, i, a, s, l, c, d) {
    var u, p, h, f, m, v, g = o && o.__k || L,
        _ = t.length;
    for (l = function(e, t, n, o, r) {
            var i, a, s, l, c, d = n.length,
                u = d,
                p = 0;
            for (e.__k = new Array(r), i = 0; i < r; i++) null != (a = t[i]) && "boolean" != typeof a && "function" != typeof a ? (l = i + p, (a = e.__k[i] = "string" == typeof a || "number" == typeof a || "bigint" == typeof a || a.constructor == String ? $(null, a, null, null, null) : z(a) ? $(B, {
                children: a
            }, null, null, null) : void 0 === a.constructor && a.__b > 0 ? $(a.type, a.props, a.key, a.ref ? a.ref : null, a.__v) : a).__ = e, a.__b = e.__b + 1, s = null, -1 != (c = a.__i = J(a, n, l, u)) && (u--, (s = n[c]) && (s.__u |= 2)), null == s || null == s.__v ? (-1 == c && (r > d ? p-- : r < d && p++), "function" != typeof a.type && (a.__u |= 4)) : c != l && (c == l - 1 ? p-- : c == l + 1 ? p++ : (c > l ? p-- : p++, a.__u |= 4))) : e.__k[i] = null;
            if (u)
                for (i = 0; i < d; i++) null != (s = n[i]) && !(2 & s.__u) && (s.__e == o && (o = V(s)), ae(s, s));
            return o
        }(n, t, g, l, _), u = 0; u < _; u++) null != (h = n.__k[u]) && (p = -1 == h.__i ? A : g[h.__i] || A, h.__i = u, v = te(e, h, p, r, i, a, s, l, c, d), f = h.__e, h.ref && p.ref != h.ref && (p.ref && ie(p.ref, null, h), d.push(h.ref, h.__c || f, h)), null == m && null != f && (m = f), 4 & h.__u || p.__k === h.__k ? l = X(h, l, e) : "function" == typeof h.type && void 0 !== v ? l = v : f && (l = f.nextSibling), h.__u &= -7);
    return n.__e = m, l
}

function X(e, t, n) {
    var o, r;
    if ("function" == typeof e.type) {
        for (o = e.__k, r = 0; o && r < o.length; r++) o[r] && (o[r].__ = e, t = X(o[r], t, n));
        return t
    }
    e.__e != t && (t && e.type && !n.contains(t) && (t = V(e)), n.insertBefore(e.__e, t || null), t = e.__e);
    do {
        t = t && t.nextSibling
    } while (null != t && 8 == t.nodeType);
    return t
}

function Y(e, t) {
    return t = t || [], null == e || "boolean" == typeof e || (z(e) ? e.some((function(e) {
        Y(e, t)
    })) : t.push(e)), t
}

function J(e, t, n, o) {
    var r, i, a = e.key,
        s = e.type,
        l = t[n];
    if (null === l && null == e.key || l && a == l.key && s == l.type && !(2 & l.__u)) return n;
    if (o > (null == l || 2 & l.__u ? 0 : 1))
        for (r = n - 1, i = n + 1; r >= 0 || i < t.length;) {
            if (r >= 0) {
                if ((l = t[r]) && !(2 & l.__u) && a == l.key && s == l.type) return r;
                r--
            }
            if (i < t.length) {
                if ((l = t[i]) && !(2 & l.__u) && a == l.key && s == l.type) return i;
                i++
            }
        }
    return -1
}

function Z(e, t, n) {
    "-" == t[0] ? e.setProperty(t, null == n ? "" : n) : e[t] = null == n ? "" : "number" != typeof n || R.test(t) ? n : n + "px"
}

function Q(e, t, n, o, r) {
    var i, a;
    e: if ("style" == t)
        if ("string" == typeof n) e.style.cssText = n;
        else {
            if ("string" == typeof o && (e.style.cssText = o = ""), o)
                for (t in o) n && t in n || Z(e.style, t, "");
            if (n)
                for (t in n) o && n[t] == o[t] || Z(e.style, t, n[t])
        }
    else if ("o" == t[0] && "n" == t[1]) i = t != (t = t.replace(C, "$1")), a = t.toLowerCase(), t = a in e || "onFocusOut" == t || "onFocusIn" == t ? a.slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + i] = n, n ? o ? n.u = o.u : (n.u = O, e.addEventListener(t, i ? I : T, i)) : e.removeEventListener(t, i ? I : T, i);
    else {
        if ("http://www.w3.org/2000/svg" == r) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" != t && "height" != t && "href" != t && "list" != t && "form" != t && "tabIndex" != t && "download" != t && "rowSpan" != t && "colSpan" != t && "role" != t && "popover" != t && t in e) try {
            e[t] = null == n ? "" : n;
            break e
        } catch (e) {}
        "function" == typeof n || (null == n || !1 === n && "-" != t[4] ? e.removeAttribute(t) : e.setAttribute(t, "popover" == t && 1 == n ? "" : n))
    }
}

function ee(e) {
    return function(t) {
        if (this.l) {
            var n = this.l[t.type + e];
            if (null == t.t) t.t = O++;
            else if (t.t < n.u) return;
            return n(k.event ? k.event(t) : t)
        }
    }
}

function te(e, t, n, o, r, i, a, s, l, c) {
    var d, u, p, h, f, m, v, g, _, y, b, w, x, E, S, P, M, j = t.type;
    if (void 0 !== t.constructor) return null;
    128 & n.__u && (l = !!(32 & n.__u), i = [s = t.__e = n.__e]), (d = k.__b) && d(t);
    e: if ("function" == typeof j) try {
        if (g = t.props, _ = "prototype" in j && j.prototype.render, y = (d = j.contextType) && o[d.__c], b = d ? y ? y.props.value : d.__ : o, n.__c ? v = (u = t.__c = n.__c).__ = u.__E : (_ ? t.__c = u = new j(g, b) : (t.__c = u = new H(g, b), u.constructor = j, u.render = se), y && y.sub(u), u.props = g, u.state || (u.state = {}), u.context = b, u.__n = o, p = u.__d = !0, u.__h = [], u._sb = []), _ && null == u.__s && (u.__s = u.state), _ && null != j.getDerivedStateFromProps && (u.__s == u.state && (u.__s = D({}, u.__s)), D(u.__s, j.getDerivedStateFromProps(g, u.__s))), h = u.props, f = u.state, u.__v = t, p) _ && null == j.getDerivedStateFromProps && null != u.componentWillMount && u.componentWillMount(), _ && null != u.componentDidMount && u.__h.push(u.componentDidMount);
        else {
            if (_ && null == j.getDerivedStateFromProps && g !== h && null != u.componentWillReceiveProps && u.componentWillReceiveProps(g, b), !u.__e && null != u.shouldComponentUpdate && !1 === u.shouldComponentUpdate(g, u.__s, b) || t.__v == n.__v) {
                for (t.__v != n.__v && (u.props = g, u.state = u.__s, u.__d = !1), t.__e = n.__e, t.__k = n.__k, t.__k.some((function(e) {
                        e && (e.__ = t)
                    })), w = 0; w < u._sb.length; w++) u.__h.push(u._sb[w]);
                u._sb = [], u.__h.length && a.push(u);
                break e
            }
            null != u.componentWillUpdate && u.componentWillUpdate(g, u.__s, b), _ && null != u.componentDidUpdate && u.__h.push((function() {
                u.componentDidUpdate(h, f, m)
            }))
        }
        if (u.context = b, u.props = g, u.__P = e, u.__e = !1, x = k.__r, E = 0, _) {
            for (u.state = u.__s, u.__d = !1, x && x(t), d = u.render(u.props, u.state, u.context), S = 0; S < u._sb.length; S++) u.__h.push(u._sb[S]);
            u._sb = []
        } else
            do {
                u.__d = !1, x && x(t), d = u.render(u.props, u.state, u.context), u.state = u.__s
            } while (u.__d && ++E < 25);
        u.state = u.__s, null != u.getChildContext && (o = D(D({}, o), u.getChildContext())), _ && !p && null != u.getSnapshotBeforeUpdate && (m = u.getSnapshotBeforeUpdate(h, f)), P = d, null != d && d.type === B && null == d.key && (P = oe(d.props.children)), s = G(e, z(P) ? P : [P], t, n, o, r, i, a, s, l, c), u.base = t.__e, t.__u &= -161, u.__h.length && a.push(u), v && (u.__E = u.__ = null)
    } catch (e) {
        if (t.__v = null, l || null != i)
            if (e.then) {
                for (t.__u |= l ? 160 : 128; s && 8 == s.nodeType && s.nextSibling;) s = s.nextSibling;
                i[i.indexOf(s)] = null, t.__e = s
            } else
                for (M = i.length; M--;) U(i[M]);
        else t.__e = n.__e, t.__k = n.__k;
        k.__e(e, t, n)
    } else null == i && t.__v == n.__v ? (t.__k = n.__k, t.__e = n.__e) : s = t.__e = re(n.__e, t, n, o, r, i, a, l, c);
    return (d = k.diffed) && d(t), 128 & t.__u ? void 0 : s
}

function ne(e, t, n) {
    for (var o = 0; o < n.length; o++) ie(n[o], n[++o], n[++o]);
    k.__c && k.__c(t, e), e.some((function(t) {
        try {
            e = t.__h, t.__h = [], e.some((function(e) {
                e.call(t)
            }))
        } catch (e) {
            k.__e(e, t.__v)
        }
    }))
}

function oe(e) {
    return "object" != typeof e || null == e || e.__b && e.__b > 0 ? e : z(e) ? e.map(oe) : D({}, e)
}

function re(e, t, n, o, r, i, a, s, l) {
    var c, d, u, p, h, f, m, v = n.props,
        g = t.props,
        _ = t.type;
    if ("svg" == _ ? r = "http://www.w3.org/2000/svg" : "math" == _ ? r = "http://www.w3.org/1998/Math/MathML" : r || (r = "http://www.w3.org/1999/xhtml"), null != i)
        for (c = 0; c < i.length; c++)
            if ((h = i[c]) && "setAttribute" in h == !!_ && (_ ? h.localName == _ : 3 == h.nodeType)) {
                e = h, i[c] = null;
                break
            }
    if (null == e) {
        if (null == _) return document.createTextNode(g);
        e = document.createElementNS(r, _, g.is && g), s && (k.__m && k.__m(t, i), s = !1), i = null
    }
    if (null == _) v === g || s && e.data == g || (e.data = g);
    else {
        if (i = i && x.call(e.childNodes), v = n.props || A, !s && null != i)
            for (v = {}, c = 0; c < e.attributes.length; c++) v[(h = e.attributes[c]).name] = h.value;
        for (c in v)
            if (h = v[c], "children" == c);
            else if ("dangerouslySetInnerHTML" == c) u = h;
        else if (!(c in g)) {
            if ("value" == c && "defaultValue" in g || "checked" == c && "defaultChecked" in g) continue;
            Q(e, c, null, h, r)
        }
        for (c in g) h = g[c], "children" == c ? p = h : "dangerouslySetInnerHTML" == c ? d = h : "value" == c ? f = h : "checked" == c ? m = h : s && "function" != typeof h || v[c] === h || Q(e, c, h, v[c], r);
        if (d) s || u && (d.__html == u.__html || d.__html == e.innerHTML) || (e.innerHTML = d.__html), t.__k = [];
        else if (u && (e.innerHTML = ""), G("template" == t.type ? e.content : e, z(p) ? p : [p], t, n, o, "foreignObject" == _ ? "http://www.w3.org/1999/xhtml" : r, i, a, i ? i[0] : n.__k && V(n, 0), s, l), null != i)
            for (c = i.length; c--;) U(i[c]);
        s || (c = "value", "progress" == _ && null == f ? e.removeAttribute("value") : null != f && (f !== e[c] || "progress" == _ && !f || "option" == _ && f != v[c]) && Q(e, c, f, v[c], r), c = "checked", null != m && m != e[c] && Q(e, c, m, v[c], r))
    }
    return e
}

function ie(e, t, n) {
    try {
        if ("function" == typeof e) {
            var o = "function" == typeof e.__u;
            o && e.__u(), o && null == t || (e.__u = e(t))
        } else e.current = t
    } catch (e) {
        k.__e(e, n)
    }
}

function ae(e, t, n) {
    var o, r;
    if (k.unmount && k.unmount(e), (o = e.ref) && (o.current && o.current != e.__e || ie(o, null, t)), null != (o = e.__c)) {
        if (o.componentWillUnmount) try {
            o.componentWillUnmount()
        } catch (e) {
            k.__e(e, t)
        }
        o.base = o.__P = null
    }
    if (o = e.__k)
        for (r = 0; r < o.length; r++) o[r] && ae(o[r], t, n || "function" != typeof e.type);
    n || U(e.__e), e.__c = e.__ = e.__e = void 0
}

function se(e, t, n) {
    return this.constructor(e, n)
}

function le(e, t, n) {
    var o, r, i, a;
    t == document && (t = document.documentElement), k.__ && k.__(e, t), r = (o = "function" == typeof n) ? null : t.__k, i = [], a = [], te(t, e = (!o && n || t).__k = F(B, null, [e]), r || A, A, t.namespaceURI, !o && n ? [n] : r ? null : t.firstChild ? x.call(t.childNodes) : null, i, !o && n ? n : r ? r.__e : t.firstChild, o, a), ne(i, e, a)
}

function ce(e, t, n) {
    var o, r, i, a, s = D({}, e.props);
    for (i in e.type && e.type.defaultProps && (a = e.type.defaultProps), t) "key" == i ? o = t[i] : "ref" == i ? r = t[i] : s[i] = void 0 === t[i] && null != a ? a[i] : t[i];
    return arguments.length > 2 && (s.children = arguments.length > 3 ? x.call(arguments, 2) : n), $(e.type, s, o || e.key, r || e.ref, null)
}

function de(e) {
    function t(e) {
        var n, o;
        return this.getChildContext || (n = new Set, (o = {})[t.__c] = this, this.getChildContext = function() {
            return o
        }, this.componentWillUnmount = function() {
            n = null
        }, this.shouldComponentUpdate = function(e) {
            this.props.value != e.value && n.forEach((function(e) {
                e.__e = !0, q(e)
            }))
        }, this.sub = function(e) {
            n.add(e);
            var t = e.componentWillUnmount;
            e.componentWillUnmount = function() {
                n && n.delete(e), t && t.call(e)
            }
        }), e.children
    }
    return t.__c = "__cC" + N++, t.__ = e, t.Provider = t.__l = (t.Consumer = function(e, t) {
        return e.children(t)
    }).contextType = t, t
}
x = L.slice, k = {
    __e: function(e, t, n, o) {
        for (var r, i, a; t = t.__;)
            if ((r = t.__c) && !r.__) try {
                if ((i = r.constructor) && null != i.getDerivedStateFromError && (r.setState(i.getDerivedStateFromError(e)), a = r.__d), null != r.componentDidCatch && (r.componentDidCatch(e, o || {}), a = r.__d), a) return r.__E = r
            } catch (t) {
                e = t
            }
        throw e
    }
}, E = 0, H.prototype.setState = function(e, t) {
    var n;
    n = null != this.__s && this.__s != this.state ? this.__s : this.__s = D({}, this.state), "function" == typeof e && (e = e(D({}, n), this.props)), e && D(n, e), null != e && this.__v && (t && this._sb.push(t), q(this))
}, H.prototype.forceUpdate = function(e) {
    this.__v && (this.__e = !0, e && this.__h.push(e), q(this))
}, H.prototype.render = B, S = [], M = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, j = function(e, t) {
    return e.__v.__b - t.__v.__b
}, K.__r = 0, C = /(PointerCapture)$|Capture$/i, O = 0, T = ee(!1), I = ee(!0), N = 0;
var ue = 0;

function pe(e, t, n, o, r, i) {
    t || (t = {});
    var a, s, l = t;
    if ("ref" in l)
        for (s in l = {}, t) "ref" == s ? a = t[s] : l[s] = t[s];
    var c = {
        type: e,
        props: l,
        key: n,
        ref: a,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __c: null,
        constructor: void 0,
        __v: --ue,
        __i: -1,
        __u: 0,
        __source: r,
        __self: i
    };
    if ("function" == typeof e && (a = e.defaultProps))
        for (s in a) void 0 === l[s] && (l[s] = a[s]);
    return k.vnode && k.vnode(c), c
}
var he, fe, me, ve, ge = 0,
    _e = [],
    ye = k,
    be = ye.__b,
    we = ye.__r,
    xe = ye.diffed,
    ke = ye.__c,
    Ee = ye.unmount,
    Se = ye.__;

function Pe(e, t) {
    ye.__h && ye.__h(fe, e, ge || t), ge = 0;
    var n = fe.__H || (fe.__H = {
        __: [],
        __h: []
    });
    return e >= n.__.length && n.__.push({}), n.__[e]
}

function Me(e) {
    return ge = 1, je(Be, e)
}

function je(e, t, n) {
    var o = Pe(he++, 2);
    if (o.t = e, !o.__c && (o.__ = [n ? n(t) : Be(void 0, t), function(e) {
            var t = o.__N ? o.__N[0] : o.__[0],
                n = o.t(t, e);
            t !== n && (o.__N = [n, o.__[1]], o.__c.setState({}))
        }], o.__c = fe, !fe.__f)) {
        var r = function(e, t, n) {
            if (!o.__c.__H) return !0;
            var r = o.__c.__H.__.filter((function(e) {
                return !!e.__c
            }));
            if (r.every((function(e) {
                    return !e.__N
                }))) return !i || i.call(this, e, t, n);
            var a = o.__c.props !== e;
            return r.forEach((function(e) {
                if (e.__N) {
                    var t = e.__[0];
                    e.__ = e.__N, e.__N = void 0, t !== e.__[0] && (a = !0)
                }
            })), i && i.call(this, e, t, n) || a
        };
        fe.__f = !0;
        var i = fe.shouldComponentUpdate,
            a = fe.componentWillUpdate;
        fe.componentWillUpdate = function(e, t, n) {
            if (this.__e) {
                var o = i;
                i = void 0, r(e, t, n), i = o
            }
            a && a.call(this, e, t, n)
        }, fe.shouldComponentUpdate = r
    }
    return o.__N || o.__
}

function Ce(e, t) {
    var n = Pe(he++, 3);
    !ye.__s && $e(n.__H, t) && (n.__ = e, n.u = t, fe.__H.__h.push(n))
}

function Oe(e, t) {
    var n = Pe(he++, 4);
    !ye.__s && $e(n.__H, t) && (n.__ = e, n.u = t, fe.__h.push(n))
}

function Te(e) {
    return ge = 5, Ne((function() {
        return {
            current: e
        }
    }), [])
}

function Ie(e, t, n) {
    ge = 6, Oe((function() {
        if ("function" == typeof e) {
            var n = e(t());
            return function() {
                e(null), n && "function" == typeof n && n()
            }
        }
        if (e) return e.current = t(),
            function() {
                return e.current = null
            }
    }), null == n ? n : n.concat(e))
}

function Ne(e, t) {
    var n = Pe(he++, 7);
    return $e(n.__H, t) && (n.__ = e(), n.__H = t, n.__h = e), n.__
}

function Ae(e, t) {
    return ge = 8, Ne((function() {
        return e
    }), t)
}

function Le(e) {
    var t = fe.context[e.__c],
        n = Pe(he++, 9);
    return n.c = e, t ? (null == n.__ && (n.__ = !0, t.sub(fe)), t.props.value) : e.__
}

function Re() {
    for (var e; e = _e.shift();)
        if (e.__P && e.__H) try {
            e.__H.__h.forEach(Ue), e.__H.__h.forEach(Fe), e.__H.__h = []
        } catch (t) {
            e.__H.__h = [], ye.__e(t, e.__v)
        }
}
ye.__b = function(e) {
    fe = null, be && be(e)
}, ye.__ = function(e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m), Se && Se(e, t)
}, ye.__r = function(e) {
    we && we(e), he = 0;
    var t = (fe = e.__c).__H;
    t && (me === fe ? (t.__h = [], fe.__h = [], t.__.forEach((function(e) {
        e.__N && (e.__ = e.__N), e.u = e.__N = void 0
    }))) : (t.__h.forEach(Ue), t.__h.forEach(Fe), t.__h = [], he = 0)), me = fe
}, ye.diffed = function(e) {
    xe && xe(e);
    var t = e.__c;
    t && t.__H && (t.__H.__h.length && (1 !== _e.push(t) && ve === ye.requestAnimationFrame || ((ve = ye.requestAnimationFrame) || De)(Re)), t.__H.__.forEach((function(e) {
        e.u && (e.__H = e.u), e.u = void 0
    }))), me = fe = null
}, ye.__c = function(e, t) {
    t.some((function(e) {
        try {
            e.__h.forEach(Ue), e.__h = e.__h.filter((function(e) {
                return !e.__ || Fe(e)
            }))
        } catch (n) {
            t.some((function(e) {
                e.__h && (e.__h = [])
            })), t = [], ye.__e(n, e.__v)
        }
    })), ke && ke(e, t)
}, ye.unmount = function(e) {
    Ee && Ee(e);
    var t, n = e.__c;
    n && n.__H && (n.__H.__.forEach((function(e) {
        try {
            Ue(e)
        } catch (e) {
            t = e
        }
    })), n.__H = void 0, t && ye.__e(t, n.__v))
};
var ze = "function" == typeof requestAnimationFrame;

function De(e) {
    var t, n = function() {
            clearTimeout(o), ze && cancelAnimationFrame(t), setTimeout(e)
        },
        o = setTimeout(n, 35);
    ze && (t = requestAnimationFrame(n))
}

function Ue(e) {
    var t = fe,
        n = e.__c;
    "function" == typeof n && (e.__c = void 0, n()), fe = t
}

function Fe(e) {
    var t = fe;
    e.__c = e.__(), fe = t
}

function $e(e, t) {
    return !e || e.length !== t.length || t.some((function(t, n) {
        return t !== e[n]
    }))
}

function Be(e, t) {
    return "function" == typeof t ? t(e) : t
}

function He(e, t) {
    for (var n in t) e[n] = t[n];
    return e
}

function Ve(e, t) {
    for (var n in e)
        if ("__source" !== n && !(n in t)) return !0;
    for (var o in t)
        if ("__source" !== o && e[o] !== t[o]) return !0;
    return !1
}

function We(e, t) {
    this.props = e, this.context = t
}(We.prototype = new H).isPureReactComponent = !0, We.prototype.shouldComponentUpdate = function(e, t) {
    return Ve(this.props, e) || Ve(this.state, t)
};
var qe = k.__b;
k.__b = function(e) {
    e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), qe && qe(e)
};
var Ke = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;

function Ge(e) {
    function t(t) {
        var n = He({}, t);
        return delete n.ref, e(n, t.ref || null)
    }
    return t.$$typeof = Ke, t.render = t, t.prototype.isReactComponent = t.__f = !0, t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", t
}
var Xe = k.__e;
k.__e = function(e, t, n, o) {
    if (e.then)
        for (var r, i = t; i = i.__;)
            if ((r = i.__c) && r.__c) return null == t.__e && (t.__e = n.__e, t.__k = n.__k), r.__c(e, t);
    Xe(e, t, n, o)
};
var Ye = k.unmount;

function Je(e, t, n) {
    return e && (e.__c && e.__c.__H && (e.__c.__H.__.forEach((function(e) {
        "function" == typeof e.__c && e.__c()
    })), e.__c.__H = null), null != (e = He({}, e)).__c && (e.__c.__P === n && (e.__c.__P = t), e.__c.__e = !0, e.__c = null), e.__k = e.__k && e.__k.map((function(e) {
        return Je(e, t, n)
    }))), e
}

function Ze(e, t, n) {
    return e && n && (e.__v = null, e.__k = e.__k && e.__k.map((function(e) {
        return Ze(e, t, n)
    })), e.__c && e.__c.__P === t && (e.__e && n.appendChild(e.__e), e.__c.__e = !0, e.__c.__P = n)), e
}

function Qe() {
    this.__u = 0, this.o = null, this.__b = null
}

function et(e) {
    var t = e.__.__c;
    return t && t.__a && t.__a(e)
}

function tt() {
    this.i = null, this.l = null
}
k.unmount = function(e) {
    var t = e.__c;
    t && t.__R && t.__R(), t && 32 & e.__u && (e.type = null), Ye && Ye(e)
}, (Qe.prototype = new H).__c = function(e, t) {
    var n = t.__c,
        o = this;
    null == o.o && (o.o = []), o.o.push(n);
    var r = et(o.__v),
        i = !1,
        a = function() {
            i || (i = !0, n.__R = null, r ? r(s) : s())
        };
    n.__R = a;
    var s = function() {
        if (!--o.__u) {
            if (o.state.__a) {
                var e = o.state.__a;
                o.__v.__k[0] = Ze(e, e.__c.__P, e.__c.__O)
            }
            var t;
            for (o.setState({
                    __a: o.__b = null
                }); t = o.o.pop();) t.forceUpdate()
        }
    };
    o.__u++ || 32 & t.__u || o.setState({
        __a: o.__b = o.__v.__k[0]
    }), e.then(a, a)
}, Qe.prototype.componentWillUnmount = function() {
    this.o = []
}, Qe.prototype.render = function(e, t) {
    if (this.__b) {
        if (this.__v.__k) {
            var n = document.createElement("div"),
                o = this.__v.__k[0].__c;
            this.__v.__k[0] = Je(this.__b, n, o.__O = o.__P)
        }
        this.__b = null
    }
    var r = t.__a && F(B, null, e.fallback);
    return r && (r.__u &= -33), [F(B, null, t.__a ? null : e.children), r]
};
var nt = function(e, t, n) {
    if (++n[1] === n[0] && e.l.delete(t), e.props.revealOrder && ("t" !== e.props.revealOrder[0] || !e.l.size))
        for (n = e.i; n;) {
            for (; n.length > 3;) n.pop()();
            if (n[1] < n[0]) break;
            e.i = n = n[2]
        }
};

function ot(e) {
    return this.getChildContext = function() {
        return e.context
    }, e.children
}

function rt(e) {
    var t = this,
        n = e.h;
    if (t.componentWillUnmount = function() {
            le(null, t.v), t.v = null, t.h = null
        }, t.h && t.h !== n && t.componentWillUnmount(), !t.v) {
        for (var o = t.__v; null !== o && !o.__m && null !== o.__;) o = o.__;
        t.h = n, t.v = {
            nodeType: 1,
            parentNode: n,
            childNodes: [],
            __k: {
                __m: o.__m
            },
            contains: function() {
                return !0
            },
            insertBefore: function(e, n) {
                this.childNodes.push(e), t.h.insertBefore(e, n)
            },
            removeChild: function(e) {
                this.childNodes.splice(this.childNodes.indexOf(e) >>> 1, 1), t.h.removeChild(e)
            }
        }
    }
    le(F(ot, {
        context: t.context
    }, e.__v), t.v)
}

function it(e, t) {
    var n = F(rt, {
        __v: e,
        h: t
    });
    return n.containerInfo = t, n
}(tt.prototype = new H).__a = function(e) {
    var t = this,
        n = et(t.__v),
        o = t.l.get(e);
    return o[0]++,
        function(r) {
            var i = function() {
                t.props.revealOrder ? (o.push(r), nt(t, e, o)) : r()
            };
            n ? n(i) : i()
        }
}, tt.prototype.render = function(e) {
    this.i = null, this.l = new Map;
    var t = Y(e.children);
    e.revealOrder && "b" === e.revealOrder[0] && t.reverse();
    for (var n = t.length; n--;) this.l.set(t[n], this.i = [1, 0, this.i]);
    return e.children
}, tt.prototype.componentDidUpdate = tt.prototype.componentDidMount = function() {
    var e = this;
    this.l.forEach((function(t, n) {
        nt(e, n, t)
    }))
};
var at = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103,
    st = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    lt = /^on(Ani|Tra|Tou|BeforeInp|Compo)/,
    ct = /[A-Z0-9]/g,
    dt = "undefined" != typeof document,
    ut = function(e) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(e)
    };
H.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach((function(e) {
    Object.defineProperty(H.prototype, e, {
        configurable: !0,
        get: function() {
            return this["UNSAFE_" + e]
        },
        set: function(t) {
            Object.defineProperty(this, e, {
                configurable: !0,
                writable: !0,
                value: t
            })
        }
    })
}));
var pt = k.event;

function ht() {}

function ft() {
    return this.cancelBubble
}

function mt() {
    return this.defaultPrevented
}
k.event = function(e) {
    return pt && (e = pt(e)), e.persist = ht, e.isPropagationStopped = ft, e.isDefaultPrevented = mt, e.nativeEvent = e
};
var vt = {
        enumerable: !1,
        configurable: !0,
        get: function() {
            return this.class
        }
    },
    gt = k.vnode;
k.vnode = function(e) {
    "string" == typeof e.type && function(e) {
        var t = e.props,
            n = e.type,
            o = {},
            r = -1 === n.indexOf("-");
        for (var i in t) {
            var a = t[i];
            if (!("value" === i && "defaultValue" in t && null == a || dt && "children" === i && "noscript" === n || "class" === i || "className" === i)) {
                var s = i.toLowerCase();
                "defaultValue" === i && "value" in t && null == t.value ? i = "value" : "download" === i && !0 === a ? a = "" : "translate" === s && "no" === a ? a = !1 : "o" === s[0] && "n" === s[1] ? "ondoubleclick" === s ? i = "ondblclick" : "onchange" !== s || "input" !== n && "textarea" !== n || ut(t.type) ? "onfocus" === s ? i = "onfocusin" : "onblur" === s ? i = "onfocusout" : lt.test(i) && (i = s) : s = i = "oninput" : r && st.test(i) ? i = i.replace(ct, "-$&").toLowerCase() : null === a && (a = void 0), "oninput" === s && o[i = s] && (i = "oninputCapture"), o[i] = a
            }
        }
        "select" == n && o.multiple && Array.isArray(o.value) && (o.value = Y(t.children).forEach((function(e) {
            e.props.selected = -1 != o.value.indexOf(e.props.value)
        }))), "select" == n && null != o.defaultValue && (o.value = Y(t.children).forEach((function(e) {
            e.props.selected = o.multiple ? -1 != o.defaultValue.indexOf(e.props.value) : o.defaultValue == e.props.value
        }))), t.class && !t.className ? (o.class = t.class, Object.defineProperty(o, "className", vt)) : (t.className && !t.class || t.class && t.className) && (o.class = o.className = t.className), e.props = o
    }(e), e.$$typeof = at, gt && gt(e)
};
var _t = k.__r;
k.__r = function(e) {
    _t && _t(e), e.__c
};
var yt = k.diffed;
k.diffed = function(e) {
        yt && yt(e);
        var t = e.props,
            n = e.__e;
        null != n && "textarea" === e.type && "value" in t && t.value !== n.value && (n.value = null == t.value ? "" : t.value)
    },
    function() {
        if ("undefined" != typeof document && !("adoptedStyleSheets" in document)) {
            var e = "ShadyCSS" in window && !ShadyCSS.nativeShadow,
                t = document.implementation.createHTMLDocument(""),
                n = new WeakMap,
                o = "object" == typeof DOMException ? Error : DOMException,
                r = Object.defineProperty,
                i = Array.prototype.forEach,
                a = /@import.+?;?$/gm,
                s = CSSStyleSheet.prototype;
            s.replace = function() {
                return Promise.reject(new o("Can't call replace on non-constructed CSSStyleSheets."))
            }, s.replaceSync = function() {
                throw new o("Failed to execute 'replaceSync' on 'CSSStyleSheet': Can't call replaceSync on non-constructed CSSStyleSheets.")
            };
            var l = new WeakMap,
                c = new WeakMap,
                d = new WeakMap,
                u = new WeakMap,
                p = M.prototype;
            p.replace = function(e) {
                try {
                    return this.replaceSync(e), Promise.resolve(this)
                } catch (e) {
                    return Promise.reject(e)
                }
            }, p.replaceSync = function(e) {
                if (P(this), "string" == typeof e) {
                    var t = this;
                    l.get(t).textContent = function(e) {
                        var t = e.replace(a, "");
                        return t !== e && console.warn("@import rules are not allowed here. See https://github.com/WICG/construct-stylesheets/issues/119#issuecomment-588352418"), t.trim()
                    }(e), u.set(t, []), c.get(t).forEach((function(e) {
                        e.isConnected() && S(t, E(t, e))
                    }))
                }
            }, r(p, "cssRules", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return P(this), l.get(this).sheet.cssRules
                }
            }), r(p, "media", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return P(this), l.get(this).sheet.media
                }
            }), ["addRule", "deleteRule", "insertRule", "removeRule"].forEach((function(e) {
                p[e] = function() {
                    var t = this;
                    P(t);
                    var n = arguments;
                    u.get(t).push({
                        method: e,
                        args: n
                    }), c.get(t).forEach((function(o) {
                        if (o.isConnected()) {
                            var r = E(t, o).sheet;
                            r[e].apply(r, n)
                        }
                    }));
                    var o = l.get(t).sheet;
                    return o[e].apply(o, n)
                }
            })), r(M, Symbol.hasInstance, {
                configurable: !0,
                value: x
            });
            var h = {
                    childList: !0,
                    subtree: !0
                },
                f = new WeakMap,
                m = new WeakMap,
                v = new WeakMap,
                g = new WeakMap;
            if (N.prototype = {
                    isConnected: function() {
                        var e = m.get(this);
                        return e instanceof Document ? "loading" !== e.readyState : function(e) {
                            return "isConnected" in e ? e.isConnected : document.contains(e)
                        }(e.host)
                    },
                    connect: function() {
                        var e = T(this);
                        g.get(this).observe(e, h), v.get(this).length > 0 && I(this), O(e, (function(e) {
                            j(e).connect()
                        }))
                    },
                    disconnect: function() {
                        g.get(this).disconnect()
                    },
                    update: function(e) {
                        var t = this,
                            n = m.get(t) === document ? "Document" : "ShadowRoot";
                        if (!Array.isArray(e)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Iterator getter is not callable.");
                        if (!e.every(x)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Failed to convert value to 'CSSStyleSheet'");
                        if (e.some(k)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Can't adopt non-constructed stylesheets");
                        t.sheets = e;
                        var o, r, i = v.get(t),
                            a = (o = e).filter((function(e, t) {
                                return o.indexOf(e) === t
                            }));
                        (r = a, i.filter((function(e) {
                            return -1 === r.indexOf(e)
                        }))).forEach((function(e) {
                            var n;
                            (n = E(e, t)).parentNode.removeChild(n),
                                function(e, t) {
                                    d.get(e).delete(t), c.set(e, c.get(e).filter((function(e) {
                                        return e !== t
                                    })))
                                }(e, t)
                        })), v.set(t, a), t.isConnected() && a.length > 0 && I(t)
                    }
                }, window.CSSStyleSheet = M, C(Document), "ShadowRoot" in window) {
                C(ShadowRoot);
                var _ = Element.prototype,
                    y = _.attachShadow;
                _.attachShadow = function(e) {
                    var t = y.call(this, e);
                    return "closed" === e.mode && n.set(this, t), t
                }
            }
            var b = j(document);
            b.isConnected() ? b.connect() : document.addEventListener("DOMContentLoaded", b.connect.bind(b))
        }

        function w(e) {
            return e.shadowRoot || n.get(e)
        }

        function x(e) {
            return "object" == typeof e && (p.isPrototypeOf(e) || s.isPrototypeOf(e))
        }

        function k(e) {
            return "object" == typeof e && s.isPrototypeOf(e)
        }

        function E(e, t) {
            return d.get(e).get(t)
        }

        function S(e, t) {
            requestAnimationFrame((function() {
                t.textContent = l.get(e).textContent, u.get(e).forEach((function(e) {
                    return t.sheet[e.method].apply(t.sheet, e.args)
                }))
            }))
        }

        function P(e) {
            if (!l.has(e)) throw new TypeError("Illegal invocation")
        }

        function M() {
            var e = this,
                n = document.createElement("style");
            t.body.appendChild(n), l.set(e, n), c.set(e, []), d.set(e, new WeakMap), u.set(e, [])
        }

        function j(e) {
            var t = f.get(e);
            return t || (t = new N(e), f.set(e, t)), t
        }

        function C(e) {
            r(e.prototype, "adoptedStyleSheets", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return j(this).sheets
                },
                set: function(e) {
                    j(this).update(e)
                }
            })
        }

        function O(e, t) {
            for (var n = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT, (function(e) {
                    return w(e) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
                }), null, !1), o = void 0; o = n.nextNode();) t(w(o))
        }

        function T(e) {
            var t = m.get(e);
            return t instanceof Document ? t.body : t
        }

        function I(e) {
            var t = document.createDocumentFragment(),
                n = v.get(e),
                o = g.get(e),
                r = T(e);
            o.disconnect(), n.forEach((function(n) {
                t.appendChild(E(n, e) || function(e, t) {
                    var n = document.createElement("style");
                    return d.get(e).set(t, n), c.get(e).push(t), n
                }(n, e))
            })), r.insertBefore(t, null), o.observe(r, h), n.forEach((function(t) {
                S(t, E(t, e))
            }))
        }

        function N(t) {
            var n = this;
            n.sheets = [], m.set(n, t), v.set(n, []), g.set(n, new MutationObserver((function(t, o) {
                document ? t.forEach((function(t) {
                    e || i.call(t.addedNodes, (function(e) {
                        e instanceof Element && O(e, (function(e) {
                            j(e).connect()
                        }))
                    })), i.call(t.removedNodes, (function(t) {
                        t instanceof Element && (function(e, t) {
                            return t instanceof HTMLStyleElement && v.get(e).some((function(t) {
                                return E(t, e)
                            }))
                        }(n, t) && I(n), e || O(t, (function(e) {
                            j(e).disconnect()
                        })))
                    }))
                })) : o.disconnect()
            })))
        }
    }();
const bt = de({
        client: void 0,
        leaveBreadcrumb: () => {
            throw new Error("Invalid attempt to call leaveBreadcrumb outside of context.")
        },
        notify: () => {
            throw new Error("Invalid attempt to call notify outside of context.")
        }
    }),
    wt = () => {
        const e = Le(bt);
        if (!e) throw new Error("Invalid attempt to use useBugsnag outside of BugsnagProvider.");
        return e
    };
var xt = '*,::backdrop,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:#3b82f680;--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/*! tailwindcss v3.4.14 | MIT License | https://tailwindcss.com*/*,:after,:before{border:0 solid;box-sizing:border-box}:after,:before{--tw-content:""}:host,html{-webkit-text-size-adjust:100%;font-feature-settings:normal;-webkit-tap-highlight-color:transparent;font-family:GTStandard-M,sans-serif;font-variation-settings:normal;line-height:1.5;tab-size:4}body{line-height:inherit;margin:0}hr{border-top-width:1px;color:inherit;height:0}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-feature-settings:normal;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:1em;font-variation-settings:normal}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:initial}sub{bottom:-.25em}sup{top:-.5em}table{border-collapse:collapse;border-color:inherit;text-indent:0}button,input,optgroup,select,textarea{font-feature-settings:inherit;color:inherit;font-family:inherit;font-size:100%;font-variation-settings:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:initial;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:initial}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0}fieldset,legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{color:#9ca3af;opacity:1}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{height:auto;max-width:100%}[hidden]:where(:not([hidden=until-found])){display:none}:host{font-family:GTStandard-M,sans-serif}:host([data-nametag=shop-portal-provider]){all:initial!important}:host(shopify-payment-terms){font-family:inherit}.\\!container{width:100%!important}.container{width:100%}@media (min-width:768px){.\\!container{max-width:768px!important}.container{max-width:768px}}@media (min-width:1024px){.\\!container{max-width:1024px!important}.container{max-width:1024px}}@media (min-width:1280px){.\\!container{max-width:1280px!important}.container{max-width:1280px}}@media (min-width:1536px){.\\!container{max-width:1536px!important}.container{max-width:1536px}}.sr-only{clip:rect(0,0,0,0);border-width:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px}.pointer-events-none{pointer-events:none}.\\!visible{visibility:visible!important}.visible{visibility:visible}.invisible{visibility:hidden}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.inset-0{inset:0}.inset-05{inset:2px}.inset-x-0{left:0;right:0}.inset-y-0{bottom:0;top:0}.bottom-8{bottom:32px}.bottom-\\[15\\%\\]{bottom:15%}.right-0{right:0}.-z-10{z-index:-10}.z-0{z-index:0}.z-10{z-index:10}.z-30{z-index:30}.z-40{z-index:40}.z-50{z-index:50}.z-max{z-index:2147483647}.-m-px{margin:-1px}.m-0{margin:0}.m-\\[1em\\]{margin:1em}.m-auto{margin:auto}.mx-auto{margin-left:auto;margin-right:auto}.my-0\\.5{margin-bottom:.125rem;margin-top:.125rem}.my-1{margin-bottom:4px;margin-top:4px}.my-4{margin-bottom:16px;margin-top:16px}.my-7{margin-bottom:28px;margin-top:28px}.my-px{margin-bottom:1px;margin-top:1px}.-ml-1{margin-left:-4px}.mb-2{margin-bottom:8px}.mb-3{margin-bottom:12px}.mb-4{margin-bottom:16px}.mb-5{margin-bottom:20px}.mb-7{margin-bottom:28px}.ml-1{margin-left:4px}.ml-auto{margin-left:auto}.mr-0\\.5{margin-right:.125rem}.mr-20{margin-right:5rem}.mr-3{margin-right:12px}.mt-4{margin-top:16px}.mt-5{margin-top:20px}.mt-8{margin-top:32px}.box-content{box-sizing:initial}.block{display:block}.inline-block{display:inline-block}.inline{display:inline}.flex{display:flex}.inline-flex{display:inline-flex}.hidden{display:none}.aspect-branded-button-icon{aspect-ratio:60/25}.aspect-shop-pay-icon{aspect-ratio:99/25}.size-0{height:0;width:0}.size-5{height:20px;width:20px}.size-6{height:24px;width:24px}.size-8{height:32px;width:32px}.size-full{height:100%;width:100%}.h-0{height:0}.h-10{height:40px}.h-3{height:12px}.h-4{height:16px}.h-4-5{height:18px}.h-5{height:20px}.h-8{height:32px}.h-9{height:36px}.h-\\[14px\\]{height:14px}.h-\\[22px\\]{height:22px}.h-auto{height:auto}.h-branded-button-icon{height:var(--font-paragraph--size,16px)}.h-full{height:100%}.h-px{height:1px}.max-h-8{max-height:32px}.max-h-\\[80vh\\]{max-height:80vh}.max-h-full{max-height:100%}.w-1{width:4px}.w-16{width:64px}.w-22{width:88px}.w-37{width:148px}.w-44{width:11rem}.w-55{width:220px}.w-6{width:24px}.w-85{width:340px}.w-9{width:36px}.w-\\[432px\\]{width:432px}.w-\\[59px\\]{width:59px}.w-auto{width:auto}.w-fit{width:fit-content}.w-full{width:100%}.w-pay-button{width:var(--shop-pay-button-width,260px)}.w-px{width:1px}.min-w-0{min-width:0}.min-w-100{min-width:400px}.min-w-85{min-width:340px}.min-w-max{min-width:max-content}.max-w-100{max-width:400px}.max-w-85{max-width:340px}.max-w-\\[40\\%\\]{max-width:40%}.max-w-full{max-width:100%}.flex-1{flex:1 1 0%}.flex-none{flex:none}.flex-shrink-0{flex-shrink:0}.flex-grow{flex-grow:1}.translate-x-0{--tw-translate-x:0px}.translate-x-0,.translate-y-0{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.translate-y-0{--tw-translate-y:0px}.translate-y-94{--tw-translate-y:376px}.translate-y-94,.translate-y-\\[9\\.375\\%\\]{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.translate-y-\\[9\\.375\\%\\]{--tw-translate-y:9.375%}.translate-y-full{--tw-translate-y:100%}.rotate-45,.translate-y-full{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.rotate-45{--tw-rotate:45deg}.scale-0{--tw-scale-x:0;--tw-scale-y:0}.scale-0,.scale-100{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.scale-100{--tw-scale-x:1;--tw-scale-y:1}.transform{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.animate-fade-in{animation:fadeIn 1s}@keyframes fadeOut{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(100%)}}.animate-fade-out{animation:fadeOut .3s ease-out}@keyframes follow{0%{transform:scaleY(1);width:100%}25%{transform:scaleY(1)}50%{transform:scaleY(1.2)}to{transform:scaleY(1);width:36px}}.animate-follow{animation:follow .3s cubic-bezier(.45,0,.15,1)}@keyframes pulse{50%{opacity:.5}}.animate-pulse{animation:pulse 2s cubic-bezier(.4,0,.6,1) infinite}@keyframes reveal{to{stroke-dashoffset:408}}.animate-reveal{animation:reveal 1.3s ease-in-out 0s infinite reverse}@keyframes slideUp{0%,20%{opacity:0;transform:translateY(100%)}to{opacity:1;transform:translateY(0)}}.animate-slide-up{animation:slideUp .3s ease-in}@keyframes spin{to{transform:rotate(1turn)}}.animate-spin{animation:spin 1.3s linear infinite}.cursor-pointer{cursor:pointer}.select-none{-webkit-user-select:none;user-select:none}.resize{resize:both}.list-none{list-style-type:none}.appearance-none{appearance:none}.flex-row{flex-direction:row}.flex-col{flex-direction:column}.flex-nowrap{flex-wrap:nowrap}.content-center{align-content:center}.items-end{align-items:flex-end}.items-center{align-items:center}.justify-start{justify-content:flex-start}.justify-end{justify-content:flex-end}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-0\\.5{gap:.125rem}.gap-1{gap:4px}.gap-2{gap:8px}.gap-3{gap:12px}.gap-text-icon{gap:.25em}.gap-x-1{column-gap:4px}.gap-x-1-5{column-gap:6px}.gap-x-3{column-gap:12px}.gap-x-4{column-gap:16px}.space-y-3>:not([hidden])~:not([hidden]){--tw-space-y-reverse:0;margin-bottom:calc(12px*var(--tw-space-y-reverse));margin-top:calc(12px*(1 - var(--tw-space-y-reverse)))}.space-y-4>:not([hidden])~:not([hidden]){--tw-space-y-reverse:0;margin-bottom:calc(16px*var(--tw-space-y-reverse));margin-top:calc(16px*(1 - var(--tw-space-y-reverse)))}.self-center{align-self:center}.overflow-hidden{overflow:hidden}.overflow-visible{overflow:visible}.overflow-y-auto{overflow-y:auto}.truncate{overflow:hidden;white-space:nowrap}.text-ellipsis,.truncate{text-overflow:ellipsis}.whitespace-nowrap{white-space:nowrap}.whitespace-pre-line{white-space:pre-line}.rounded-login-button{border-radius:var(--buttons-radius,var(--x-primary-button-border-radius,var(--shop-pay-button-border-radius,12px)))}.rounded-login-card{border-radius:var(--x-border-radius-large,12px)}.rounded-max{border-radius:999px}.rounded-md{border-radius:12px}.rounded-sm{border-radius:8px}.rounded-sm100{border-radius:10px}.rounded-xs{border-radius:4px}.rounded-xxl{border-radius:28px}.border{border-width:1px}.border-0{border-width:0}.border-\\[0\\.5px\\]{border-width:.5px}.border-b{border-bottom-width:1px}.border-t{border-top-width:1px}.border-solid{border-style:solid}.border-none{border-style:none}.border-checkout-branded{border-color:var(--x-textfield-border-color,#00000014)}.border-checkout-branded-dark{border-color:#ffffff14}.border-grayscale-l2{--tw-border-opacity:1;border-color:rgb(203 203 202/var(--tw-border-opacity))}.border-grayscale-l2l{--tw-border-opacity:1;border-color:rgb(227 227 227/var(--tw-border-opacity))}.border-white\\/20{border-color:#fff3}.bg-core-idp-social-logins{background-color:var(--x-social-color-background,#fff)}.bg-grayscale-l2{--tw-bg-opacity:1;background-color:rgb(203 203 202/var(--tw-bg-opacity))}.bg-grayscale-l3{--tw-bg-opacity:1;background-color:rgb(240 240 240/var(--tw-bg-opacity))}.bg-grayscale-l4{--tw-bg-opacity:1;background-color:rgb(242 244 245/var(--tw-bg-opacity))}.bg-grayscale-primary-light{--tw-bg-opacity:1;background-color:rgb(112 112 112/var(--tw-bg-opacity))}.bg-overlay{background-color:#0006}.bg-poppy-d1{--tw-bg-opacity:1;background-color:rgb(217 42 15/var(--tw-bg-opacity))}.bg-poppy-l2{--tw-bg-opacity:1;background-color:rgb(255 236 233/var(--tw-bg-opacity))}.bg-purple-primary{--tw-bg-opacity:1;background-color:rgb(84 51 235/var(--tw-bg-opacity))}.bg-transparent{background-color:initial}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-opacity-5{--tw-bg-opacity:0.05}.bg-gradient-to-r{background-image:linear-gradient(to right,var(--tw-gradient-stops))}.bg-none{background-image:none}.from-transparent{--tw-gradient-from:#0000 var(--tw-gradient-from-position);--tw-gradient-to:#0000 var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to)}.to-white{--tw-gradient-to:#fff var(--tw-gradient-to-position)}.fill-purple-primary{fill:#5433eb}.stroke-white{stroke:#fff}.p-0{padding:0}.p-3{padding:12px}.p-4{padding:16px}.p-6{padding:24px}.p-8{padding:32px}.p-shop-button{padding:max(var(--button-padding-block,16px),8px) max(var(--button-padding-inline,44px),16px)}.p-shop-login{padding:var(--x-spacing-base,14px)}.px-0{padding-left:0;padding-right:0}.px-11{padding-left:44px;padding-right:44px}.px-2{padding-left:8px;padding-right:8px}.px-3{padding-left:12px;padding-right:12px}.px-4{padding-left:16px;padding-right:16px}.px-5{padding-left:20px;padding-right:20px}.px-6{padding-left:24px;padding-right:24px}.py-1{padding-bottom:4px;padding-top:4px}.py-2-5{padding-bottom:10px;padding-top:10px}.py-2\\.5{padding-bottom:.625rem;padding-top:.625rem}.py-3{padding-bottom:12px;padding-top:12px}.py-4{padding-bottom:16px;padding-top:16px}.pb-0{padding-bottom:0}.pb-2{padding-bottom:8px}.pb-3{padding-bottom:12px}.pb-4{padding-bottom:16px}.pb-6{padding-bottom:24px}.pr-1\\.5{padding-right:.375rem}.pr-3{padding-right:12px}.pt-0{padding-top:0}.pt-3{padding-top:12px}.pt-4{padding-top:16px}.text-center{text-align:center}.align-middle{vertical-align:middle}.font-inherit{font-family:inherit}.font-sans{font-family:GTStandard-M,sans-serif}.font-system{font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.text-body-large{font-size:16px;font-weight:450;letter-spacing:-.5px;line-height:22px}.text-body-small{font-weight:450}.text-body-small,.text-body-title-small{font-size:14px;letter-spacing:-.2px;line-height:18px}.text-body-title-small{font-weight:500}.text-branded-button{font-size:var(--font-paragraph--size,16px);font-weight:500;letter-spacing:-.5px;line-height:var(--font-paragraph--line-height,22px)}.text-button-large{font-size:16px;font-weight:600;letter-spacing:-.5px;line-height:22px}.text-button-medium{font-size:14px;font-weight:600;letter-spacing:-.2px;line-height:18px}.text-caption{font-size:12px;font-weight:450;letter-spacing:-.2px;line-height:16px}.text-subtitle{font-size:18px;font-weight:500;letter-spacing:-1px;line-height:20px}.font-bold{font-weight:700}.font-light{font-weight:300}.font-medium{font-weight:500}.font-normal{font-weight:400}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.leading-6{line-height:1.5rem}.leading-normal{line-height:1.5}.leading-snug{line-height:1.375}.tracking-wider{letter-spacing:.05em}.text-black{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.text-grayscale-d0{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.text-grayscale-d1{--tw-text-opacity:1;color:rgb(64 64 64/var(--tw-text-opacity))}.text-grayscale-d2\\/70{color:#121212b3}.text-grayscale-l1{--tw-text-opacity:1;color:rgb(168 168 167/var(--tw-text-opacity))}.text-grayscale-l4{--tw-text-opacity:1;color:rgb(242 244 245/var(--tw-text-opacity))}.text-grayscale-primary-light{--tw-text-opacity:1;color:rgb(112 112 112/var(--tw-text-opacity))}.text-poppy-d1{--tw-text-opacity:1;color:rgb(217 42 15/var(--tw-text-opacity))}.text-purple-primary{--tw-text-opacity:1;color:rgb(84 51 235/var(--tw-text-opacity))}.text-white{--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity))}.underline{text-decoration-line:underline}.no-underline{text-decoration-line:none}.opacity-0{opacity:0}.opacity-100{opacity:1}.shadow-card{--tw-shadow:0 4px 12px #0000000a;--tw-shadow-colored:0 4px 12px var(--tw-shadow-color)}.shadow-card,.shadow-lg{box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.shadow-lg{--tw-shadow:0px 8px 30px 0px #0006;--tw-shadow-colored:0px 8px 30px 0px var(--tw-shadow-color)}.shadow-sm{--tw-shadow:0px 1px 4px 0px #0000001a;--tw-shadow-colored:0px 1px 4px 0px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.ring-1{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.ring-inset{--tw-ring-inset:inset}.ring-black\\/5{--tw-ring-color:#0000000d}.blur{--tw-blur:blur(8px)}.blur,.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.backdrop-blur-xl{--tw-backdrop-blur:blur(24px);backdrop-filter:var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia)}.transition{transition-duration:.15s;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke,opacity,box-shadow,transform,filter,backdrop-filter;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-\\[height\\]{transition-duration:.15s;transition-property:height;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-all{transition-duration:.15s;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-colors{transition-duration:.15s;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-opacity{transition-duration:.15s;transition-property:opacity;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-transform{transition-duration:.15s;transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1)}.duration-300{transition-duration:.3s}.duration-400{transition-duration:.4s}.ease-cubic-modal{transition-timing-function:cubic-bezier(.32,.72,0,1)}.ease-in-out{transition-timing-function:cubic-bezier(.4,0,.2,1)}.ease-out{transition-timing-function:cubic-bezier(0,0,.2,1)}.will-change-transform{will-change:transform}.forced-color-adjust-none{forced-color-adjust:none}.stroke-dasharray-reveal{stroke-dasharray:136}.stroke-dashoffset-reveal{stroke-dashoffset:136}.\\[interpolate-size\\:allow-keywords\\]{interpolate-size:allow-keywords}.first_pt-0:first-child{padding-top:0}.last_border-b-0:last-child{border-bottom-width:0}.last_pb-0:last-child{padding-bottom:0}.hover_text-black:hover{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.hover_text-grayscale-d0:hover{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.hover_opacity-70:hover{opacity:.7}.hover_opacity-80:hover{opacity:.8}.hover_outline-none:hover{outline:2px solid #0000;outline-offset:2px}.focus_text-black:focus{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.focus_text-grayscale-d0:focus{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.focus_opacity-70:focus{opacity:.7}.focus_outline-none:focus{outline:2px solid #0000;outline-offset:2px}.focus_outline-0:focus{outline-width:0}.focus_ring:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus_ring-purple-l1:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.focus-visible_outline-none:focus-visible{outline:2px solid #0000;outline-offset:2px}.focus-visible_ring:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus-visible_ring-purple-l1:focus-visible{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.active_text-black:active{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.active_text-grayscale-d0:active{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.active_opacity-70:active{opacity:.7}.active_outline-none:active{outline:2px solid #0000;outline-offset:2px}.hover_enabled_bg-purple-d0:enabled:hover{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.hover_enabled_bg-transparent:enabled:hover{background-color:initial}.focus_enabled_outline-none:enabled:focus{outline:2px solid #0000;outline-offset:2px}.focus_enabled_ring:enabled:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus_enabled_ring-purple-l1:enabled:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.focus-visible_enabled_outline-none:enabled:focus-visible{outline:2px solid #0000;outline-offset:2px}.focus-visible_enabled_ring:enabled:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus-visible_enabled_ring-purple-l1:enabled:focus-visible{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.disabled_opacity-50:disabled{opacity:.5}.group:hover .group-hover_bg-purple-d0{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.group:hover .group-hover_text-grayscale-l2l{--tw-text-opacity:1;color:rgb(227 227 227/var(--tw-text-opacity))}.aria-hidden_opacity-0[aria-hidden=true]{opacity:0}.data-hidden_invisible[data-visible=false]{visibility:hidden}.data-hidden_absolute[data-visible=false]{position:absolute}.data-hidden_inset-0[data-visible=false]{inset:0}.data-hidden_hidden[data-visible=false]{display:none}.data-hidden_opacity-0[data-visible=false]{opacity:0}.group[data-visible=false] .group-data-hidden_translate-x-full{--tw-translate-x:100%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.group[data-visible=false] .group-data-hidden_animate-none{animation:none}.group[data-visible=false] .group-data-hidden_opacity-0{opacity:0}@media (prefers-reduced-motion:reduce){.motion-reduce_animate-none{animation:none}.motion-reduce_transition-none{transition-property:none}.motion-reduce_transition-opacity{transition-duration:.15s;transition-property:opacity;transition-timing-function:cubic-bezier(.4,0,.2,1)}.motion-reduce_duration-0{transition-duration:0s}}@media (max-width:448px){.sm_absolute{position:absolute}.sm_inset-x-0{left:0;right:0}.sm_bottom-0{bottom:0}.sm_top-auto{top:auto}.sm_hidden{display:none}.sm_max-w-none{max-width:none}.sm_translate-y-0{--tw-translate-y:0px}.sm_translate-y-0,.sm_translate-y-full{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm_translate-y-full{--tw-translate-y:100%}.sm_scale-100{--tw-scale-x:1;--tw-scale-y:1;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm_rounded-none{border-radius:0}.sm_rounded-b-none{border-bottom-left-radius:0;border-bottom-right-radius:0}}';

function kt({
    children: e,
    instanceId: t,
    type: n,
    variant: o
}) {
    const r = Te(null),
        [i, a] = Me(null),
        {
            notify: s
        } = wt();
    return Oe((() => {
        a(r.current.attachShadow({
            mode: "open"
        }))
    }), []), Oe((() => {
        if (i) {
            const e = new CSSStyleSheet;
            e.replace(xt).then((() => {
                i.adoptedStyleSheets = [e]
            })).catch((e => {
                s(new Error(`Failed to adopt stylesheets for portal provider: ${e}`))
            }))
        }
    }), [i, s]), pe("div", {
        "data-nametag": "shop-portal-provider",
        "data-portal-instance-id": t,
        "data-type": n,
        "data-variant": o,
        ref: r,
        children: i && it(e, i)
    })
}
const Et = de({
        analyticsData: {
            analyticsTraceId: ""
        },
        getTrekkieAttributes: () => y(void 0, void 0, void 0, (function*() {
            return Promise.resolve({})
        })),
        produceMonorailEvent: () => {
            throw new Error("Invalid attempt to call produceMonorailEvent outside of context.")
        },
        trackModalStateChange: () => {
            throw new Error("Invalid attempt to call trackModalStateChange outside of context.")
        },
        trackPageImpression: () => y(void 0, void 0, void 0, (function*() {
            throw new Error("Invalid attempt to call trackPageImpression outside of context.")
        })),
        trackUserAction: () => {
            throw new Error("Invalid attempt to call trackUserAction outside of context.")
        },
        trackPostMessageTransmission: () => {
            throw new Error("Invalid attempt to call trackPostMessageTransmission outside of context.")
        }
    }),
    St = () => Le(Et),
    Pt = de({
        log: () => {
            throw new Error("Invalid attempt to call log outside of context.")
        },
        recordCounter: () => {
            throw new Error("Invalid attempt to call recordCounter outside of context.")
        },
        recordGauge: () => {
            throw new Error("Invalid attempt to call recordGauge outside of context.")
        },
        recordHistogram: () => {
            throw new Error("Invalid attempt to call recordHistogram outside of context.")
        },
        client: void 0
    }),
    Mt = () => Le(Pt),
    jt = de({
        devMode: !1,
        element: null,
        instanceId: ""
    }),
    Ct = () => Le(jt),
    Ot = de({
        dispatch: () => {
            throw new Error("Invalid attempt to call dispatch outside of AuthorizeStateProvider")
        },
        loaded: !1,
        modalDismissible: !1,
        modalForceHidden: !1,
        modalVisible: !1,
        uiRendered: !1
    }),
    Tt = {
        loaded: !1,
        uiRendered: !1,
        modalDismissible: !1,
        modalForceHidden: !1,
        modalVisible: !1
    },
    It = ({
        children: e
    }) => {
        const {
            leaveBreadcrumb: t,
            notify: n
        } = wt(), {
            trackModalStateChange: o
        } = St(), r = Ae((({
            action: e,
            previousState: r,
            state: i
        }) => {
            const a = r.modalVisible !== i.modalVisible,
                s = i.modalVisible ? "shown" : "hidden";
            if ("loaded" === e.type && (o({
                    currentState: "loaded",
                    reason: "event_loaded"
                }), t("iframe loaded", {}, "state")), a) switch (e.type) {
                case "loaded":
                    o({
                        currentState: s,
                        reason: "event_loaded_with_auto_open"
                    });
                    break;
                case "windoidOpened":
                    o({
                        currentState: s,
                        dismissMethod: "windoid_continue",
                        reason: "event_windoid_opened"
                    });
                    break;
                case "showModal":
                    o({
                        currentState: s,
                        reason: e.reason
                    });
                    break;
                case "hideModal":
                    o({
                        currentState: s,
                        dismissMethod: e.dismissMethod,
                        reason: e.reason
                    });
                    break;
                case "reset":
                    o({
                        currentState: s,
                        reason: "event_restarted"
                    });
                    break;
                default:
                    n(new Error(`Could not determine state change reason for action: ${e}`))
            }
        }), [t, n, o]), i = Ae(((e, t) => {
            const n = ((e, t) => {
                switch (t.type) {
                    case "hideModal":
                        return Object.assign(Object.assign({}, e), {
                            modalVisible: !1
                        });
                    case "loaded":
                        {
                            const n = t.payload.autoOpen && t.payload.sessionDetected && !e.modalVisible;
                            return Object.assign(Object.assign(Object.assign({}, e), {
                                loaded: !0
                            }), n && !e.modalForceHidden && {
                                modalDismissible: !1,
                                modalVisible: !0
                            })
                        }
                    case "modalDismissible":
                        return Object.assign(Object.assign({}, e), {
                            modalDismissible: !0
                        });
                    case "reset":
                        return Object.assign(Object.assign({}, Tt), {
                            modalForceHidden: e.modalForceHidden
                        });
                    case "uiRendered":
                        return Object.assign(Object.assign({}, e), {
                            uiRendered: !0
                        });
                    case "showModal":
                        return e.modalForceHidden && "user_button_clicked" !== t.reason ? e : Object.assign(Object.assign({}, e), {
                            modalDismissible: !1,
                            modalForceHidden: !1,
                            modalVisible: !0
                        });
                    case "windoidClosed":
                        return Object.assign(Object.assign({}, e), {
                            modalForceHidden: !1
                        });
                    case "windoidOpened":
                        return Object.assign(Object.assign({}, e), {
                            modalForceHidden: !0,
                            modalVisible: !1
                        });
                    default:
                        return e
                }
            })(e, t);
            return r({
                action: t,
                previousState: e,
                state: n
            }), n
        }), [r]), [a, s] = je(i, {
            loaded: !1,
            modalDismissible: !1,
            modalForceHidden: !1,
            modalVisible: !1,
            uiRendered: !1
        }), l = Ne((() => {
            const {
                loaded: e,
                modalDismissible: t,
                modalForceHidden: n,
                modalVisible: o,
                uiRendered: r
            } = a;
            return {
                dispatch: s,
                loaded: e,
                modalDismissible: t,
                modalForceHidden: n,
                modalVisible: o,
                uiRendered: r
            }
        }), [s, a]);
        return pe(Ot.Provider, {
            value: l,
            children: e
        })
    };

function Nt(e) {
    return At(e).map((e => e instanceof Error ? e : new Lt(`[${typeof e}] ${function(e){if("string"!=typeof e)try{return JSON.stringify(e)??typeof e}catch{}return`
        $ {
            e
        }
        `}(e).slice(0,10240)}`)))
}

function At(e, t = 0) {
    return t >= 20 ? [e, "Truncated cause stack"] : e instanceof Error && e.cause ? [e, ...At(e.cause, t + 1)] : [e]
}
var Lt = class extends Error {
        name = "BugsnagInvalidError"
    },
    Rt = /^\s*at .*(\S+:\d+|\(native\))/m,
    zt = /^(eval@)?(\[native code])?$/;

function Dt(e) {
    return e.stack ? e.stack.match(Rt) ? function(e) {
        return e.stack.split("\n").filter((e => !!e.match(Rt))).map((e => {
            let t = e.replace(/^\s+/, "").replace(/^.*?\s+/, ""),
                n = t.match(/ (\(.+\)$)/);
            t = n ? t.replace(n[0], "") : t;
            let o = Ut(n ? n[1] : t);
            return {
                method: n && t || void 0,
                file: ["eval", "<anonymous>"].indexOf(o[0]) > -1 ? void 0 : o[0],
                lineNumber: o[1],
                columnNumber: o[2]
            }
        }))
    }(e) : function(e) {
        return e.stack.split("\n").filter((e => !e.match(zt))).map((e => {
            if (-1 === e.indexOf("@") && -1 === e.indexOf(":")) return {
                method: e
            };
            let t = /((.*".+"[^@]*)?[^@]*)(?:@)/,
                n = e.match(t),
                o = n && n[1] ? n[1] : void 0,
                r = Ut(e.replace(t, ""));
            return {
                method: o,
                file: r[0],
                lineNumber: r[1],
                columnNumber: r[2]
            }
        }))
    }(e) : []
}

function Ut(e) {
    if (-1 === e.indexOf(":")) return [e];
    let t = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/[()]/g, ""));
    return [t[1], t[2] ? Number(t[2]) : void 0, t[3] ? Number(t[3]) : void 0]
}
var Ft = class {
    breadcrumbs = [];
    apiKey;
    plugins;
    appId;
    appType;
    appVersion;
    releaseStage;
    locale;
    userAgent;
    metadata;
    persistedMetadata;
    onError;
    onPostErrorListeners = [];
    endpoints;
    session;
    constructor(e) {
        this.apiKey = e.apiKey, this.appType = e.appType, this.appId = e.appId, this.appVersion = e.appVersion, this.releaseStage = e.releaseStage, this.locale = e.locale, this.userAgent = e.userAgent, this.metadata = e.metadata, this.onError = e.onError, this.persistedMetadata = {}, this.endpoints = e.endpoints ? ? {
            notify: "https://error-analytics-production.shopifysvc.com",
            sessions: "https://error-analytics-sessions-production.shopifysvc.com/observeonly"
        }, this.plugins = e.plugins ? ? [], this.plugins.forEach((e => e.load(this))), this.leaveBreadcrumb("Bugsnag started", void 0, "state"), (e.withSessionTracking ? ? 1) && (this.session = {
            id: this.getRandomUUID(),
            startedAt: (new Date).toISOString(),
            events: {
                handled: 0,
                unhandled: 0
            }
        }, this.startSession())
    }
    addMetadata(e) {
        for (let t of Object.keys(e)) this.persistedMetadata[t] = e[t]
    }
    getSessionId() {
        return this.session ? .id
    }
    leaveBreadcrumb(e, t, n = "manual") {
        this.breadcrumbs.push({
            name: e,
            metaData: t,
            type: n,
            timestamp: (new Date).toISOString()
        })
    }
    notify(e, {
        errorClass: t,
        severity: n,
        severityType: o,
        handled: r = !0,
        metadata: i,
        context: a,
        groupingHash: s
    } = {}) {
        let l = Nt(e),
            c = { ...this.metadata,
                ...this.persistedMetadata,
                ...i
            },
            d = this.buildBugsnagEvent(l, {
                errorClass: t,
                severityType: o,
                handled: r,
                severity: n,
                metadata: c,
                context: a,
                groupingHash: s
            });
        if ((this.onError ? .(d, e) ? ? 1) && "development" !== this.releaseStage) {
            this.updateAndAppendSessionInformation(d);
            let e = this.sendToBugsnag(d);
            return this.onPostErrorListeners.forEach((e => e(d))), e
        }
        return Promise.resolve()
    }
    addOnPostError(e) {
        this.onPostErrorListeners.push(e)
    }
    updateAndAppendSessionInformation(e) {
        this.session && (e.unhandled ? this.session.events.unhandled++ : this.session.events.handled++, e.session = this.session)
    }
    buildBugsnagEvent(e, {
        errorClass: t,
        severity: n = "error",
        severityType: o = "handledException",
        handled: r,
        metadata: i = {},
        context: a,
        groupingHash: s
    }) {
        let l = (new Date).toISOString(),
            {
                breadcrumbs: c,
                appId: d,
                appType: u,
                appVersion: p,
                releaseStage: h,
                locale: f,
                userAgent: m
            } = this,
            v = e.map(((e, n) => ({
                errorClass: 0 === n ? t ? ? e.name : e.name,
                stacktrace: $t(d, e),
                message: e.message,
                type: "browserjs"
            })));
        return {
            payloadVersion: "5",
            exceptions: v,
            severity: n,
            severityReason: {
                type: o
            },
            unhandled: !r,
            app: {
                id: d,
                type: u,
                version: p,
                releaseStage: h
            },
            device: {
                time: l,
                locale: f,
                userAgent: m
            },
            breadcrumbs: c,
            context: a,
            metaData: i,
            groupingHash: s
        }
    }
    async startSession() {
        if ("development" === this.releaseStage) return void console.log("Skipping error logging session tracking in development mode");
        let {
            apiKey: e
        } = this, t = {
            notifier: {
                name: "Bugsnag JavaScript",
                version: "7.22.2",
                url: "https://github.com/bugsnag/bugsnag-js"
            },
            app: {
                version: this.appVersion,
                releaseStage: this.releaseStage,
                type: this.appType
            },
            device: {
                id: this.appId,
                locale: this.locale,
                userAgent: this.userAgent
            },
            sessions: [this.session]
        };
        try {
            await fetch(this.endpoints.sessions, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Bugsnag-Api-Key": e,
                    "Bugsnag-Payload-Version": "5",
                    "Bugsnag-Sent-At": this.session ? .startedAt ? ? (new Date).toISOString()
                },
                body: JSON.stringify(t)
            })
        } catch (e) {
            console.warn("[bugsnag-light] failed to start session"), console.warn(e)
        }
    }
    async sendToBugsnag(e) {
        let {
            apiKey: t
        } = this, n = {
            apiKey: t,
            notifier: {
                name: "Bugsnag JavaScript",
                version: "7.22.2",
                url: "https://github.com/bugsnag/bugsnag-js"
            },
            events: [e]
        };
        try {
            await fetch(this.endpoints.notify, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Bugsnag-Api-Key": t,
                    "Bugsnag-Payload-Version": "5",
                    "Bugsnag-Sent-At": e.device.time
                },
                body: JSON.stringify(n)
            })
        } catch (e) {
            console.warn("[bugsnag-light] failed to send an event"), console.warn(e)
        }
    }
    getRandomUUID() {
        try {
            return crypto.randomUUID()
        } catch {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e => {
                let t = 16 * Math.random() | 0;
                return ("x" === e ? t : 3 & t | 8).toString(16)
            }))
        }
    }
};

function $t(e, t) {
    let n = Dt(t).map((t => {
        let n = t.file ? .includes(e);
        return {
            method: t.method ? ? "",
            file: t.file ? ? "",
            lineNumber: t.lineNumber ? ? 0,
            columnNumber: t.columnNumber,
            inProject: n
        }
    }));
    if (t instanceof Lt) {
        let e = n.findIndex((e => e.method.endsWith("notify")));
        e > -1 && (n = n.slice(e + 1))
    }
    return n
}
const Bt = "undefined" == typeof navigator ? {
    languages: [],
    userAgent: "",
    userAgentData: {},
    userLanguage: "",
    credentials: {}
} : navigator;
var Ht = "e35d7136cee78d344ccffdbd5ca710fa";

function Vt(e, t) {
    if (!{}.hasOwnProperty.call(e, t)) throw new TypeError("attempted to use private field on non-instance");
    return e
}
var Wt = 0;

function qt(e) {
    return "__private_" + Wt++ + "_" + e
}

function Kt(e) {
    return Object.entries(e).map((([e, t]) => ({
        key: e,
        value: {
            stringValue: String(t)
        }
    })))
}

function Gt(e) {
    if (Array.isArray(e)) return {
        arrayValue: {
            values: e.map((e => Gt(e)))
        }
    };
    switch (typeof e) {
        case "boolean":
            return {
                boolValue: Boolean(e)
            };
        case "number":
            return {
                doubleValue: Number(e)
            };
        default:
            return {
                stringValue: String(e)
            }
    }
}
const Xt = function(e, t, n) {
    const o = [0];
    for (let r = 0; r < n; r++) {
        const n = Math.floor(e * t ** r);
        o.push(n)
    }
    return o
}(5, 2, 12);
var Yt = qt("exporter"),
    Jt = qt("attributes"),
    Zt = qt("metrics"),
    Qt = qt("logs");
class en {
    constructor({
        exporter: e,
        attributes: t
    }) {
        Object.defineProperty(this, Yt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Jt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Zt, {
            writable: !0,
            value: []
        }), Object.defineProperty(this, Qt, {
            writable: !0,
            value: []
        }), Vt(this, Yt)[Yt] = e, Vt(this, Jt)[Jt] = null != t ? t : {}
    }
    addAttributes(e) {
        Vt(this, Jt)[Jt] = { ...Vt(this, Jt)[Jt],
            ...e
        }
    }
    histogram({
        name: e,
        value: t,
        unit: n,
        bounds: o,
        attributes: r,
        scale: i,
        requiresKeepalive: a
    }) {
        const s = 1e6 * Date.now();
        o ? Vt(this, Zt)[Zt].push({
            name: e,
            type: "histogram",
            value: t,
            unit: n,
            timeUnixNano: s,
            attributes: r,
            bounds: o,
            requiresKeepalive: a
        }) : Vt(this, Zt)[Zt].push({
            name: e,
            type: "exponential_histogram",
            value: t,
            unit: n,
            timeUnixNano: s,
            attributes: r,
            scale: i,
            requiresKeepalive: a
        })
    }
    counter({
        name: e,
        value: t,
        unit: n,
        attributes: o,
        requiresKeepalive: r
    }) {
        const i = 1e6 * Date.now();
        Vt(this, Zt)[Zt].push({
            name: e,
            type: "counter",
            value: t,
            unit: n,
            timeUnixNano: i,
            attributes: o,
            requiresKeepalive: r
        })
    }
    gauge({
        name: e,
        value: t,
        unit: n,
        attributes: o,
        requiresKeepalive: r
    }) {
        const i = 1e6 * Date.now();
        Vt(this, Zt)[Zt].push({
            name: e,
            type: "gauge",
            value: t,
            unit: n,
            timeUnixNano: i,
            attributes: o,
            requiresKeepalive: r
        })
    }
    log({
        body: e,
        attributes: t,
        requiresKeepalive: n
    }) {
        const o = 1e6 * Date.now();
        Vt(this, Qt)[Qt].push({
            timeUnixNano: o,
            body: e,
            attributes: t,
            requiresKeepalive: n
        })
    }
    async exportMetrics() {
        Vt(this, Zt)[Zt].forEach((e => {
            e.attributes = { ...Vt(this, Jt)[Jt],
                ...e.attributes
            }
        }));
        const e = Vt(this, Zt)[Zt];
        Vt(this, Zt)[Zt] = [], await this.exportByKeepalive(e, ((e, t) => Vt(this, Yt)[Yt].exportMetrics(this.aggregateMetrics(e), t)))
    }
    async exportLogs() {
        const e = Vt(this, Qt)[Qt];
        Vt(this, Qt)[Qt] = [], await this.exportByKeepalive(e, ((e, t) => Vt(this, Yt)[Yt].exportLogs(this.formatLogs(e), t)))
    }
    aggregateMetrics(e) {
        const t = {};
        return e.forEach((e => {
            switch (e.type) {
                case "histogram":
                    ! function(e, t) {
                        var n;
                        const {
                            name: o,
                            value: r,
                            unit: i,
                            timeUnixNano: a,
                            attributes: s
                        } = t, l = null !== (n = t.bounds) && void 0 !== n ? n : Xt, c = new Array(l.length + 1).fill(0);
                        e[o] || = {
                            name: o,
                            unit: i || "1",
                            histogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        };
                        for (let e = 0; e < c.length; e++) {
                            const t = l[e];
                            if (void 0 === t) c[e] = 1;
                            else if (r <= t) {
                                c[e] = 1;
                                break
                            }
                        }
                        e[o].histogram.dataPoints.push({
                            startTimeUnixNano: a,
                            timeUnixNano: a,
                            count: 1,
                            sum: r,
                            min: r,
                            max: r,
                            bucketCounts: c,
                            explicitBounds: l,
                            attributes: Kt(null != s ? s : {})
                        })
                    }(t, e);
                    break;
                case "exponential_histogram":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a,
                            scale: s
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            exponentialHistogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        };
                        const l = o <= 0 ? 0 : o,
                            c = s || 3,
                            d = 2 ** c / Math.log(2),
                            u = Math.ceil(Math.log(o) * d) - 1,
                            p = o <= 0 ? 1 : 0,
                            h = {
                                offset: 0,
                                bucketCounts: []
                            },
                            f = {
                                offset: o > 0 ? u : 0,
                                bucketCounts: o > 0 ? [1] : []
                            };
                        e[n].exponentialHistogram.dataPoints.push({
                            attributes: Kt(null != a ? a : {}),
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            count: 1,
                            sum: l,
                            scale: c,
                            zeroCount: p,
                            positive: f,
                            negative: h,
                            min: l,
                            max: l,
                            zeroThreshold: 0
                        })
                    }(t, e);
                    break;
                case "counter":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            sum: {
                                aggregationTemporality: 1,
                                isMonotonic: !0,
                                dataPoints: []
                            }
                        }, e[n].sum.dataPoints.push({
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            asDouble: o,
                            attributes: Kt(null != a ? a : {})
                        })
                    }(t, e);
                    break;
                case "gauge":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            gauge: {
                                dataPoints: []
                            }
                        }, e[n].gauge.dataPoints.push({
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            asDouble: o,
                            attributes: Kt(null != a ? a : {})
                        })
                    }(t, e)
            }
        })), Object.values(t)
    }
    async exportByKeepalive(e, t) {
        if (0 === e.length) return;
        const n = [],
            o = [];
        e.forEach((e => {
            var t;
            null === (t = e.requiresKeepalive) || void 0 === t || t ? n.push(e) : o.push(e)
        }));
        const r = [n.length > 0 ? t(n, {
            keepalive: !0
        }) : void 0, o.length > 0 ? t(o, {
            keepalive: !1
        }) : void 0].filter((e => void 0 !== e));
        await Promise.all(r)
    }
    formatLogs(e) {
        return e.map((e => {
            const t = {
                timeUnixNano: e.timeUnixNano,
                observedTimeUnixNano: e.timeUnixNano,
                attributes: (n = { ...Vt(this, Jt)[Jt],
                    ...e.attributes
                }, Object.entries(n).map((([e, t]) => ({
                    key: e,
                    value: Gt(t)
                }))))
            };
            var n;
            return e.body && (t.body = {
                stringValue: e.body
            }), t
        }))
    }
}
var tn, nn, on = qt("url"),
    rn = qt("serviceName"),
    an = qt("logger"),
    sn = qt("fetchFn"),
    ln = qt("maxPayloadSizeBytes");
class cn {
    constructor(e, t, n) {
        var o;
        Object.defineProperty(this, on, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, rn, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, an, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, sn, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, ln, {
            writable: !0,
            value: void 0
        }), Vt(this, on)[on] = e.replace(/\/v1\/(logs|metrics|traces)\/?$/, ""), Vt(this, rn)[rn] = t, Vt(this, an)[an] = null == n ? void 0 : n.logger, Vt(this, sn)[sn] = null == n ? void 0 : n.fetchFn, Vt(this, ln)[ln] = null !== (o = null == n ? void 0 : n.maxPayloadSizeBytes) && void 0 !== o ? o : 51200
    }
    async exportMetrics(e, t) {
        var n;
        const o = null === (n = null == t ? void 0 : t.keepalive) || void 0 === n || n;
        await this.exportBatches("/v1/metrics", [...e], (e => ({
            resourceMetrics: [{
                resource: {
                    attributes: [{
                        key: "service.name",
                        value: {
                            stringValue: Vt(this, rn)[rn]
                        }
                    }]
                },
                scopeMetrics: [{
                    scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: []
                    },
                    metrics: e
                }]
            }]
        })), o)
    }
    async exportLogs(e, t) {
        var n;
        const o = null === (n = null == t ? void 0 : t.keepalive) || void 0 === n || n;
        await this.exportBatches("/v1/logs", [...e], (e => ({
            resourceLogs: [{
                resource: {
                    attributes: [{
                        key: "service.name",
                        value: {
                            stringValue: Vt(this, rn)[rn]
                        }
                    }]
                },
                scopeLogs: [{
                    scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: []
                    },
                    logRecords: e
                }]
            }]
        })), o)
    }
    async exportTo(e, t, n) {
        var o;
        const r = JSON.stringify(e),
            i = (new TextEncoder).encode(r).length;
        if (i > Vt(this, ln)[ln]) throw new un(`Payload size ${i} exceeds ${Vt(this,ln)[ln]} bytes`);
        const a = await this.exporterFetch()(`${Vt(this,on)[on]}${t}`, {
            method: "POST",
            keepalive: n,
            headers: {
                "Content-Type": "application/json"
            },
            body: r
        });
        if (null === (o = Vt(this, an)[an]) || void 0 === o || o.log({
                status: a.status
            }), !a.ok) {
            if (400 === a.status) {
                const e = await a.text();
                throw new dn(`Invalid OpenTelemetry Data: ${e}`)
            }
            if (429 === a.status || 503 === a.status) {
                const t = await a.text(),
                    n = a.headers.get("Retry-After"),
                    o = n ? {
                        seconds: Number(n)
                    } : void 0;
                throw new dn("Server did not accept data", {
                    errorData: t,
                    retryAfter: o,
                    body: e
                })
            }
            if (401 === a.status || 403 === a.status) {
                const t = await a.text();
                throw new pn(`Authentication failed: ${a.status} ${401===a.status?"Unauthorized":"Forbidden"}`, {
                    errorData: t,
                    body: e
                })
            }
            throw new dn(`Server responded with ${a.status}`)
        }
    }
    exporterFetch() {
        return Vt(this, sn)[sn] || fetch
    }
    async exportBatches(e, t, n, o) {
        let r = t.length;
        for (; t.length > 0;) try {
            const i = t.slice(0, r);
            await this.exportTo(n(i), e, o), t.splice(0, r)
        } catch (e) {
            if (!(e instanceof un && r > 1)) throw e;
            r = Math.ceil(r / 2)
        }
    }
}
class dn extends Error {
    constructor(e, t) {
        super(e), this.metadata = void 0, this.name = "OpenTelemetryClientError", this.metadata = t
    }
}
class un extends Error {
    constructor(...e) {
        super(...e), this.name = "PayloadTooLargeError"
    }
}
class pn extends Error {
    constructor(e, t) {
        super(e), this.name = "AuthenticationFailedError", this.metadata = void 0, this.name = "AuthenticationFailedError", this.metadata = t
    }
}
class hn extends en {
    counter(e) {
        super.counter(e), this.exportMetrics()
    }
    gauge(e) {
        super.gauge(e), this.exportMetrics()
    }
    histogram(e) {
        super.histogram(e), this.exportMetrics()
    }
    log(e) {
        super.log(e), this.exportLogs()
    }
}
class fn {
    constructor({
        exporter: e,
        getKeepalive: t
    }) {
        tn.set(this, void 0), nn.set(this, void 0), w(this, tn, e, "f"), w(this, nn, t, "f")
    }
    exportMetrics(e, t) {
        return y(this, void 0, void 0, (function*() {
            var n;
            try {
                yield b(this, tn, "f").exportMetrics(e, Object.assign(Object.assign({}, t), {
                    keepalive: b(this, nn, "f").call(this)
                }))
            } catch (o) {
                if (o instanceof dn) {
                    const r = null === (n = o.metadata) || void 0 === n ? void 0 : n.retryAfter;
                    if (r) return void(yield new Promise((n => {
                        setTimeout((() => this.exportMetrics(e, t).finally(n)), 1e3 * r.seconds)
                    })))
                }
                throw o
            }
        }))
    }
    exportLogs(e, t) {
        return y(this, void 0, void 0, (function*() {
            var n;
            try {
                yield b(this, tn, "f").exportLogs(e, Object.assign(Object.assign({}, t), {
                    keepalive: b(this, nn, "f").call(this)
                }))
            } catch (o) {
                if (o instanceof dn) {
                    const r = null === (n = o.metadata) || void 0 === n ? void 0 : n.retryAfter;
                    if (r) return void(yield new Promise((n => {
                        setTimeout((() => this.exportLogs(e, t).finally(n)), 1e3 * r.seconds)
                    })))
                }
                throw o
            }
        }))
    }
}
tn = new WeakMap, nn = new WeakMap;
const mn = {
    blockedRequest: "Blocked Request",
    emptyeEventCreatedAtMs: "event_created_at_ms metadata field cannot be empty",
    errorParsingCreatedAtMs: "Error parsing: X-Monorail-Edge-Event-Created-At-Ms",
    failedToReadRequestBody: "Failed to read request body",
    incorrectContentType: "Incorrect Content-Type. Expected: application/json or text/plain",
    methodNotAllowed: "Method Not Allowed",
    noPermissionToGetURL: "Your client does not have permission to get URL",
    noResponseFromEdge: "No response from edge",
    schemaValidationError: "Schema validation error"
};

function vn() {
    {
        const e = new cn("https://otlp-http-production.shopifysvc.com/v1/metrics", "shop-js");
        return new fn({
            exporter: e,
            getKeepalive: () => "readyState" in n && "complete" === n.readyState
        })
    }
}
const gn = ["Load failed", "Failed to fetch", "when attempting to fetch resource"],
    _n = ["Failed to fetch dynamically imported module", "Importing a module script failed"],
    yn = new Set(["ShopPayPaymentRequest", "ShopPayPaymentRequestButton", "ShopPayPaymentRequestLogin"]),
    bn = ["NotFoundError", "NotSupportedError", "ReferenceError", "SyntaxError", "TypeError"],
    wn = e => {
        const {
            errorClass: t,
            message: n
        } = e;
        return Boolean("NetworkError" === t || gn.some((e => null == n ? void 0 : n.includes(e))) || (o = n, Boolean((null == o ? void 0 : o.includes("A network failure may have prevented the request from completing")) || (null == o ? void 0 : o.includes("Backpressure applied")))));
        var o
    },
    xn = ({
        event: e,
        metadata: t,
        onNetworkError: o
    }) => {
        var r, i, a, s, l, d, u;
        const p = e.exceptions[0];
        if (!p) return !1;
        const h = null === (r = t.custom) || void 0 === r ? void 0 : r.feature;
        if (((e, t) => {
                const {
                    errorClass: n,
                    message: o
                } = e, r = "SecurityError" === n && (null == o ? void 0 : o.includes("Failed to read the 'cookie' property from 'Document'")) && (null == o ? void 0 : o.includes("sandboxed")), i = "SecurityError" === n && (null == o ? void 0 : o.includes("Blocked a frame with origin")) && (null == o ? void 0 : o.includes("from accessing a cross-origin frame")), a = "string" == typeof t && yn.has(t), s = e.stacktrace.some((e => e.inProject));
                return Boolean(!s || r || i && a)
            })(p, "string" == typeof h ? h : void 0)) return !1;
        if ((e => bn.includes(e.errorClass))(p)) return !1;
        if ((e => {
                const {
                    message: t
                } = e;
                return Boolean(_n.some((e => null == t ? void 0 : t.includes(e))))
            })(p)) return o("DynamicImportError"), !1;
        if (wn(p)) return o(), !1;
        const f = null === (a = null === (i = c.Shopify) || void 0 === i ? void 0 : i.featureAssets) || void 0 === a ? void 0 : a["shop-js"],
            m = Boolean(f && Object.keys(f).length > 0),
            v = Array.from(n.querySelectorAll('script[src*="/shop-js/"]')).map((e => e.src));
        e.device = {
            locale: Bt.userLanguage || Bt.language,
            userAgent: Bt.userAgent,
            orientation: null === (l = null === (s = c.screen) || void 0 === s ? void 0 : s.orientation) || void 0 === l ? void 0 : l.type,
            time: (new Date).toISOString()
        }, e.metaData = Object.assign(Object.assign(Object.assign({}, e.metaData), t), {
            custom: Object.assign(Object.assign(Object.assign({}, null === (d = e.metaData) || void 0 === d ? void 0 : d.custom), t.custom), {
                beta: !0,
                bundleLocale: "",
                compactUX: !0,
                domain: null === (u = null == c ? void 0 : c.location) || void 0 === u ? void 0 : u.hostname,
                shopJsUrls: v,
                shopJsFeatureAssetsExist: m
            })
        }), e.request = {
            url: c.location.href
        }
    };
class kn {
    constructor(e) {
        this.opentelClient = new hn({
            exporter: vn()
        });
        const t = function({
            metadata: e,
            onNetworkError: t
        }) {
            return {
                apiKey: Ht,
                appId: "shop-js",
                appVersion: "1.1.0-beta",
                onError: n => xn({
                    event: n,
                    metadata: e,
                    onNetworkError: t
                }),
                releaseStage: "production",
                withSessionTracking: !1
            }
        }({
            metadata: {
                custom: {
                    feature: e
                }
            },
            onNetworkError: this.handleNetworkError.bind(this)
        });
        this.client = new Ft(t), this.feature = e || "", this.leaveBreadcrumb = this.leaveBreadcrumb.bind(this), this.notify = this.notify.bind(this)
    }
    leaveBreadcrumb(e, t, n) {
        this.client ? this.client.leaveBreadcrumb(e, t, n) : console.log("Bugsnag.leaveBreadcrumb() called before client creation.")
    }
    notify(e, t) {
        return y(this, void 0, void 0, (function*() {
            var n;
            this.client ? this.client.notify(e, t) : null === (n = console.warn) || void 0 === n || n.call(console, "Bugsnag.notify() called before client creation.")
        }))
    }
    handleNetworkError(e = "NetworkError") {
        this.opentelClient.counter({
            attributes: {
                feature: this.feature,
                error: e
            },
            name: "shop_js_network_error",
            value: 1
        })
    }
}
const En = ({
    children: e
}) => {
    const {
        featureName: t
    } = Ct(), n = Ne((() => {
        const {
            client: e,
            leaveBreadcrumb: n,
            notify: o
        } = new kn(t);
        return {
            client: e,
            leaveBreadcrumb: n,
            notify: o
        }
    }), [t]);
    return pe(bt.Provider, {
        value: n,
        children: e
    })
};

function Sn(e) {
    return e.replace(/[-:_]([a-z])/g, ((e, t) => `${t.toUpperCase()}`))
}

function Pn(e) {
    return e.replace(/([a-z0-9])([A-Z])/g, ((e, t, n) => `${t}-${n.toLowerCase()}`)).replace(/[\s_]+/g, "-")
}
class Mn extends Error {
    constructor(e, t, n = s()) {
        super(e), this.name = t, this.analyticsTraceId = n;
        const o = t.replace(/[A-Z]/g, (e => `_${e.toLowerCase()}`)).replace(/^_/, "");
        this.analyticsTraceId = n, this.code = o, this.name = t
    }
}

function jn({
    children: e
}) {
    const [t] = function(e) {
        var t = Pe(he++, 10),
            n = Me();
        return t.__ = e, fe.componentDidCatch || (fe.componentDidCatch = function(e, o) {
            t.__ && t.__(e, o), n[1](e)
        }), [n[0], function() {
            n[1](void 0)
        }]
    }(), {
        notify: n
    } = wt();
    return Ce((() => {
        t && n(t instanceof Error ? t : new Mn(t, "UnhandledError"), {
            context: "Error in Preact tree"
        })
    }), [t, n]), pe(B, {
        children: e
    })
}

function Cn(e, t, n = !1) {
    let o;
    return function(...r) {
        const i = n && !o;
        "number" == typeof o && clearTimeout(o), o = setTimeout((() => {
            o = void 0, n || e.apply(this, r)
        }), t), i && e.apply(this, r)
    }
}
const On = e => (e => {
    try {
        return new c.URL(e)
    } catch (e) {
        return null
    }
})(e.message.replace("Failed to fetch dynamically imported module: ", "").trim());

function Tn(e) {
    return y(this, arguments, void 0, (function*(e, {
        maxRetries: t = 3,
        retryDelay: n = 1e3,
        signal: o
    } = {}) {
        const r = (i, a) => y(this, void 0, void 0, (function*() {
            var s;
            if (!(null == o ? void 0 : o.aborted)) try {
                return a ? yield(s = a,
                    import (s)): yield e()
            } catch (e) {
                if (!(e instanceof Error) || (null == o ? void 0 : o.aborted)) return;
                if (i >= t - 1) throw e;
                const a = On(e);
                if (a) {
                    if (a.searchParams.set("t", `${Date.now()}`), yield new Promise((e => setTimeout(e, n))), null == o ? void 0 : o.aborted) return;
                    return r(i + 1, a.href)
                }
                if ((e => e.message.includes("Importing a module script failed"))(e)) {
                    if (yield new Promise((e => setTimeout(e, n))), null == o ? void 0 : o.aborted) return;
                    return r(i + 1)
                }
                throw e
            }
        }));
        return r(0)
    }))
}
const In = ["en", "bg-BG", "cs", "da", "de", "el", "es", "fi", "fr", "hi", "hr-HR", "hu", "id", "it", "ja", "ko", "lt-LT", "ms", "nb", "nl", "pl", "pt-BR", "pt-PT", "ro-RO", "ru", "sk-SK", "sl-SI", "sv", "th", "tr", "vi", "zh-CN", "zh-TW"],
    Nn = de({
        loading: void 0,
        locale: "en",
        translations: void 0
    });

function An(e) {
    return In.includes(e)
}
const Ln = [],
    Rn = [],
    zn = new Map;
const Dn = Cn((function(e) {
    let t = {};
    const n = zn.get(e);
    Rn.forEach((e => {
        t = Object.assign(Object.assign({}, t), e)
    })), zn.set(e, Object.assign(Object.assign({}, n), t)), Ln.forEach((e => e())), Ln.splice(0, Ln.length), Rn.splice(0, Rn.length)
}), 250);

function Un({
    children: e,
    getFeatureDictionary: t,
    overrideLocale: o
}) {
    const {
        notify: r
    } = wt(), {
        recordCounter: i
    } = Mt(), {
        featureName: a
    } = Ct(), [s, l] = Me(), [d, u] = Me(void 0), p = Ae((() => {
        var e;
        const t = Object.freeze([o, n.documentElement.lang, null === (e = c.Shopify) || void 0 === e ? void 0 : e.locale, ...Bt.languages].filter((e => e)));
        let r;
        for (const e of t) {
            if (An(e)) {
                r = e;
                break
            }
            try {
                const t = new Intl.Locale(e);
                if (t.language && An(t.language)) {
                    r = t.language;
                    break
                }
                i("shop_js_unsupported_locale", {
                    attributes: {
                        locale: e
                    }
                }), console.error(`Unsupported locale: "${e}"`)
            } catch (t) {
                i("shop_js_invalid_locale", {
                    attributes: {
                        locale: e
                    }
                }), console.error(`Invalid locale: "${e}"`)
            }
        }
        return r || "en"
    }), [o, i]), h = Ae((() => y(this, void 0, void 0, (function*() {
        if (An(d)) try {
            if (!zn.has(d)) {
                l(!0);
                try {
                    const e = yield Tn((() => y(this, void 0, void 0, (function*() {
                        return yield {
                            button: {
                                close: "Close"
                            }
                        }
                    }))), {
                        maxRetries: 5,
                        retryDelay: 1e3
                    });
                    zn.set(d, e)
                } catch (e) {
                    if ("en" !== d) throw new Mn("Failed to fetch non-English translations", "HandledTranslationFetchError");
                    r(new Mn(`Failed to load shared translations for "en" locale: ${e}`, "TranslationFetchError"))
                }
            }
            if (a && t) {
                l(!0);
                try {
                    const e = (yield Tn((() => y(this, void 0, void 0, (function*() {
                        return t(d)
                    }))), {
                        maxRetries: 5,
                        retryDelay: 1e3
                    })) || {};
                    Rn.push(e)
                } catch (e) {
                    if ("en" !== d) throw new Mn("Failed to fetch non-English translations", "HandledTranslationFetchError");
                    r(new Mn(`Failed to load ${a} translations for "en" locale: ${e}`, "TranslationFetchError"))
                }
            }
            Ln.push((() => l(!1))), Dn(d)
        } catch (e) {
            e instanceof Mn && "HandledTranslationFetchError" === e.name && (i("shop_js_handle_silent_error", {
                attributes: {
                    error: e.name,
                    locale: d
                }
            }), u("en"))
        }
    }))), [a, t, d, r, i]);
    Ce((() => {
        const e = p();
        u(e)
    }), [p]), Ce((() => {
        try {
            h()
        } catch (e) {
            e instanceof Error && r(e)
        }
    }), [h, d, r]);
    const f = Ne((() => ({
        loading: s,
        locale: d,
        translations: zn
    })), [s, d]);
    return pe(Nn.Provider, {
        value: f,
        children: !1 === s && e
    })
}

function Fn(e, t = 200, n = !1) {
    const o = Te(),
        r = Te(e);
    return r.current = e, Ae(((...e) => {
        var i;
        const a = n && !o.current;
        "number" == typeof o.current && clearTimeout(o.current), o.current = setTimeout(((...e) => {
            var t;
            o.current = void 0, n || null === (t = r.current) || void 0 === t || t.call(r, ...e)
        }), t, ...e), a && (null === (i = r.current) || void 0 === i || i.call(r, ...e))
    }), [t, n])
}

function $n(e, t, n) {
    return (t = function(e) {
        var t = function(e, t) {
            if ("object" != typeof e || !e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 !== n) {
                var o = n.call(e, t);
                if ("object" != typeof o) return o;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === t ? String : Number)(e)
        }(e, "string");
        return "symbol" == typeof t ? t : t + ""
    }(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function Bn(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        t && (o = o.filter((function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        }))), n.push.apply(n, o)
    }
    return n
}

function Hn(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? Bn(Object(n), !0).forEach((function(t) {
            $n(e, t, n[t])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Bn(Object(n)).forEach((function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
        }))
    }
    return e
}
const Vn = "http://localhost:8082",
    Wn = "https://monorail-edge.shopifysvc.com",
    qn = "/v1/produce";

function Kn(e) {
    return void 0 !== e.schemaId
}
class Gn {
    constructor(e) {
        this.producer = e
    }
    do(e, t) {
        return Kn(e) ? this.producer.produce(e) : this.producer.produceBatch(e)
    }
}

function Xn() {
    if ("undefined" != typeof crypto && crypto && "function" == typeof crypto.randomUUID) return crypto.randomUUID();
    const e = new Array(36);
    for (let t = 0; t < 36; t++) e[t] = Math.floor(16 * Math.random());
    return e[14] = 4, e[19] = e[19] &= -5, e[19] = e[19] |= 8, e[8] = e[13] = e[18] = e[23] = "-", e.map((e => e.toString(16))).join("")
}

function Yn(e, t = !0) {
    return e && Object.keys(e).length && t ? Object.keys(e).map((t => ({
        [Jn(t)]: e[t]
    }))).reduce(((e, t) => Hn(Hn({}, e), t))) : e
}

function Jn(e) {
    return e.split(/(?=[A-Z])/).join("_").toLowerCase()
}

function Zn(e) {
    return e.events.map((e => {
        let t = !0,
            n = !0;
        return e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (t = Boolean(e.options.convertEventCase)), e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertMetaDataCase") && (n = Boolean(e.options.convertMetaDataCase)), Hn({
            schema_id: e.schemaId,
            payload: Yn(e.payload, t)
        }, e.metadata && {
            metadata: Yn(e.metadata, n)
        })
    }))
}
class Qn extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), $n(this, "name", "MonorailUnableToProduceError"), this.response = e, Object.setPrototypeOf(this, Qn.prototype)
    }
}
class eo extends Error {
    constructor(e) {
        super(`Response not from Monorail Edge. Response received: ${JSON.stringify(e)}`), $n(this, "name", "MonorailInterceptedProduceError"), this.response = e, Object.setPrototypeOf(this, eo.prototype)
    }
}
class to extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), $n(this, "name", "MonorailBatchProduceError"), Object.setPrototypeOf(this, to.prototype), this.response = e
    }
}
class no extends Error {
    constructor(e, t) {
        super(`Error completing request. A network failure may have prevented the request from completing. Error: ${e}. Schemas: ${Array.from(new Set(t)).join(", ")}`), $n(this, "name", "MonorailRequestError"), Object.setPrototypeOf(this, no.prototype)
    }
}
class oo extends Error {
    constructor(e, t) {
        super(`Error reading response from Monorail Edge. Status: ${t||"unknown"}. Error: ${(null==e?void 0:e.message)||"Unknown error"}`), $n(this, "name", "MonorailResponseReadError"), this.error = e, this.status = t, Object.setPrototypeOf(this, oo.prototype)
    }
}
class ro {
    static withEndpoint(e) {
        return new ro(`https://${new URL(e).hostname}`)
    }
    constructor(e = Vn, t = {}) {
        var n, o;
        if (this.edgeDomain = e, this.optionsOrKeepalive = t, "boolean" == typeof t) return this.keepalive = t, void(this.detectInterceptedErrorEnabled = !1);
        this.keepalive = null !== (n = t.keepalive) && void 0 !== n && n, this.detectInterceptedErrorEnabled = null !== (o = t.detectInterceptedErrorEnabled) && void 0 !== o && o
    }
    async produceBatch(e) {
        const t = {
            events: Zn(e),
            metadata: Yn(e.metadata)
        };
        let n, o;
        try {
            n = await fetch(this.produceBatchEndpoint(), {
                method: "post",
                headers: io(e.metadata),
                body: JSON.stringify(t),
                keepalive: this.keepalive
            })
        } catch (t) {
            throw new no(t, e.events.map((e => e.schemaId)))
        }
        if (207 === n.status) {
            const e = await n.json();
            throw new to(e)
        }
        try {
            o = await n.text()
        } catch (e) {
            throw new oo(e, n.status)
        }
        if (!n.ok) {
            if (!Boolean(n.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new eo({
                status: n.status,
                message: o
            });
            throw new Qn({
                status: n.status,
                message: o
            })
        }
        return {
            status: n.status
        }
    }
    async produce(e) {
        let t, n, o = !0;
        e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (o = Boolean(e.options.convertEventCase));
        try {
            t = await async function({
                endpoint: e,
                event: t,
                keepalive: n
            }) {
                var o, r, i, a, s;
                const l = t.metadata ? {
                    clientMessageId: null === (o = t.metadata) || void 0 === o ? void 0 : o.clientMessageId,
                    eventCreatedAtMs: null === (r = t.metadata) || void 0 === r ? void 0 : r.eventCreatedAtMs,
                    consent: null === (i = t.metadata) || void 0 === i ? void 0 : i.consent,
                    consent_provider: null === (a = t.metadata) || void 0 === a ? void 0 : a.consent_provider,
                    consent_version: null === (s = t.metadata) || void 0 === s ? void 0 : s.consent_version
                } : void 0;
                return fetch(null != e ? e : Wn + qn, {
                    method: "post",
                    headers: io(t.metadata),
                    body: JSON.stringify({
                        schema_id: t.schemaId,
                        payload: t.payload,
                        metadata: l && Yn(l, !0)
                    }),
                    keepalive: n
                })
            }({
                endpoint: this.produceEndpoint(),
                keepalive: this.keepalive,
                event: Hn(Hn({}, e), {}, {
                    payload: Yn(e.payload, o)
                })
            })
        } catch (t) {
            throw new no(t, [e.schemaId])
        }
        if (!t) throw new Qn({
            message: "No response from edge"
        });
        try {
            n = await t.text()
        } catch (e) {
            throw new oo(e, t.status)
        }
        if (!t.ok) {
            if (!Boolean(t.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new eo({
                status: t.status,
                message: n
            });
            throw new Qn({
                status: t.status,
                message: n
            })
        }
        return {
            status: t.status
        }
    }
    produceBatchEndpoint() {
        return this.edgeDomain + "/unstable/produce_batch"
    }
    produceEndpoint() {
        return this.edgeDomain + qn
    }
}

function io(e) {
    const t = {
        "Content-Type": "application/json; charset=utf-8",
        "X-Monorail-Edge-Event-Created-At-Ms": (e && e.eventCreatedAtMs || Date.now()).toString(),
        "X-Monorail-Edge-Event-Sent-At-Ms": Date.now().toString(),
        "X-Monorail-Edge-Client-Message-Id": (e && e.clientMessageId || Xn()).toString()
    };
    return e && e.userAgent && (t["User-Agent"] = e.userAgent), e && e.remoteIp && (t["X-Forwarded-For"] = e.remoteIp), e && e.deviceInstallId && (t["X-Monorail-Edge-Device-Install-Id"] = e.deviceInstallId), e && e.client && (t["X-Monorail-Edge-Client"] = e.client), e && e.clientOs && (t["X-Monorail-Edge-Client-OS"] = e.clientOs), t
}
class ao {
    static printWelcomeMessage(e) {
        console.log(`%c👋 from Monorail%c\n\nWe've noticed that you're${e?"":" not"} running in debug mode. As such, we will ${e?"produce":"not produce"} Monorail events to the console. \n\nIf you want Monorail events to ${e?"stop":"start"} appearing here, %cset debugMode=${(!e).toString()}%c, for the Monorail Log Producer in your code.`, "font-size: large;", "font-size: normal;", "font-weight: bold;", "font-weight: normal;")
    }
    constructor(e) {
        this.sendToConsole = e, e && ao.printWelcomeMessage(e)
    }
    async produce(e) {
        return this.sendToConsole && console.log("Monorail event produced", e), new Promise((t => {
            t(e)
        }))
    }
    produceBatch(e) {
        return this.sendToConsole && console.log("Monorail Batch event produced", e), new Promise((t => {
            t(e)
        }))
    }
}
class so {
    constructor(e) {
        this.version = e.version
    }
}
class lo {
    constructor(e, t = () => !1) {
        if ($n(this, "eventsAwaitingConsent", []), null == e || !e.provider) throw new co("ConsentTrackingMiddleware requires an instance of ConsentTrackingProvider");
        this.isStrictlyNecessary = t, this.provider = e.provider
    }
    async do(e, t) {
        if (Kn(e)) {
            const n = await this.provider.annotateEvent(e);
            return this.isConsentGivenForEmission(n) ? (await this.processBufferedEvents(t), t(n)) : this.isStrictlyNecessary(n) ? t(n) : (this.eventsAwaitingConsent.push(e), Promise.resolve({
                status: 0,
                message: "Consent not granted and event not marked strictly necessary, event not sent"
            }))
        } {
            if (this.isConsentGivenForEmission(await this.provider.annotateEvent(e.events[0]))) {
                await this.processBufferedEvents(t);
                const n = await Promise.all(e.events.map((e => this.provider.annotateEvent(e))));
                return t(Hn(Hn({}, e), {}, {
                    events: n
                }))
            }
            const n = e.events.filter((e => !!this.isStrictlyNecessary(e) || (this.eventsAwaitingConsent.push(e), !1)));
            if (n.length > 0) {
                const o = await Promise.all(n.map((e => this.provider.annotateEvent(e))));
                return t(Hn(Hn({}, e), {}, {
                    events: o
                }))
            }
            return Promise.resolve({
                status: 0,
                message: "Consent not granted for any event, and no event marked strictly necessary, event batch not sent"
            })
        }
    }
    isConsentGivenForEmission(e) {
        var t;
        const n = null === (t = e.metadata) || void 0 === t ? void 0 : t.consent,
            o = this.provider.getRequiredConsentForEmission();
        return Boolean(Array.isArray(n) && n.some((e => o.includes(e))))
    }
    async
    processBufferedEvents(e) {
        if (0 === this.eventsAwaitingConsent.length) return;
        const t = this.eventsAwaitingConsent;
        this.eventsAwaitingConsent = [];
        const n = await Promise.all(t.map((e => this.provider.annotateEvent(e))));
        await e({
            events: n
        })
    }
}
class co extends Error {
    constructor(e) {
        super(e), Object.setPrototypeOf(this, co.prototype)
    }
}

function uo(e, t) {
    var n, o, r;
    if (e === t) return !0;
    if (typeof e != typeof t) return !1;
    if ("function" == typeof e && void 0 !== (null === (n = e.toString) || void 0 === n ? void 0 : n.call(e)) && (null === (o = e.toString) || void 0 === o ? void 0 : o.call(e)) === (null === (r = t.toString) || void 0 === r ? void 0 : r.call(t))) return !0;
    if (e && t && "object" == typeof e && "object" == typeof t) {
        if (e.constructor !== t.constructor) return !1;
        let n, o;
        const r = Object.keys(e);
        if (Array.isArray(e)) {
            if (n = e.length, n !== t.length) return !1;
            for (o = n; 0 != o--;)
                if (!uo(e[o], t[o])) return !1;
            return !0
        }
        if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === t.valueOf();
        if (e.toString !== Object.prototype.toString) return e.toString() === t.toString();
        if (n = r.length, n !== Object.keys(t).length) return !1;
        for (o = n; 0 != o--;)
            if (!Object.prototype.hasOwnProperty.call(t, r[o])) return !1;
        for (o = n; 0 != o--;) {
            const n = r[o];
            if (!uo(e[n], t[n])) return !1
        }
        return !0
    }
    return e != e && t != t
}
const po = "",
    ho = "1",
    fo = "0",
    mo = "p",
    vo = "a",
    go = "m",
    _o = "t",
    yo = "m",
    bo = "a",
    wo = "p",
    xo = "s";

function ko(e) {
    try {
        return decodeURIComponent(e)
    } catch (e) {
        return ""
    }
}

function Eo(e, t = !1) {
    const n = function() {
        try {
            return document.cookie
        } catch {
            return !1
        }
    }() ? document.cookie.split("; ") : [];
    for (let t = 0; t < n.length; t++) {
        const [o, r] = n[t].split("=");
        if (e === ko(o)) {
            return ko(r)
        }
    }
    if (t && "_tracking_consent" === e && !window.localStorage.getItem("tracking_consent_fetched")) {
        if ("undefined" != typeof __CtaTestEnv__ && "true" === __CtaTestEnv__) return;
        return console.debug("_tracking_consent missing"),
            function(e = "/") {
                const t = new XMLHttpRequest;
                t.open("HEAD", e, !1), t.withCredentials = !0, t.send()
            }(), window.localStorage.setItem("tracking_consent_fetched", "true"), Eo(e, !1)
    }
}

function So() {
    const e = new URLSearchParams(window.location.search).get("_cs") || Eo("_tracking_consent");
    if (void 0 !== e) return function(e) {
        const t = e.slice(0, 1);
        if ("{" == t) return function(e) {
            var t;
            let n;
            try {
                n = JSON.parse(e)
            } catch {
                return
            }
            if ("2.1" !== n.v) return;
            if (null === (t = n.con) || void 0 === t || !t.CMP) return;
            return n
        }(e);
        if ("3" == t) return function(e) {
            const t = e.slice(1).split("_"),
                [n, o, r, i, a] = t;
            let s, l;
            try {
                s = t[5] ? JSON.parse(t.slice(5).join("_")) : void 0
            } catch {}
            if (a) {
                const e = a.replace(/\*/g, "/").replace(/-/g, "+"),
                    t = Array.from(atob(e)).map((e => e.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                l = [8, 13, 18, 23].reduce(((e, t) => e.slice(0, t) + "-" + e.slice(t)), t)
            }

            function c(e) {
                const t = n.split(".")[0];
                return t.includes(e.toLowerCase()) ? fo : t.includes(e.toUpperCase()) ? ho : po
            }

            function d(e) {
                return n.includes(e.replace("t", "s").toUpperCase())
            }
            return {
                v: "3",
                con: {
                    CMP: {
                        [bo]: c(bo),
                        [wo]: c(wo),
                        [yo]: c(yo),
                        [xo]: c(xo)
                    }
                },
                region: o || "",
                cus: s,
                purposes: {
                    [vo]: d(vo),
                    [mo]: d(mo),
                    [go]: d(go),
                    [_o]: d(_o)
                },
                sale_of_data_region: "t" == i,
                display_banner: "t" == r,
                consent_id: l
            }
        }(e);
        return
    }(e)
}

function Po(e) {
    const t = So();
    if (!t || !t.purposes) return !0;
    const n = t.purposes[e];
    return "boolean" != typeof n || n
}

function Mo() {
    return Po(vo)
}

function jo() {
    return Po(mo)
}

function Co() {
    return Po(go)
}

function Oo() {
    return Po(_o)
}

function To() {
    const e = [];
    return Mo() && e.push("analytics"), Co() && e.push("marketing"), Oo() && e.push("sale_of_data"), jo() && e.push("preferences"), e
}
class Io extends so {
    async annotateEvent(e) {
        return Promise.resolve(function(e, t) {
            if ("v1" === t) {
                const n = To();
                return { ...e,
                    metadata: { ...null == e ? void 0 : e.metadata,
                        consent: n,
                        consent_provider: "consent-tracking-api",
                        consent_version: t
                    }
                }
            }
            throw new No(t || "unknown")
        }(e, this.version))
    }
    getRequiredConsentForEmission() {
        if ("v1" === this.version) return ["analytics", "marketing"];
        throw new No(this.version || "unknown")
    }
}
class No extends Error {
    constructor(e) {
        super(`Version ${e} is not supported by the consent-tracking-api provider`), this.name = "MonorailConsentTrackingApiProviderVersionError", Object.setPrototypeOf(this, No.prototype)
    }
}

function Ao() {
    var e;
    const t = null === (e = n.querySelector("script#shop-js-analytics")) || void 0 === e ? void 0 : e.innerHTML;
    return t ? JSON.parse(t) : {}
}

function Lo() {
    return y(this, void 0, void 0, (function*() {
        let e;
        return Promise.race([new Promise((t => e = setTimeout((() => t({})), 1e4))), new Promise((e => {
            var t, n, o;
            const r = (null === (n = null === (t = c.ShopifyAnalytics) || void 0 === t ? void 0 : t.lib) || void 0 === n ? void 0 : n.ready) || (null === (o = c.analytics) || void 0 === o ? void 0 : o.ready);
            null == r || r((() => {
                var t, n, o, r;
                const i = (null === (n = null === (t = c.ShopifyAnalytics) || void 0 === t ? void 0 : t.lib) || void 0 === n ? void 0 : n.trekkie) || (null === (o = c.analytics) || void 0 === o ? void 0 : o.trekkie),
                    a = null !== (r = null == i ? void 0 : i.defaultAttributes) && void 0 !== r ? r : {};
                e(a)
            }))
        }))]).finally((() => clearTimeout(e)))
    }))
}

function Ro(...e) {
    return y(this, void 0, void 0, (function*() {
        var t;
        if (!c.ShopifyAnalytics && !c.analytics) return {};
        let n;
        Boolean(null === (t = c.trekkie) || void 0 === t ? void 0 : t.ready) ? n = Lo() : (c.trekkie = c.trekkie || [], n = new Promise((e => {
            c.trekkie.push(["ready", () => {
                e(Lo())
            }])
        })));
        const o = yield n;
        return e.reduce(((e, t) => {
            const n = o[t];
            return void 0 !== n && (e[t] = n), e
        }), {})
    }))
}
var zo;
const Do = "unspecified",
    Uo = function() {
        const e = new Io({
            version: "v1"
        });
        return [new lo({
            provider: e
        })]
    }(),
    Fo = ["completed", "emailsubmitted", "namesubmitted", "sheetmodalclosed", "sheetmodalopened"],
    $o = class e {
        static createLogProducer(t) {
            return new e(new ao(t.debugMode), t.middleware || [])
        }
        static createHttpProducerWithEndpoint(t, n = []) {
            return new e(ro.withEndpoint(t), n)
        }
        static createHttpProducer(t) {
            return new e(t.production ? new ro(Wn, t.options) : new ro(Vn, t.options), t.middleware || [])
        }
        static buildMiddlewareChain(e, t = 0) {
            return t === e.length ? this.identityFn : n => e[t].do(n, this.buildMiddlewareChain(e, t + 1))
        }
        constructor(t, n) {
            this.producer = t, this.middleware = n, this.executeChain = e.buildMiddlewareChain(this.middleware.concat(new Gn(t)))
        }
        produce(e) {
            return e.metadata = Hn({
                eventCreatedAtMs: Date.now(),
                clientMessageId: Xn()
            }, e.metadata), this.executeChain(e)
        }
        produceBatch(e) {
            return this.executeChain(e)
        }
    }.createHttpProducer({
        production: !0,
        middleware: Uo
    });
class Bo {
    constructor({
        analyticsData: e,
        devMode: t = !1,
        notify: n,
        recordCounter: o
    }) {
        var r;
        zo.set(this, void 0), this.featureInitializationEventAlreadyEmitted = !1, this.trackedPageImpressions = new Set, w(this, zo, Object.assign(Object.assign({}, e), {
            flowVersion: null !== (r = e.flowVersion) && void 0 !== r ? r : Do
        }), "f"), this.devMode = t, this.notify = n, this.recordCounter = o, this.clearTrackedPageImpressions = this.clearTrackedPageImpressions.bind(this), this.produceMonorailEvent = this.produceMonorailEvent.bind(this), this.trackFeatureInitialization = this.trackFeatureInitialization.bind(this), this.trackModalStateChange = this.trackModalStateChange.bind(this), this.trackPageImpression = this.trackPageImpression.bind(this), this.trackUserAction = this.trackUserAction.bind(this), this.trackPostMessageTransmission = this.trackPostMessageTransmission.bind(this)
    }
    get analyticsData() {
        return b(this, zo, "f")
    }
    set analyticsData(e) {
        const t = Object.assign(Object.assign({}, b(this, zo, "f")), e);
        uo(t, b(this, zo, "f")) || w(this, zo, t, "f")
    }
    clearTrackedPageImpressions() {
        this.trackedPageImpressions.clear()
    }
    produceMonorailEvent({
        event: e,
        onError: t,
        trekkieAttributes: n
    }) {
        this.devMode || (!n || Object.keys(n).length ? (e.payload = Object.assign(e.payload, n), $o.produce(e).catch((e => {
            var n;
            if (null == t || t(e), function(e) {
                    var t, n, o, r, i, a, s;
                    const l = e instanceof oo && 200 === e.status;
                    return !(e instanceof no || e instanceof Qn || (null === (t = null == e ? void 0 : e.message) || void 0 === t ? void 0 : t.includes("Invalid agent:")) || (null === (n = null == e ? void 0 : e.message) || void 0 === n ? void 0 : n.includes(".text is not a function")) || (null === (o = null == e ? void 0 : e.message) || void 0 === o ? void 0 : o.includes("event_sent_at_ms metadata field cannot be empty")) || (null === (r = null == e ? void 0 : e.message) || void 0 === r ? void 0 : r.includes("event_created_at_ms metadata field cannot be empty.")) || (null === (i = null == e ? void 0 : e.message) || void 0 === i ? void 0 : i.match(/Cannot read properties of (null|undefined) \(reading 'status'\)/)) || (null === (a = null == e ? void 0 : e.message) || void 0 === a ? void 0 : a.match(/(null|undefined) is not an object \(evaluating '[a-zA-Z]+\.status'\)/)) || (null === (s = null == e ? void 0 : e.message) || void 0 === s ? void 0 : s.match(/[a-zA-Z]+ is (null|undefined)/)) || l)
                }(e)) {
                const t = e instanceof Error ? e : new Mn(String(e), "MonorailProducerError");
                if (null === (n = this.notify) || void 0 === n || n.call(this, t), this.recordCounter) {
                    const e = function(e) {
                        const t = Object.values(mn).find((([t, n]) => e.message.includes(n)));
                        return (null == t ? void 0 : t[0]) || "otherErrors"
                    }(t);
                    this.recordCounter("shop_js_monorail_producer_error", {
                        attributes: {
                            error: e
                        }
                    })
                }
            }
        }))) : null == t || t({
            message: "trekkie attributes are empty"
        }))
    }
    trackFeatureInitialization() {
        return y(this, void 0, void 0, (function*() {
            var e, t, n, o;
            const {
                analyticsTraceId: r,
                apiKey: i,
                checkoutToken: a,
                flow: s,
                flowVersion: l = Do,
                shopId: d,
                source: u = "unspecified",
                uxMode: p
            } = this.analyticsData;
            if (!s) return;
            this.featureInitializationEventAlreadyEmitted && (null === (e = this.notify) || void 0 === e || e.call(this, new Mn(`Feature Initialize Event already emitted once for the feature ${s}`, "MonorailLogicError", r)));
            const h = Ao(),
                f = null !== (t = null == h ? void 0 : h.pageType) && void 0 !== t ? t : "",
                m = yield Ro("customerId", "isPersistentCookie", "path", "uniqToken", "visitToken"), v = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, i && {
                    apiKey: i
                }), a && {
                    checkoutToken: a
                }), d && {
                    shopId: d
                }), m), {
                    analyticsTraceId: r,
                    flow: s,
                    flowVersion: l,
                    sdkVersion: "1.1.0-beta",
                    shopPermanentDomain: null !== (o = null === (n = c.Shopify) || void 0 === n ? void 0 : n.shop) && void 0 !== o ? o : "",
                    source: u,
                    storefrontPageType: f,
                    uxMode: p
                });
            this.featureInitializationEventAlreadyEmitted = !0, this.produceMonorailEvent({
                event: {
                    schemaId: "shopify_pay_login_with_shop_sdk_feature_initialize/1.1",
                    payload: v
                }
            })
        }))
    }
    trackModalStateChange({
        currentState: e,
        dismissMethod: t,
        reason: n
    }) {
        var o;
        const {
            analyticsTraceId: r,
            checkoutToken: i,
            flow: a,
            flowVersion: s = "unspecified"
        } = this.analyticsData;
        a && (this.produceMonorailEvent({
            event: {
                schemaId: "shop_identity_modal_state_change/1.4",
                payload: {
                    analyticsTraceId: r,
                    checkoutToken: i,
                    currentState: e,
                    dismissMethod: t,
                    flow: a,
                    flowVersion: s,
                    previousState: this.previousModalState,
                    reason: n,
                    zoom: `${null===(o=c.visualViewport)||void 0===o?void 0:o.scale}`
                }
            }
        }), this.previousModalState = e)
    }
    trackPageImpression(e) {
        return y(this, arguments, void 0, (function*({
            allowDuplicates: e = !1,
            analyticsTraceId: t = this.analyticsData.analyticsTraceId,
            flow: n = this.analyticsData.flow,
            page: o,
            shopAccountUuid: r
        }) {
            var i, a, s;
            if (!e && this.trackedPageImpressions.has(o)) return;
            const {
                apiKey: l,
                checkoutToken: d,
                flowVersion: u = Do
            } = this.analyticsData;
            if (!n) return;
            this.trackedPageImpressions.add(o);
            const p = Ao(),
                h = null !== (i = null == p ? void 0 : p.pageType) && void 0 !== i ? i : "",
                f = yield Ro("customerId", "isPersistentCookie", "path", "uniqToken", "visitToken"), m = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, l && {
                    apiKey: l
                }), d && {
                    checkoutToken: d
                }), r && {
                    shopAccountUuid: r
                }), f), {
                    analyticsTraceId: t,
                    flow: n,
                    flowVersion: u,
                    pageName: o,
                    sdkVersion: "1.1.0-beta",
                    shopPermanentDomain: null !== (s = null === (a = c.Shopify) || void 0 === a ? void 0 : a.shop) && void 0 !== s ? s : "",
                    storefrontPageType: h
                });
            this.produceMonorailEvent({
                event: {
                    payload: m,
                    schemaId: "shopify_pay_login_with_shop_sdk_page_impressions/3.3"
                },
                onError: () => {
                    this.trackedPageImpressions.delete(o)
                },
                trekkieAttributes: f
            })
        }))
    }
    trackUserAction({
        userAction: e
    }) {
        var t, n;
        const {
            analyticsTraceId: o,
            apiKey: r,
            checkoutToken: i,
            checkoutVersion: a,
            flow: s,
            flowVersion: l = Do,
            shopId: d
        } = this.analyticsData;
        if (!s) return;
        const u = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, r && {
            apiKey: r
        }), i && {
            checkoutToken: i
        }), a && {
            checkoutVersion: a
        }), d && {
            shopId: d
        }), {
            analyticsTraceId: o,
            flow: s,
            flowVersion: l,
            sdkVersion: "1.1.0-beta",
            shopPermanentDomain: null !== (n = null === (t = c.Shopify) || void 0 === t ? void 0 : t.shop) && void 0 !== n ? n : "",
            userAction: e
        });
        this.produceMonorailEvent({
            event: {
                schemaId: "shopify_pay_login_with_shop_sdk_user_actions/2.2",
                payload: u
            }
        })
    }
    trackPostMessageTransmission({
        direction: e,
        event: t
    }) {
        var n;
        const o = t.type;
        if (!Fo.includes(o)) return;
        const r = Date.now(),
            i = t.messageId,
            {
                analyticsTraceId: a,
                checkoutToken: s,
                shopPermanentDomain: l
            } = this.analyticsData,
            c = function(e) {
                return "email" in e
            }(t) ? t.email : void 0,
            d = {
                eventType: o,
                direction: e,
                actor: "shop-js"
            };
        null === (n = this.recordCounter) || void 0 === n || n.call(this, "shop_js_post_message_transmission", {
            attributes: d
        }), this.produceMonorailEvent({
            event: {
                schemaId: "shop_identity_post_message_transmission/1.0",
                payload: {
                    messageId: i,
                    messageDirection: e,
                    actor: "shop-js",
                    payloadType: o,
                    clientTimestampMs: r,
                    analyticsTraceId: a,
                    checkoutToken: s,
                    shopifyDomain: l,
                    email: c
                }
            }
        })
    }
}
zo = new WeakMap;
const Ho = ({
    analyticsContext: e = "loginWithShop",
    apiKey: t,
    checkoutVersion: n,
    checkoutToken: o,
    children: r,
    flow: i,
    flowVersion: a,
    shopId: s = 0,
    shopPermanentDomain: l,
    source: c,
    uxMode: d
}) => {
    const {
        notify: u
    } = wt(), {
        recordCounter: p
    } = Mt(), {
        devMode: h,
        instanceId: f
    } = Ct(), m = Te({
        analyticsContext: e,
        analyticsTraceId: f,
        apiKey: t,
        checkoutVersion: n,
        checkoutToken: o,
        flow: i,
        flowVersion: a,
        shopId: s,
        shopPermanentDomain: l,
        source: c,
        uxMode: d
    }), v = Ne((() => new Bo({
        analyticsData: m.current,
        devMode: h,
        notify: u,
        recordCounter: p
    })), [h, u, p]);
    v.analyticsData = Object.assign(Object.assign({}, m.current), {
        analyticsTraceId: f,
        analyticsContext: e,
        apiKey: t,
        checkoutVersion: n,
        checkoutToken: o,
        flow: i,
        flowVersion: a,
        shopId: s,
        shopPermanentDomain: l,
        source: c,
        uxMode: d
    }), Ce((() => () => {
        v.clearTrackedPageImpressions()
    }), [v]);
    const g = Fn((() => {
        v.trackFeatureInitialization()
    }), 100);
    Ce((() => {
        g()
    }), [g]);
    const _ = Ne((() => ({
        analyticsData: v.analyticsData,
        getTrekkieAttributes: Ro,
        produceMonorailEvent: v.produceMonorailEvent,
        trackModalStateChange: v.trackModalStateChange,
        trackPageImpression: v.trackPageImpression,
        trackUserAction: v.trackUserAction,
        trackPostMessageTransmission: v.trackPostMessageTransmission
    })), [v.analyticsData, v.produceMonorailEvent, v.trackModalStateChange, v.trackPageImpression, v.trackUserAction, v.trackPostMessageTransmission]);
    return pe(Et.Provider, {
        value: _,
        children: r
    })
};

function Vo({
    children: e
}) {
    const {
        featureName: t
    } = Ct(), n = Ne((() => new hn({
        exporter: vn()
    })), []), o = Ae((({
        body: e,
        attributes: o
    }) => {
        n.log({
            body: e,
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, o)
        })
    }), [n, t]), r = Ae(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1
        } = o;
        n.counter({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), i = Ae(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1
        } = o;
        n.gauge({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), a = Ae(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1,
            bounds: s
        } = o;
        n.histogram({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            bounds: s,
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), s = Ne((() => ({
        client: n,
        log: o,
        recordCounter: r,
        recordGauge: i,
        recordHistogram: a
    })), [n, o, r, i, a]);
    return pe(Pt.Provider, {
        value: s,
        children: e
    })
}
const Wo = "gravity-font-faces",
    qo = ({
        authorizeStateEnabled: e = !0,
        children: t,
        devMode: o = !1,
        element: r,
        featureName: i,
        getFeatureDictionary: a,
        metricsEnabled: l = !0,
        monorailProps: c,
        overrideLocale: d
    }) => {
        Ce((() => {
            if (n.querySelector(`style[data-description="${Wo}"]`)) return;
            const e = n.createElement("style");
            e.dataset.description = Wo, e.appendChild(n.createTextNode("\n@font-face {\n  font-family: 'GTStandard-M';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MRegular.woff2')\n    format('woff2');\n  font-style: normal;\n  font-weight: 450;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: 'GTStandard-M';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MMedium.woff2')\n    format('woff2');\n  font-style: normal;\n  font-weight: 500;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: 'GTStandard-M';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MSemibold.woff2')\n    format('woff2');\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n}")), n.head.appendChild(e)
        }), []);
        const u = Ne((() => s()), []);
        Ce((() => {
            r && r.setAttribute("data-instance-id", u)
        }), [r, u]);
        const p = Ne((() => ({
            devMode: o,
            element: r,
            featureName: i,
            instanceId: u
        })), [o, r, i, u]);
        return pe(jt.Provider, {
            value: p,
            children: pe(Ko, {
                enabled: l,
                monorailProps: c,
                children: pe(Un, {
                    getFeatureDictionary: a,
                    overrideLocale: d,
                    children: pe(Go, {
                        enabled: e,
                        children: t
                    })
                })
            })
        })
    };

function Ko({
    children: e,
    enabled: t = !0,
    monorailProps: n
}) {
    return t ? pe(En, {
        children: pe(jn, {
            children: pe(Vo, {
                children: pe(Ho, Object.assign({}, n, {
                    children: e
                }))
            })
        })
    }) : pe(B, {
        children: e
    })
}

function Go({
    children: e,
    enabled: t = !0
}) {
    return t ? pe(It, {
        children: e
    }) : e
}
const Xo = () => Le(Nn),
    Yo = ["string", void 0],
    Jo = () => {
        const {
            locale: e,
            translations: t
        } = Xo();
        return {
            locale: e,
            translate: (n, o) => {
                const r = n.split(".");
                if (!t || !e) throw new ReferenceError;
                const i = o || {},
                    {
                        count: a,
                        defaultValue: s
                    } = i,
                    l = _(i, ["count", "defaultValue"]);
                let c = t.get(e);
                if (!c && (null == o ? void 0 : o.defaultValue)) return o.defaultValue;
                try {
                    for (const e of r) switch (typeof c) {
                        case "object":
                            c = c[e];
                            break;
                        case "string":
                        case "undefined":
                            throw new ReferenceError
                    }
                    if (void 0 === c) throw new ReferenceError;
                    if ("string" != typeof t && a) {
                        let e = 1 === a ? "one" : "other";
                        0 === a && "string" != typeof t && "zero" in t && (e = "zero"), c = c[e]
                    }
                    if ("string" != typeof c) throw new ReferenceError;
                    let e = !1;
                    const n = Object.keys(l),
                        o = c.split(new RegExp(`({${n.join("}|{")}})`, "g"));
                    return n.forEach((t => {
                        e || Yo.includes(typeof l[t]) || (e = !0), o.forEach(((e, n) => {
                            e === `{${t}}` && (o[n] = l[t])
                        }))
                    })), e ? pe(B, {
                        children: o
                    }) : o.join("")
                } catch (e) {
                    return s || n
                }
            }
        }
    };

function Zo(e) {
    const {
        element: t
    } = Ct(), {
        loading: n
    } = Xo();
    Ce((() => {
        if (t && !1 === n) return Object.entries(e).forEach((([e, n]) => {
            t.addEventListener(e, n)
        })), null == t || t._eventListenerReadyPromiseResolve(), () => {
            Object.entries(e).forEach((([e, n]) => {
                null == t || t.removeEventListener(e, n)
            }))
        }
    }), [t, n, e])
}
const Qo = c.HTMLElement,
    er = e => {
        const t = c.HTMLElement;
        c.HTMLElement = Qo;
        const n = e();
        return c.HTMLElement = t, n
    },
    tr = e => er((() => n.createElement(e))),
    nr = {
        boolean: {
            stringify: e => "" === e ? "true" : e ? /^[ty1-9]/i.test(e).toString() : "false",
            parse: (e, t, n) => "" === e || (e ? /^[ty1-9]/i.test(e) : n.hasAttribute(t) && null === e)
        },
        function: {
            stringify: e => "function" == typeof e ? e.name.replace("bound ", "") : "string" == typeof e ? e.replace("bound ", "") : e,
            parse: (e, t, n) => {
                if (!e) return null;
                const o = "undefined" != typeof window ? window[e] : "undefined" != typeof global ? global[e] : void 0;
                return "function" == typeof o ? o.bind(n) : void 0
            }
        },
        number: {
            stringify: e => `${e}`,
            parse: e => {
                if (e) return parseFloat(e)
            }
        },
        string: {
            stringify: e => e,
            parse: e => {
                if (e) return e
            }
        }
    };

function or(e, {
    methods: t,
    name: n,
    props: o,
    shadow: r
}) {
    var i;
    if ("undefined" == typeof window) return;
    const {
        notify: a
    } = new kn(n);

    function s() {
        const t = (e => er((() => Reflect.construct(HTMLElement, [], e))))(s);
        if (t._eventListenerReadyPromise = new Promise((e => {
                t._eventListenerReadyPromiseResolve = e
            })), t._vdomComponent = e, t._root = r ? t.attachShadow({
                mode: r
            }) : t, r) {
            const e = new CSSStyleSheet;
            e.replaceSync(xt), t._root.adoptedStyleSheets = [e]
        }
        return t
    }
    const l = new Map;
    Object.entries(o || {}).forEach((([e, t]) => {
        const n = Pn(e);
        l.set(n, {
            attribute: n,
            preactProp: e,
            type: t
        })
    }));
    const c = Array.from(l.values()).map((({
        attribute: e
    }) => e));

    function d(e) {
        this.getChildContext = () => e.context;
        const {
            context: t,
            children: n
        } = e;
        return ce(n, _(e, ["context", "children"]))
    }

    function u(e) {
        return F("slot", Object.assign({}, e))
    }

    function p(e, t) {
        if (3 === e.nodeType) return e.data;
        if (1 !== e.nodeType) return null;
        const n = {},
            o = [],
            {
                childNodes: r
            } = e;
        l.forEach((({
            attribute: t,
            preactProp: o,
            type: r
        }) => {
            const i = nr[r],
                a = e.getAttribute(t);
            let s = a;
            ("boolean" === r || a) && (s = i.parse(a, t, e)), null !== s && (n[t] = s, n[o] = s)
        }));
        for (const e of r) {
            const t = p(e, null);
            o.push(t)
        }
        const i = t ? F(u, null, o) : o;
        return F(t, n, i)
    }
    s.prototype = Object.create(HTMLElement.prototype), s.prototype.constructor = s, s.observedAttributes = c, s.prototype.attributeChangedCallback = function(e, t, n) {
        if (!this._vdom) return;
        const o = l.get(e);
        if (!o) return;
        const {
            preactProp: r,
            type: i
        } = o, a = nr[i], s = {};
        if (n || "boolean" !== i) {
            if (i && n) {
                const t = a.parse(n, e, this);
                s[e] = t, s[r] = t
            }
        } else {
            const t = a.parse(n, e, this);
            s[e] = t, s[r] = t
        }
        this._vdom = ce(this._vdom, s), le(this._vdom, this._root)
    }, s.prototype.connectedCallback = function() {
        const e = new CustomEvent("_preact", {
            detail: {},
            bubbles: !0,
            cancelable: !0
        });
        this.dispatchEvent(e);
        const t = e.detail.context;
        this._vdom = F(d, Object.assign(Object.assign({}, this._props), {
            context: t,
            element: this
        }), p(this, this._vdomComponent)), le(this._vdom, this._root)
    }, null == t || t.forEach((e => {
        s.prototype[e] = function(t) {
            this._eventListenerReadyPromise.then((() => {
                this.dispatchEvent(new CustomEvent(e, {
                    detail: t
                }))
            })).catch((() => {
                a(new Mn(`Custom element ${n}: Error listening for methods`, "CustomElementMethodListenerError"))
            }))
        }
    })), s.prototype.disconnectedCallback = function() {
        le(this._vdom = null, this._root)
    }, l.forEach((({
        attribute: e,
        type: t
    }) => {
        const n = nr[t];
        Object.defineProperty(s.prototype, e, {
            get() {
                return this._vdom && this._vdom.props ? this._vdom.props[e] : null
            },
            set(o) {
                let r = o;
                this._vdom ? this.attributeChangedCallback(e, null, o) : (("boolean" === t || o) && (r = n.parse(o, e, this)), this._props || (this._props = {}), this._props[e] = r, this.connectedCallback()), this.setAttribute(e, n.stringify(r))
            }
        })
    }));
    return customElements.get(n) ? void 0 : (null === (i = Reflect.defineProperty) || void 0 === i || i.call(Reflect, s, "componentVersion", {
        value: "preact"
    }), ((e, t) => {
        er((() => {
            customElements.define(e, t)
        }))
    })(n, s))
}

function rr({
    className: e
}) {
    return pe("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 50 50",
        children: [pe("path", {
            fill: "currentColor",
            d: "M50 12.5C50 5.597 44.403 0 37.5 0h-25C5.597 0 0 5.597 0 12.5v25C0 44.403 5.597 50 12.5 50h25C44.403 50 50 44.403 50 37.5v-25z"
        }), pe("path", {
            fill: "#fff",
            d: "M14.551 17.49v12.2a.09.09 0 0 0 .092.092h2.249a.091.091 0 0 0 .091-.091v-5.203c0-1.007.676-1.726 1.761-1.726 1.189 0 1.484.969 1.484 1.96v4.969a.09.09 0 0 0 .027.065.09.09 0 0 0 .066.026h2.24a.092.092 0 0 0 .09-.091v-5.266c0-.18-.007-.357-.022-.53a4.681 4.681 0 0 0-.416-1.628c-.52-1.084-1.505-1.785-2.989-1.785a2.989 2.989 0 0 0-2.336 1.195l-.056.066V17.49a.092.092 0 0 0-.091-.092h-2.098a.092.092 0 0 0-.092.092zm-3.441 6.862s-1.088-.256-1.489-.357c-.4-.102-1.101-.328-1.101-.848 0-.544.562-.696 1.138-.696.576 0 1.21.137 1.261.771a.09.09 0 0 0 .09.08l2.108-.008a.091.091 0 0 0 .086-.06.092.092 0 0 0 .005-.036c-.13-2.027-1.915-2.752-3.563-2.752-1.953 0-3.377 1.28-3.377 2.698 0 1.03.294 2 2.597 2.673.402.118.954.27 1.433.4.577.16.884.4.884.784 0 .443-.652.75-1.277.75-.916 0-1.567-.338-1.62-.946a.09.09 0 0 0-.09-.08l-2.104.01a.09.09 0 0 0-.066.028.092.092 0 0 0-.025.066c.096 1.914 1.951 2.945 3.68 2.945 2.57 0 3.74-1.45 3.74-2.796.003-.628-.143-2.075-2.31-2.627zm25.703-2.588V20.54a.088.088 0 0 0-.026-.064.09.09 0 0 0-.065-.027h-2.1a.09.09 0 0 0-.09.09v11.994a.088.088 0 0 0 .026.064.089.089 0 0 0 .065.026h2.249a.09.09 0 0 0 .09-.09v-3.937h.034c.356.542 1.334 1.192 2.608 1.192 2.401 0 4.397-1.98 4.397-4.66 0-2.569-1.984-4.651-4.51-4.651-1.125 0-2.069.62-2.677 1.369v-.082zm2.468 5.747c-1.292 0-2.32-1.072-2.32-2.38 0-1.308 1.027-2.368 2.32-2.368 1.294 0 2.33 1.06 2.33 2.368 0 1.308-1.036 2.38-2.33 2.38zm-11.406-7.554c-2.096 0-3.142.708-3.983 1.28l-.024.016a.205.205 0 0 0-.063.275l.867 1.487a.213.213 0 0 0 .322.056l.065-.054c.432-.36 1.086-.905 2.761-1.04.933-.074 1.74.176 2.33.72.653.601 1.044 1.57 1.044 2.594 0 1.88-1.114 3.064-2.902 3.088-1.474-.008-2.466-.774-2.466-1.906 0-.599.237-1.04.77-1.43a.207.207 0 0 0 .061-.263l-.744-1.402a.215.215 0 0 0-.297-.083c-.836.493-1.822 1.446-1.767 3.182.067 2.21 1.912 3.896 4.31 3.965h.273c2.85-.092 4.907-2.198 4.907-5.048 0-2.637-1.914-5.437-5.463-5.437z"
        })]
    })
}

function ir(...e) {
    return e.map((e => "object" == typeof e && "string" == typeof(null == e ? void 0 : e.value) ? e.value : e)).filter((e => "string" == typeof e)).join(" ")
}
const ar = () => Le(Ot);
const sr = function(e) {
        const t = function(e) {
            if (e.match(/\.shop\.dev$/) && "web-shop-client.shop.dev" !== e) return "shop.dev"
        }(e.hostname);
        return t ? {
            coreAuthDomain: `https://shop1.my.${t}`,
            payAuthDomain: `https://shop-server.${t}`,
            payAuthDomainAlt: `https://pay-shopify-com.${t}`
        } : {
            coreAuthDomain: e.origin,
            payAuthDomain: "https://shop.app",
            payAuthDomainAlt: "https://pay.shopify.com"
        }
    }(c.location),
    lr = sr.coreAuthDomain,
    cr = sr.payAuthDomain,
    dr = sr.payAuthDomainAlt;

function ur() {
    const {
        notify: e
    } = wt(), {
        element: t
    } = Ct();
    return Ae(((n, o, r = !1) => {
        t ? t.dispatchEvent(new CustomEvent(n, {
            bubbles: r,
            cancelable: !1,
            composed: !0,
            detail: o
        })) : e(new Error("dispatchEvent called without a reference to the custom element."))
    }), [t, e])
}

function pr(e, t) {
    try {
        const n = new c.URL(e).host.split(".").reverse(),
            o = new c.URL(t).host.split(".").reverse();
        for (let e = 0; e < Math.min(n.length, o.length); e++)
            if (n[e] !== o[e]) return !1;
        return !0
    } catch (e) {
        return !1
    }
}

function hr(e) {
    return !("string" != typeof e || !e) && RegExp(/^[^@]+@[^@]+\.[^@]{2,}$/i).test(e)
}

function fr({
    allowedOrigins: e,
    event: t,
    source: n
}) {
    return !! function(e, t) {
        return e.source === t
    }(t, n) && (!!e.some((e => pr(e, t.origin))) || (console.error("Origin mismatch for message event", t), !1))
}

function mr({
    allowedOrigins: e,
    destination: t = c,
    handler: n,
    source: o
}) {
    const {
        trackPostMessageTransmission: r
    } = St(), i = Ne((() => new Set), []);
    Ce((() => (i.add(n), () => {
        i.delete(n)
    })), [n, i]), Ce((() => {
        const e = e => function(e) {
            return "object" == typeof e && null !== e && "messageId" in e && "type" in e
        }(e) && r({
            direction: "incoming",
            event: e
        });
        return i.add(e), () => {
            i.delete(e)
        }
    }), [r, i]);
    const a = Ae((e => {
            i.forEach((t => t(e)))
        }), [i]),
        s = Ae((t => {
            const n = o.current instanceof HTMLIFrameElement ? o.current.contentWindow : o.current;
            fr({
                allowedOrigins: e,
                event: t,
                source: n
            }) && a(t.data)
        }), [e, a, o]),
        l = Ae((() => {
            t.removeEventListener("message", s, !1)
        }), [t, s]);
    Ce((() => (t.addEventListener("message", s, !1), () => {
        l()
    })), [t, l, s]);
    const d = Ae(((e, t) => y(this, void 0, void 0, (function*() {
        let n;
        return new Promise(((o, r) => {
            function a() {
                r(new Mn("Abort signal received", "AbortSignalReceivedError"))
            }(null == t ? void 0 : t.aborted) && a(), n = n => {
                n.type === e && (null == t || t.removeEventListener("abort", a), o(n))
            }, i.add(n), null == t || t.addEventListener("abort", a)
        })).finally((() => {
            i.delete(n)
        }))
    }))), [i]);
    return {
        destroy: l,
        waitForMessage: d
    }
}

function vr(e) {
    var {
        includeCore: t,
        source: n,
        storefrontOrigin: o
    } = e, r = _(e, ["includeCore", "source", "storefrontOrigin"]);
    const i = ur(),
        a = Ae((e => y(this, void 0, void 0, (function*() {
            const {
                onAuthorizeStepChanged: t,
                onClose: n,
                onComplete: o,
                onConfirmSuccess: a,
                onContinueToCheckout: s,
                onCustomFlowSideEffect: l,
                onDiscountSaved: c,
                onEmailChangeRequested: d,
                onError: u,
                onLeadCaptureLoaded: p,
                onLoaded: h,
                onModalOpened: f,
                onPopUpOpened: m,
                onPrequalError: v,
                onPrequalMissingInformation: g,
                onPrequalReady: _,
                onPrequalSuccess: y,
                onProcessingStatusUpdated: b,
                onPromptChange: w,
                onPromptContinue: x,
                onResizeIframe: k,
                onRestarted: E,
                onShopUserMatched: S,
                onShopUserNotMatched: P,
                onUnloaded: M,
                onUserVerified: j,
                onVerificationStepChanged: C
            } = r;
            switch (e.type) {
                case "authorize_step_changed":
                    null == t || t(e);
                    break;
                case "close":
                case "close_requested":
                    null == n || n();
                    break;
                case "completed":
                    {
                        const {
                            avatar: t,
                            email: n,
                            givenName: r,
                            loggedIn: a,
                            shouldFinalizeLogin: s
                        } = e;o && (yield o(e)),
                        i("completed", e),
                        a && s && i("storefront:signincompleted", {
                            avatar: (() => {
                                const e = tr("shop-user-avatar"),
                                    o = (null == r ? void 0 : r[0]) || (null == n ? void 0 : n[0]) || "";
                                return e.setAttribute("src", t || ""), e.setAttribute("initial", o), e
                            })()
                        }, !0);
                        break
                    }
                case "confirm_success":
                    null == a || a();
                    break;
                case "continue_to_checkout":
                    null == s || s();
                    break;
                case "custom_flow_side_effect":
                    null == l || l(e);
                    break;
                case "discount_saved":
                    null == c || c();
                    break;
                case "email_change_requested":
                    null == d || d();
                    break;
                case "error":
                    null == u || u(e), i("error", {
                        code: e.code,
                        message: e.message,
                        email: e.email
                    });
                    break;
                case "loaded":
                    i("loaded", e), "loginTitle" in e ? null == p || p(e) : null == h || h(e);
                    break;
                case "unloaded":
                    null == M || M(e);
                    break;
                case "modalopened":
                    null == f || f();
                    break;
                case "pop_up_opened":
                    null == m || m(e), i("popuploading", e);
                    break;
                case "processing_status_updated":
                    null == b || b();
                    break;
                case "prequal_error":
                    null == v || v();
                    break;
                case "prequal_missing_information":
                    null == g || g();
                    break;
                case "prequal_ready":
                    null == _ || _();
                    break;
                case "prequal_success":
                    null == y || y();
                    break;
                case "resize_iframe":
                    null == k || k(e);
                    break;
                case "restarted":
                    null == E || E(), i("restarted");
                    break;
                case "shop_user_matched":
                    null == S || S(e);
                    break;
                case "shop_user_not_matched":
                    null == P || P(e);
                    break;
                case "user_verified":
                    null == j || j(e);
                    break;
                case "verification_step_changed":
                    null == C || C(e);
                    break;
                case "prompt_change":
                    null == w || w();
                    break;
                case "prompt_continue":
                    null == x || x()
            }
        }))), [i, r]);
    return mr({
        allowedOrigins: Ne((() => [cr, dr, ...t ? [lr] : [], ...o ? [o] : []]), [t, o]),
        handler: a,
        source: n
    })
}
const gr = "temporarily_unavailable",
    _r = "Shop login is temporarily unavailable";

function yr() {
    const e = ur(),
        t = Te(null),
        n = Ae((() => {
            t.current && (clearTimeout(t.current), t.current = null)
        }), []);
    return {
        initLoadTimeout: Ae((() => {
            n(), t.current = setTimeout((() => {
                e("error", {
                    message: _r,
                    code: gr
                }), n()
            }), 1e4)
        }), [n, e]),
        clearLoadTimeout: n
    }
}

function br(e) {
    const t = Te(e);
    return Ce((() => {
        t.current = e
    })), t.current
}

function wr({
    contentWindow: e,
    event: t,
    onMessageSent: n
}) {
    if (!e) return;
    const o = [cr, dr],
        r = Object.assign(Object.assign({}, t), {
            messageId: s()
        });
    o.forEach((t => {
        e.postMessage(r, t)
    })), null == n || n(r)
}
class xr {
    constructor(e) {
        this._source = e
    }
    isSourceOf(e) {
        return e.source === this._source.contentWindow
    }
}
const kr = ({
    iframe: e,
    src: t
}) => {
    const n = null == e ? void 0 : e.parentNode;
    n && e && (n.removeChild(e), e.setAttribute("src", ""), e.setAttribute("src", t), n.appendChild(e))
};

function Er({
    className: e
}) {
    return pe("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 20 20",
        children: pe("path", {
            fill: "currentColor",
            "fill-rule": "evenodd",
            d: "M0 10C0 4.477 4.477 0 10 0s10 4.477 10 10-4.477 10-10 10S0 15.523 0 10Zm7.707-3.707a1 1 0 0 0-1.414 1.414L8.586 10l-2.293 2.293a1 1 0 1 0 1.414 1.414L10 11.414l2.293 2.293a1 1 0 0 0 1.414-1.414L11.414 10l2.293-2.293a1 1 0 0 0-1.414-1.414L10 8.586 7.707 6.293Z",
            "clip-rule": "evenodd"
        })
    })
}
const Sr = ({
        className: e,
        headerTitle: t,
        headerLogo: n,
        onDismiss: o
    }) => {
        const {
            translate: r
        } = Jo(), i = Boolean(t), a = i ? "with-title" : "default";
        return pe("div", {
            className: ir("flex w-full items-center p-4 pb-2", n ? "justify-between" : "justify-end", i && "mb-5 gap-x-4 border-b border-solid border-grayscale-l2l px-5 pb-4", e),
            "data-testid": "authorize-modal-header",
            "data-variant": a,
            children: [n, i && pe("div", {
                className: "flex-1 font-sans text-body-large",
                children: t
            }), pe("button", {
                "aria-label": r("button.close", {
                    defaultValue: "Close"
                }),
                className: "group relative z-50 flex size-6 cursor-pointer rounded-max",
                "data-testid": "authorize-modal-close-button",
                onClick: () => o("close_button"),
                type: "button",
                children: [pe(Er, {
                    className: "size-6 text-grayscale-l4 transition-colors group-hover_text-grayscale-l2l"
                }), pe("div", {
                    className: "absolute inset-05 -z-10 rounded-max bg-grayscale-primary-light"
                })]
            })]
        })
    },
    Pr = '\n  a[href],\n  area[href],\n  input:not([type="hidden"]):not([disabled]):not([tabindex="-1"]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]):not([tabindex="-1"]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls]';
const Mr = Ge(((e, t) => {
        var {
            as: n = "div",
            children: o,
            disabled: r = !1
        } = e, i = _(e, ["as", "children", "disabled"]);
        const a = Te(null),
            s = Te(null),
            l = Te(null);
        Oe((() => {
            var e;
            r || null === (e = a.current) || void 0 === e || e.focus()
        }), [r]);
        const c = e => {
                const t = a.current;
                if (!t || r) return;
                ((e ? t.querySelector(Pr) : function(e) {
                    const t = e.querySelectorAll(Pr);
                    return t[t.length - 1]
                }(t)) || t).focus()
            },
            d = r ? -1 : 0,
            u = "absolute -m-px h-px w-px overflow-hidden whitespace-nowrap p-0";
        return pe(B, {
            children: [pe("div", {
                className: u,
                ref: s,
                onFocus: () => c(!1),
                tabIndex: d
            }), pe(n, Object.assign({}, i, {
                ref: e => {
                    a.current = e, "function" == typeof t ? t(e) : t && (t.current = e)
                },
                tabIndex: -1,
                children: o
            })), pe("div", {
                className: u,
                ref: l,
                onFocus: () => c(!0),
                tabIndex: d
            })]
        })
    })),
    jr = "e_db171811ef21b52a48282dfe9378529b",
    Cr = ({
        anchorTo: e,
        children: t,
        headerLogo: o,
        headerTitle: r,
        hideHeader: i = !1,
        inlineTitle: a = "Sign in with Shop",
        onDismiss: s,
        visible: l = !0
    }) => {
        const {
            dispatch: d,
            modalDismissible: u
        } = ar(), p = Te(null), h = Te(null), [f, m] = Me(null), [v, g] = Me(null), [_, y] = Me(!1), [b, w] = Me(!1), [x, k] = Me(0), [E, S] = Me(0), [P, M] = Me(0);
        Ce((() => {
            if (!l) return void y(!1);
            const e = () => y(!0),
                t = p.current;
            return null == t || t.addEventListener("transitionend", e, {
                once: !0
            }), () => {
                null == t || t.removeEventListener("transitionend", e)
            }
        }), [l]), Ce((() => {
            if (l) {
                const e = setTimeout((() => {
                    d({
                        type: "modalDismissible"
                    })
                }), 400);
                return () => {
                    clearTimeout(e)
                }
            }
        }), [d, l]), Ce((() => {
            if (!e) return;
            let t;
            t = "string" == typeof e ? n.querySelector(e) : e.current;
            const o = null == t ? void 0 : t.closest('[id="contact-information-text-field-container"]');
            m(t), g(o)
        }), [e]), Ce((() => {
            if (v && !b) return v.style.setProperty("opacity", l ? "0" : "1"), () => {
                v.style.removeProperty("opacity")
            }
        }), [v, b, l]), Tr({
            emailInputElement: f,
            setShimmering: w,
            visible: l
        });
        const {
            emailInputResizeObserver: j,
            containerResizeObserver: C,
            inlineResizeObserver: O
        } = Ne((() => void 0 !== c && c.ResizeObserver ? {
            emailInputResizeObserver: new ResizeObserver((([e]) => {
                const t = e.contentRect.height;
                M(t)
            })),
            containerResizeObserver: new ResizeObserver((([e]) => {
                const t = e.contentRect.height;
                S(t)
            })),
            inlineResizeObserver: new ResizeObserver((([e]) => {
                const t = e.contentRect.height;
                k(t)
            }))
        } : {
            emailInputResizeObserver: void 0,
            containerResizeObserver: void 0,
            inlineResizeObserver: void 0
        }), []);
        Or({
            resizeObserver: j,
            elementRef: v,
            setHeight: M
        }), Or({
            resizeObserver: C,
            elementRef: h.current,
            setHeight: S
        }), Or({
            resizeObserver: O,
            elementRef: p.current,
            setHeight: k
        });
        const T = Ae((e => {
                u && s(e)
            }), [u, s]),
            I = l && !b,
            N = ir("overflow-hidden transition-[height] duration-400 ease-cubic-modal will-change-transform [interpolate-size:allow-keywords] motion-reduce_duration-0", I ? "h-auto" : "h-0"),
            A = {
                transform: `translateY(${-P}px)`,
                height: I ? `${x}px` : "0px",
                marginBottom: E >= 2 * P ? `-${P}px` : 0
            },
            L = ir("overflow-hidden border border-solid border-grayscale-l2l bg-white opacity-0 transition-opacity duration-400 ease-cubic-modal will-change-transform motion-reduce_duration-0", !i && "rounded-sm", I ? "opacity-100" : "opacity-0");
        return pe("div", {
            ref: h,
            className: N,
            style: A,
            children: pe(Mr, {
                as: "section",
                disabled: !_,
                "aria-modal": "true",
                "aria-hidden": !l,
                "aria-label": a,
                className: "focus_outline-none focus_outline-0",
                "data-testid": "authorize-inline",
                "data-visible": l,
                part: "inline-authorize",
                ref: e => {
                    p.current = e
                },
                role: "dialog",
                children: pe("div", {
                    className: L,
                    children: [!i && pe(Sr, {
                        "aria-hidden": !l,
                        className: "aria-hidden_opacity-0",
                        headerTitle: r,
                        headerLogo: o,
                        onDismiss: T
                    }), t]
                })
            })
        })
    },
    Or = ({
        resizeObserver: e,
        elementRef: t,
        setHeight: n
    }) => {
        Ce((() => {
            if (e && t) return e.observe(t), n(t.offsetHeight), () => {
                e.disconnect()
            }
        }), [t, e, n])
    },
    Tr = ({
        emailInputElement: e,
        setShimmering: t,
        visible: o
    }) => {
        Ce((() => {
            const e = "inline-authorize-shimmer-keyframes";
            if (n.getElementById(e)) return;
            const t = n.createElement("style");
            return t.id = e, t.textContent = "\n      @keyframes shimmer {\n        0% {\n          background-position-x: 100%;\n        }\n        100% {\n          background-position-x: 0%;\n        }\n      }\n    ", n.head.appendChild(t), () => {
                const t = n.getElementById(e);
                null == t || t.remove()
            }
        }), []);
        const r = Ae((() => {
                e && (t(!0), e.style.setProperty("background-image", "\n        linear-gradient(\n          90deg,\n          var(--x-default-color-text) 0%,\n          var(--x-default-color-text) 35%,\n          var(--x-default-color-accent) 48%,\n          var(--x-default-color-accent) 52%,\n          var(--x-default-color-text) 65%,\n          var(--x-default-color-text) 100%\n        )\n      "), e.style.setProperty("background-size", "300% 100%"), e.style.setProperty("background-clip", "text"), e.style.setProperty("background-color", "transparent"), e.style.setProperty("color", "transparent"), e.style.setProperty("caret-color", "var(--x-default-color-text)"), e.style.setProperty("animation", "shimmer 500ms ease-out"))
            }), [e, t]),
            i = Ae((() => {
                e && (t(!1), e.style.removeProperty("background-image"), e.style.removeProperty("background-size"), e.style.removeProperty("background-clip"), e.style.removeProperty("background-color"), e.style.removeProperty("color"), e.style.removeProperty("caret-color"), e.style.removeProperty("animation"))
            }), [e, t]),
            a = Ae((() => {
                if (!e) return;
                const t = e,
                    n = t.value;
                t.value = `${n} `, t.offsetHeight, t.value = n
            }), [e]);
        Ce((() => {
            if (!e) return;
            const t = e => {
                "shimmer" === e.animationName && i()
            };
            return e.addEventListener("animationend", t), () => {
                e.removeEventListener("animationend", t), i()
            }
        }), [e, i]), Zo({
            shopusermatched: () => {
                o || (a(), r())
            },
            modalclosed: () => {
                i()
            }
        })
    },
    Ir = {
        mobile: ["max-width: 448px"],
        tablet: ["min-width: 449px", "max-width: 1000px", "max-height: 920px"]
    };

function Nr() {
    const e = Ir.mobile.every((e => c.matchMedia(`(${e})`).matches)),
        t = !e && Ir.tablet.every((e => c.matchMedia(`(${e})`).matches));
    return {
        isMobile: e,
        isTablet: t,
        isDesktop: !e && !t
    }
}

function Ar() {
    return Boolean(Bt.userAgent) && /(android|iphone|ipad|mobile|phone)/i.test(Bt.userAgent) || function() {
        const e = Bt.userAgent.toLowerCase();
        return e.includes("fban/fbios") || e.includes("fb_iab/fb4a")
    }() || Bt.userAgent.toLowerCase().includes("instagram") || Bt.userAgent.toLowerCase().includes("messenger") || function() {
        const e = Bt.userAgent;
        return RegExp(zr).test(e) || RegExp(Dr).test(e)
    }() || /Mozilla\/5.0 \([^)]*Android[^)]*; wv\).+Chrome\//.test(Bt.userAgent)
}

function Lr(e) {
    return "/" === e ? e : e.endsWith("/") ? e.slice(0, -1) : e
}

function Rr() {
    return Boolean("undefined" != typeof IntersectionObserver && IntersectionObserver)
}
const zr = "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|).* AppleNews",
    Dr = "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|)(?!.*Version).*Mobile(?!.*Safari)";

function Ur({
    className: e
}) {
    return pe("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 60 25",
        role: "img",
        children: [pe("title", {
            children: "Shop"
        }), pe("path", {
            fill: "currentColor",
            d: "M7.74 11.067c-2.35-.509-3.396-.708-3.396-1.612 0-.85.708-1.274 2.125-1.274 1.246 0 2.157.544 2.828 1.609.05.082.155.11.24.066l2.644-1.334a.186.186 0 0 0 .076-.259c-1.098-1.9-3.125-2.94-5.794-2.94-3.507 0-5.686 1.727-5.686 4.47 0 2.914 2.653 3.65 5.006 4.16 2.353.509 3.403.708 3.403 1.612 0 .904-.765 1.33-2.293 1.33-1.41 0-2.457-.644-3.09-1.896a.185.185 0 0 0-.25-.082L.916 16.222a.188.188 0 0 0-.082.253c1.046 2.102 3.194 3.284 6.062 3.284 3.653 0 5.86-1.697 5.86-4.526 0-2.83-2.666-3.65-5.015-4.16v-.006ZM21.909 5.324c-1.5 0-2.824.53-3.776 1.476a.093.093 0 0 1-.158-.067V.7a.185.185 0 0 0-.187-.186H14.48a.185.185 0 0 0-.187.186v18.728c0 .105.083.187.187.187h3.308a.185.185 0 0 0 .187-.187v-8.215c0-1.586 1.217-2.803 2.859-2.803 1.641 0 2.83 1.191 2.83 2.803v8.215c0 .105.082.187.187.187h3.308a.185.185 0 0 0 .186-.187v-8.215c0-3.451-2.264-5.888-5.436-5.888ZM34.056 4.786c-1.796 0-3.478.55-4.687 1.344a.187.187 0 0 0-.06.25l1.458 2.487c.054.089.168.12.256.066a5.812 5.812 0 0 1 3.04-.834c2.887 0 5.01 2.035 5.01 4.725 0 2.292-1.7 3.99-3.853 3.99-1.755 0-2.973-1.022-2.973-2.463 0-.825.351-1.501 1.265-1.979a.183.183 0 0 0 .073-.259L32.21 9.787a.186.186 0 0 0-.224-.08c-1.844.683-3.137 2.327-3.137 4.533 0 3.338 2.66 5.829 6.369 5.829 4.333 0 7.448-3 7.448-7.302 0-4.611-3.624-7.98-8.609-7.98ZM52.342 5.295c-1.673 0-3.169.62-4.26 1.707a.092.092 0 0 1-.158-.066V5.627a.185.185 0 0 0-.186-.186h-3.223a.185.185 0 0 0-.187.186v18.7c0 .104.082.186.187.186h3.308a.185.185 0 0 0 .187-.187v-6.131c0-.083.098-.124.158-.07 1.088 1.012 2.527 1.602 4.174 1.602 3.88 0 6.907-3.138 6.907-7.216 0-4.077-3.03-7.216-6.907-7.216Zm-.626 11.265c-2.207 0-3.88-1.754-3.88-4.074s1.67-4.074 3.88-4.074 3.877 1.726 3.877 4.074c0 2.349-1.644 4.074-3.88 4.074h.003Z"
        })]
    })
}
const Fr = Ge(((e, t) => {
    var {
        children: n,
        className: o,
        disableTransition: r = !1
    } = e, i = _(e, ["children", "className", "disableTransition"]);
    return pe("button", Object.assign({}, i, {
        className: ir("relative m-0 flex w-auto items-center overflow-visible rounded-login-button bg-purple-primary p-0 hover_enabled_bg-purple-d0 focus_enabled_outline-none focus_enabled_ring focus_enabled_ring-purple-l1 focus-visible_enabled_outline-none focus-visible_enabled_ring focus-visible_enabled_ring-purple-l1 disabled_opacity-50", !r && "transition-all", o),
        ref: t,
        type: "button",
        children: n
    }))
}));
Fr.displayName = "Button";
const $r = Ge(((e, t) => {
    var {
        bordered: n,
        buttonClassName: o,
        children: r,
        className: i,
        fullWidth: a
    } = e, s = _(e, ["bordered", "buttonClassName", "children", "className", "fullWidth"]);
    return pe(Fr, Object.assign({}, s, {
        className: ir("m-auto", n ? "border border-solid border-white/20" : "border-none", a ? "w-full justify-center" : void 0, o),
        ref: t,
        children: pe("span", {
            className: ir("mx-auto flex cursor-pointer items-center justify-center gap-text-icon whitespace-nowrap p-shop-button font-sans text-branded-button text-white", i),
            children: r
        })
    }))
}));

function Br() {
    return pe(Ur, {
        className: "flex aspect-branded-button-icon h-branded-button-icon w-auto translate-y-[9.375%] self-center"
    })
}
$r.displayName = "BrandedButton", Br.displayName = "BrandedButtonIcon";
const Hr = ({
        defaultUxMode: e,
        uxMode: t
    }) => Ne((() => {
        const n = Ar();
        return "windoid" === t && n ? e : t
    }), [e, t]),
    Vr = e => {
        if (void 0 !== e) return !1 === e ? "false" : "true"
    };

function Wr({
    analyticsContext: e,
    analyticsTraceId: t,
    apiKey: n,
    avoidSdkSession: o,
    checkoutRedirectUrl: r,
    checkoutToken: i,
    checkoutVersion: a,
    clientId: s,
    codeChallenge: l,
    codeChallengeMethod: d,
    consentChallenge: u,
    ctx: p,
    disableSignUp: h,
    embed: f,
    error: m,
    experiments: v,
    flow: g,
    flowVersion: _,
    hideCopy: y,
    isCompactLayout: b = !0,
    isFullView: w,
    locale: x,
    loginHint: k,
    modalCustomized: E,
    orderId: S,
    origin: P,
    personalizeAds: M,
    prompt: j,
    placement: C,
    popUpFeatures: O,
    popUpName: T,
    redirectType: I,
    redirectUri: N,
    requireVerification: A,
    responseMode: L,
    responseType: R,
    returnUri: z,
    scope: D,
    shopId: U,
    shopifyEssential: F,
    state: $,
    storefrontDomain: B,
    transactionParams: H,
    uxMode: V,
    uxRole: W,
    hideButtons: q,
    hideHeader: K,
    accentColor: G,
    darkMode: X,
    returnTo: Y
}) {
    const J = void 0 === h ? void 0 : !1 === h,
        Z = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({
            analytics_context: e,
            analytics_trace_id: t,
            avoid_sdk_session: Vr(o),
            api_key: n,
            checkout_redirect_url: r,
            checkout_token: i,
            checkout_version: a,
            client_id: s,
            code_challenge: l,
            code_challenge_method: d,
            compact_layout: Vr(b),
            consent_challenge: Vr(u),
            ctx: p,
            "customize-modal": Vr(E),
            embed: f
        }, m && {
            error: m
        }), v && {
            experiments: v
        }), {
            flow: g ? g.toString() : void 0,
            flow_version: _,
            full_view: Vr(w),
            hide_copy: Vr(y),
            locale: x
        }), k && {
            login_hint: k
        }), {
            order_id: S ? S.toString() : void 0,
            origin: P,
            personalize_ads: Vr(M),
            hide_buttons: Vr(q),
            hide_header: Vr(K),
            accent_color: G,
            dark_mode: Vr(X),
            placement: C,
            pop_up_features: "pop_up" === I ? O : void 0,
            pop_up_name: "pop_up" === I ? T : void 0,
            preact: "true",
            prompt: j,
            redirect_type: I,
            redirect_uri: N || c.location.origin,
            require_verification: Vr(A),
            response_mode: L || "web_message",
            response_type: R || "id_token"
        }), z && {
            return_uri: z
        }), Y && {
            return_to: Y
        }), {
            scope: D || "openid email profile",
            sign_up_enabled: Vr(J),
            shop_id: U ? U.toString() : void 0,
            shopify_essential: F,
            state: $,
            storefront_domain: B,
            target_origin: c.location.origin,
            transaction_params: H,
            ux_mode: V,
            ux_role: W
        });
    return Object.keys(Z).forEach((e => void 0 === Z[e] && delete Z[e])), new URLSearchParams(Z)
}

function qr(e) {
    const t = Wr(e),
        n = new Set(["return_to", "locale", "login_hint", "login_hint_mode", "sso"]),
        o = {},
        r = {};
    "none" === e.prompt && (o.sso = "silent"), "windoid" === e.uxMode && (o.display = e.returnTo ? "redirect" : "popup");
    for (const [e, i] of t.entries()) n.has(e) ? o[e] = i : r[e] = i;
    return Object.keys(r).length > 0 && (o.shop_params = new URLSearchParams(r).toString()), new URLSearchParams(o)
}

function Kr(e) {
    if (!e.proxy && void 0 === (null == e ? void 0 : e.clientId)) return "";
    if (e.proxy) {
        if (e.proxyCoreIdp) {
            const t = qr(e);
            return `${lr}/customer_authentication/login?${t}`
        } {
            const t = Wr(e);
            return `${lr}/services/login_with_shop/authorize?${t}`
        }
    }
    const t = Wr(e);
    if (function(e) {
            return "loginWithShopSelfServe" === e.analyticsContext && "iframe" !== e.uxMode && "prompt" !== e.uxRole
        }(e)) return `${cr}/oauth/authorize?${t}`;
    const n = e.avoidPayAltDomain ? "/pay/sdk-authorize" : "/pay/sdk-session";
    return `${cr}${n}?${t}`
}

function Gr(e) {
    var {
        analyticsContext: t,
        avoidPayAltDomain: n = !1,
        avoidSdkSession: o = !1,
        disableSignUp: r = !1,
        experiments: i,
        proxy: a,
        clientId: s,
        flow: l = "default",
        flowVersion: d = "unspecified",
        error: u,
        prompt: p = "login",
        responseMode: h,
        storefrontDomain: f
    } = e, m = _(e, ["analyticsContext", "avoidPayAltDomain", "avoidSdkSession", "disableSignUp", "experiments", "proxy", "clientId", "flow", "flowVersion", "error", "prompt", "responseMode", "storefrontDomain"]);
    const {
        locale: v
    } = Xo(), {
        instanceId: g
    } = Ct(), y = Ae((e => {
        if ("prompt" === (null == e ? void 0 : e.uxRole) && !a && s) return function({
            analyticsTraceId: e,
            clientId: t,
            flow: n,
            flowVersion: o,
            locale: r,
            storefrontDomain: i
        }) {
            const a = new URLSearchParams({
                analytics_trace_id: e,
                client_id: t,
                flow: n,
                flow_version: o,
                locale: r,
                target_origin: c.location.origin,
                storefront_domain: i
            });
            return `${cr}/accounts/pre_auth?${a}`
        }({
            analyticsTraceId: g,
            clientId: s,
            flow: l,
            flowVersion: d,
            locale: v,
            storefrontDomain: f
        });
        const i = function(e, t) {
                if ("redirect" === t) return "query";
                if ("windoid" === t) return "web_message";
                return e
            }(h, m.uxMode),
            _ = function(e, t) {
                if ("redirect" === t && "loginWithShop" === e) return "loginWithShopClassicCustomerAccounts";
                return e
            }(t, m.uxMode);
        return Kr(Object.assign(Object.assign(Object.assign({
            analyticsContext: _,
            analyticsTraceId: g,
            avoidPayAltDomain: n,
            avoidSdkSession: o,
            clientId: s,
            disableSignUp: r,
            error: u,
            flow: l,
            flowVersion: d,
            locale: v,
            prompt: p,
            proxy: a,
            storefrontDomain: f
        }, i && {
            responseMode: i
        }), m), e))
    }), [t, n, o, s, r, u, l, d, g, v, p, m, a, h, f]);
    return {
        authorizeUrl: Ne((() => y()), [y]),
        getAuthorizeUrl: y
    }
}

function Xr(e = c.location.origin, t) {
    const n = `${e}/services/login_with_shop/finalize`;
    return fetch(n).catch(t)
}
const Yr = ({
    storefrontOrigin: e
}) => {
    const {
        notify: t
    } = wt(), {
        log: n
    } = Mt();
    return Ae((o => y(void 0, [o], void 0, (function*({
        loggedIn: o,
        shouldFinalizeLogin: r,
        redirectUri: i
    }) {
        o && r && (yield Xr(e, t)), i && (! function(e) {
            try {
                return "https:" === new c.URL(e).protocol
            } catch (e) {
                return !1
            }
        }(i) ? n({
            body: "Invalid redirect URI",
            attributes: {
                redirectUri: i,
                storefrontOrigin: e
            }
        }) : c.location.href = i)
    }))), [t, n, e])
};

function Jr() {
    if (! function() {
            const e = Bt.userAgent,
                t = Boolean(e.match(/iPad/i)) || Boolean(e.match(/iPhone/i)),
                n = Boolean(e.match(/WebKit/i));
            return t && n && !e.match(/CriOS/i)
        }()) return;
    const e = "shop-pay-safari-unzoom",
        t = n.getElementById(e);
    if (t) return t.focus();
    const o = n.createElement("input");
    o.id = e, o.style.fontSize = "16px", o.style.width = "1px", o.style.height = "1px", o.style.position = "fixed", o.style.bottom = "-1000px", o.style.right = "-1000px", o.style.transform = "translate(1000px, 1000px)", o.setAttribute("aria-hidden", "true"), n.body.appendChild(o), o.focus({
        preventScroll: !0
    })
}

function Zr({
    email: e,
    emailInputSelector: t,
    onGetEmailInput: o,
    hideChange: r,
    iframeRef: i,
    shouldListen: a = !0
}) {
    const {
        loaded: s,
        modalVisible: l
    } = ar(), {
        leaveBreadcrumb: c,
        notify: d
    } = wt(), {
        trackUserAction: u
    } = St(), {
        isFilledWithPasswordManager: p
    } = function({
        emailInputSelector: e
    }) {
        const [t, o] = Me(), [r, i] = Me();
        return Ce((() => {
            var t;

            function r(e) {
                "password" === this.type ? i(e.timeStamp) : o(e.timeStamp)
            }
            if (e) {
                const o = n.querySelector(e);
                if (o) {
                    o.addEventListener("input", r);
                    const e = null === (t = o.form) || void 0 === t ? void 0 : t.querySelector('input[type="password"]');
                    return e && e instanceof HTMLInputElement && e.addEventListener("input", r), () => {
                        o.removeEventListener("input", r), e && e.removeEventListener("input", r)
                    }
                }
            }
        }), [e]), {
            isFilledWithPasswordManager: Ne((() => void 0 !== t && void 0 !== r && Math.abs(t - r) < 100), [t, r])
        }
    }({
        emailInputSelector: t
    }), h = Te(null), [f, m] = Me(), [v, g] = Me(), [_, b] = Me(), w = Te(null), x = Te(""), k = Ne((() => new Set), []), E = Ae(((e, ...t) => y(this, [e, ...t], void 0, (function*(e, t = "", n = "") {
        var o, a;
        const f = hr(e);
        if (p && !k.has("PASSWORD_MANAGER_AUTOFILL_DETECTED") && (k.add("PASSWORD_MANAGER_AUTOFILL_DETECTED"), u({
                userAction: "PASSWORD_MANAGER_AUTOFILL_DETECTED"
            })), f && !k.has("EMAIL_ENTERED") && (k.add("EMAIL_ENTERED"), u({
                userAction: "EMAIL_ENTERED"
            })), c("email entered", {}, "state"), !i.current || l) return;
        if (!s) return;
        const v = f ? e : "";
        h.current && !(null === (o = h.current) || void 0 === o ? void 0 : o.signal.aborted) && h.current.abort(), h.current = new AbortController;
        try {
            const {
                open: e,
                postMessage: o,
                waitForMessage: s
            } = i.current;
            x.current = v, o({
                firstName: t,
                lastName: n,
                type: "namesubmitted"
            }), o({
                email: v,
                hideChange: void 0 === r ? v.length > 0 : r,
                type: "emailsubmitted"
            }), c("email submitted", {
                email: v ? "redacted" : ""
            }, "state");
            const l = s("shop_user_matched", h.current.signal),
                d = new Promise(((e, t) => {
                    const n = () => y(this, void 0, void 0, (function*() {
                        try {
                            const t = yield s("error", h.current.signal);
                            "error" === t.type && "captcha_challenge" === t.code ? e(void 0) : yield n()
                        } catch (e) {
                            t(e)
                        }
                    }));
                    n()
                }));
            yield Promise.race([l, d]), e("event_shop_user_matched"), null === (a = null == w ? void 0 : w.current) || void 0 === a || a.blur(), Jr(), h.current.abort(), m(void 0)
        } catch (e) {
            if (e instanceof Mn && "AbortSignalReceivedError" === e.name) return;
            e instanceof Error && d(new Error(`Error updating user info: ${e.name} - ${e.message}`))
        }
    }))), [r, i, p, c, s, l, d, u, k]), S = Fn(((e, t, n) => {
        E(e, t, n)
    }), 200);
    Ce((() => {
        void 0 !== f && s && S(f, v, _)
    }), [S, f, s, v, _]), Ce((() => {
        if (!t && !o) return;
        const e = t ? n.querySelector(t) : null == o ? void 0 : o();
        if (!e) return;
        w.current = e;
        const r = () => {
            e && m(e.value)
        };
        if ((null == e ? void 0 : e.value) && r(), a) return null == e || e.addEventListener("input", r), () => {
            null == e || e.removeEventListener("input", r)
        };
        null == e || e.removeEventListener("input", r)
    }), [t, o, a]), Ce((() => {
        void 0 !== e && m(e)
    }), [e]);
    return {
        getSubmittedEmail: () => x.current,
        updateEmailToPost: e => m(e || ""),
        updateNamesToPost: (e, t) => ((e = "", t = "") => {
            g(e), b(t)
        })(e, t)
    }
}
const Qr = ({
        handleClose: e,
        handleComplete: t,
        handleError: n,
        handleOpen: o,
        windoidRef: r
    }) => {
        const i = ur();
        return Ae((a => y(void 0, void 0, void 0, (function*() {
            var s, l, c;
            switch (a.data.type) {
                case "completed":
                    yield t(a.data), i("completed", a.data, !0), null === (s = r.current) || void 0 === s || s.close();
                    break;
                case "error":
                    yield null == n ? void 0 : n(a.data), i("error", a.data), null === (l = r.current) || void 0 === l || l.close();
                    break;
                case "windoidopened":
                    i("windoidopened"), yield null == o ? void 0 : o();
                    break;
                case "close":
                case "windoidclosed":
                    i("windoidclosed"), yield null == e ? void 0 : e(), null === (c = r.current) || void 0 === c || c.close()
            }
        }))), [i, t, e, n, o, r])
    },
    ei = ({
        getAuthorizeUrl: e,
        getEmail: t,
        iframeRef: n,
        openWindoid: o
    }) => {
        const {
            trackUserAction: r
        } = St();
        return Ae((() => {
            var i;
            r({
                userAction: "SIGN_IN_WITH_SHOP_PROMPT_CONTINUE_CLICK"
            }), null === (i = null == n ? void 0 : n.current) || void 0 === i || i.close({
                dismissMethod: "windoid_continue",
                reason: "user_prompt_continue_clicked"
            });
            const a = t(),
                s = e(Object.assign(Object.assign({}, a && {
                    loginHint: a
                }), {
                    origin: "preauth_prompt",
                    prompt: void 0
                }));
            o(s)
        }), [e, t, n, o, r])
    },
    ti = {},
    ni = (e, t, o = "SignInWithShop") => {
        var r;
        const i = ((e, t) => {
            const o = void 0 === c.screenLeft ? c.screenX : c.screenLeft,
                r = void 0 === c.screenTop ? c.screenY : c.screenTop;
            let i, a;
            i = c.innerWidth ? c.innerWidth : n.documentElement.clientWidth ? n.documentElement.clientWidth : screen.width, a = c.innerHeight ? c.innerHeight : n.documentElement.clientHeight ? n.documentElement.clientHeight : screen.height;
            const s = Math.max(1, i / c.screen.availWidth);
            return {
                height: t / s,
                left: (i - e) / 2 / s + o,
                top: (a - t) / 2 / s + r,
                width: e / s
            }
        })(365, 554);
        null === (r = ti[o]) || void 0 === r || r.call(ti);
        const a = c.open(e, "SignInWithShop", `popup,width=${i.width},height=${i.height},top=${i.top},left=${i.left}`),
            s = e => {
                fr({
                    allowedOrigins: [cr, dr, lr, c.location.origin],
                    event: e,
                    source: a
                }) && t(e)
            },
            l = () => (e => {
                null == e || e.close()
            })(a);
        t(new MessageEvent("message", {
            data: {
                type: "windoidopened"
            }
        }));
        const d = setInterval((() => {
            (null == a ? void 0 : a.closed) && (t(new MessageEvent("message", {
                data: {
                    type: "windoidclosed"
                }
            })), clearInterval(d))
        }), 200);
        return ["beforeunload", "unload", "pagehide"].forEach((e => {
            c.addEventListener(e, l, {
                once: !0
            })
        })), c.addEventListener("message", s), ti[o] = () => {
            ["beforeunload", "unload", "pagehide"].forEach((e => {
                c.removeEventListener(e, l)
            })), c.removeEventListener("message", s), clearInterval(d)
        }, a
    },
    oi = de(null);

function ri() {
    const e = Le(oi);
    if (!e) throw new Error("useShopLogin must be used within a ShopLoginProvider");
    return e
}

function ii() {
    const {
        state: e
    } = ri(), t = Ne((() => !e.consented && !e.matched), [e.consented, e.matched]), n = Ne((() => {
        if (!e.footerPolicy) return null;
        const t = new Map;
        Object.entries(e.footerPolicy.links).forEach((([e, n]) => {
            n && t.set(e, pe(ai, {
                text: n.text,
                url: n.url
            }))
        }));
        const n = Array.from(t.keys());
        if (0 === n.length) return e.footerPolicy.text;
        const o = e.footerPolicy.text.split(new RegExp(`({${n.join("}|{")}})`, "g"));
        return o.forEach(((e, n) => {
            if ("string" == typeof e && e.startsWith("{") && e.endsWith("}")) {
                const r = e.replace("{", "").replace("}", ""),
                    i = t.get(r);
                i && (o[n] = i)
            }
        })), o
    }), [e.footerPolicy]);
    return e.loaded || "card" !== e.localPresentationMode ? t ? pe("span", {
        className: ir("block w-full text-center text-caption data-hidden_invisible", "dark" === e.parentTheme ? "text-grayscale-l1" : "text-grayscale-d0"),
        "data-testid": "footer-policy",
        "data-visible": t,
        children: n
    }) : null : pe("div", {
        className: "flex flex-col items-center",
        "data-testid": "footer-policy-skeleton",
        children: [pe("div", {
            className: "my-0.5 h-3 w-full animate-pulse rounded-sm bg-grayscale-l2 motion-reduce_animate-none"
        }), pe("div", {
            className: "my-0.5 h-3 w-44 animate-pulse rounded-sm bg-grayscale-l2 motion-reduce_animate-none"
        })]
    })
}

function ai({
    text: e,
    url: t
}) {
    return pe("a", {
        className: "m-0 inline cursor-pointer appearance-none border-none bg-none p-0 underline hover_opacity-70 focus_opacity-70 active_opacity-70",
        href: t,
        target: "_blank",
        rel: "noopener noreferrer",
        children: e
    })
}

function si({
    className: e,
    color: t,
    processing: n = !1
}) {
    return pe("div", {
        className: ir("pointer-events-none absolute inset-0 z-50 flex items-center justify-center rounded-login-button opacity-100 data-hidden_opacity-0", e),
        "data-testid": "shop-login-spinner",
        "data-visible": n,
        children: pe("svg", {
            className: ir("purple" === t ? "text-purple-primary" : "text-white"),
            "data-testid": "shop-login-spinner-svg",
            fill: "none",
            height: 16,
            viewBox: "0 0 52 58",
            width: 16,
            xmlns: "http://www.w3.org/2000/svg",
            children: pe("path", {
                className: "animate-reveal will-change-transform stroke-dasharray-reveal stroke-dashoffset-reveal",
                d: "M3 13C5 11.75 10.4968 6.92307 21.5 6.4999C34.5 5.99993 42 13 45 23C48.3 34 42.9211 48.1335 30.5 51C17.5 54 6.6 46 6 37C5.46667 29 10.5 25 14 23",
                stroke: "currentColor",
                strokeWidth: 14
            })
        })
    })
}
const li = Ge((({
    ariaLabel: e,
    children: t,
    onClick: n,
    visible: o = !0
}, r) => {
    const {
        state: i
    } = ri();
    return pe("div", {
        className: ir("relative", !o && "invisible hidden"),
        "data-testid": "login-button-container",
        children: [pe($r, {
            "aria-label": e,
            buttonClassName: ir("dark" === i.parentTheme && "shadow-sm", i.processing && "pointer-events-none"),
            className: "p-shop-login",
            "data-testid": "login-button",
            bordered: "dark" === i.parentTheme,
            fullWidth: !0,
            onClick: () => {
                i.processing || null == n || n()
            },
            ref: r,
            children: t
        }), pe(si, {
            className: "bg-purple-primary",
            color: "white",
            processing: i.processing
        })]
    })
}));
li.displayName = "LoginButton";
const ci = Ge((({
    ariaLabel: e,
    children: t,
    onClick: n
}, o) => {
    const r = Te(null),
        i = Te(null),
        a = Te(null),
        {
            state: s
        } = ri(),
        [l, c] = Me(void 0),
        [d, u] = Me(!1),
        p = Te(s.localPresentationMode);
    Oe((() => {
        const e = i.current;
        if (!e || "card" !== s.localPresentationMode) return;
        const t = new ResizeObserver((e => {
            const t = e[0];
            t && c(t.target.offsetHeight)
        }));
        return t.observe(e), () => t.disconnect()
    }), [s.localPresentationMode, s.footerPolicy]), Ce((() => {
        const e = r.current;
        if (!e) return;
        const t = e => {
                "opacity" === e.propertyName && u(!0)
            },
            n = e => {
                var t;
                "opacity" === e.propertyName && (u(!1), "button" === p.current && "card" === s.localPresentationMode && (null === (t = a.current) || void 0 === t || t.focus()))
            };
        return e.addEventListener("transitionstart", t), e.addEventListener("transitionend", n), () => {
            null == e || e.removeEventListener("transitionstart", t), null == e || e.removeEventListener("transitionend", n)
        }
    }), [s.localPresentationMode]), Ie(o, (() => ({
        focus: () => {
            var e;
            null === (e = a.current) || void 0 === e || e.focus()
        }
    })), []);
    const h = "button" === s.localPresentationMode ? 0 : l;
    return pe("div", {
        className: ir("relative block transition-all ease-out motion-reduce_transition-none", "button" === s.localPresentationMode ? "invisible opacity-0 duration-300" : "opacity-100 duration-400", d && "overflow-hidden"),
        "data-testid": "card-content",
        ref: r,
        style: {
            height: void 0 === h ? "auto" : `${h}px`
        },
        children: pe("div", {
            className: "relative flex w-full flex-col space-y-3 pt-3",
            ref: i,
            children: [pe(li, {
                ariaLabel: e,
                onClick: n,
                ref: a,
                children: t
            }), pe(ii, {})]
        })
    })
}));

function di() {
    var e;
    const t = Te(null),
        {
            state: n
        } = ri(),
        o = "button" === n.localPresentationMode;
    return pe("div", {
        className: "flex-shrink-0 opacity-100 data-hidden_opacity-0",
        "data-testid": "animated-shop-logo",
        "data-visible": !n.processing,
        children: pe("div", {
            className: "group relative h-4 flex-shrink-0 overflow-hidden transition-all duration-300 ease-out motion-reduce_transition-none",
            "data-testid": "shop-logo-width-aware-container",
            "data-visible": o,
            style: {
                "--shop-logo-container-width": `${null===(e=t.current)||void 0===e?void 0:e.offsetWidth}px`,
                width: o ? "var(--shop-logo-container-width)" : "0px"
            },
            children: pe("div", {
                className: "aspect-branded-button-icon h-4 translate-x-0 opacity-100 transition-all duration-300 group-data-hidden_translate-x-full group-data-hidden_opacity-0 motion-reduce_transition-opacity",
                "data-testid": "shop-logo-container",
                ref: t,
                children: pe(Ur, {
                    className: "h-4 text-purple-primary"
                })
            })
        })
    })
}
const ui = Ge((({
    src: t,
    storefrontOrigin: n
}, o) => {
    const {
        leaveBreadcrumb: r,
        notify: i
    } = wt(), a = ur(), {
        clearLoadTimeout: s,
        initLoadTimeout: l
    } = yr(), {
        recordCounter: c
    } = Mt(), {
        dispatch: d,
        state: u
    } = ri(), p = Te(null), {
        loaded: h,
        localPresentationMode: f,
        processing: m
    } = u, v = Ae((() => {
        kr({
            iframe: p.current,
            src: t
        })
    }), [t]), {
        destroy: g,
        waitForMessage: _
    } = vr({
        includeCore: !0,
        onError: t => {
            const {
                message: n,
                code: o
            } = t;
            e(o, n) ? (r("shop login iframe error", {
                code: o,
                message: n
            }, "state"), i(new Mn(n, "ShopLoginIframeError"))) : (c("shop_js_handle_silent_error", {
                attributes: {
                    errorCode: o
                }
            }), r("silent error", {
                code: o
            }, "state")), s()
        },
        onLoaded: ({
            consented: e,
            footerPolicy: t,
            loginHintMatch: n,
            userFound: o
        }) => {
            s(), d({
                payload: {
                    consented: e,
                    footerPolicy: t,
                    loginHintMatch: n,
                    userFound: o
                },
                type: "iframeLoaded"
            })
        },
        onResizeIframe: e => {
            p.current && (p.current.style.maxHeight = `${e.height}px`)
        },
        onShopUserMatched: ({
            userCookieExists: e
        }) => {
            d({
                payload: {
                    userCookieExists: e
                },
                type: "userMatched"
            })
        },
        onShopUserNotMatched: () => {
            a("lookup_end"), a("shop_user_not_matched")
        },
        source: p,
        storefrontOrigin: n
    });
    Ce((() => () => {
        p.current && g()
    }), [g]);
    const b = Ae(((e, t) => y(void 0, void 0, void 0, (function*() {
        var n;
        Boolean(null == t ? void 0 : t.afterLoaded) && !h && (yield _("loaded")), wr({
            contentWindow: null === (n = p.current) || void 0 === n ? void 0 : n.contentWindow,
            event: e
        })
    }))), [h, _]);
    Ie(o, (() => ({
        iframeRef: p,
        postMessage: b,
        reload: v,
        waitForMessage: _
    })), [b, v, _]), Ce((() => {
        l(), r("Iframe url updated", {
            src: t
        }, "state")
    }), [l, r, t]), Ce((() => {
        kr({
            iframe: p.current,
            src: t
        })
    }), [t]);
    return pe("div", {
        className: "pointer-events-none flex w-full flex-grow flex-row items-center justify-start gap-x-1 overflow-hidden",
        children: [pe("div", {
            className: "relative block min-w-0 flex-grow overflow-hidden opacity-100 data-hidden_opacity-0",
            "data-testid": "recognition-iframe-wrapper",
            "data-visible": Ne((() => "button" !== f || !m), [f, m]),
            children: [pe("div", {
                className: "group flex w-full items-center gap-2 opacity-100 data-hidden_absolute data-hidden_inset-0 data-hidden_opacity-0",
                "data-testid": "recognition-iframe-skeleton",
                "data-visible": !h,
                children: [pe("div", {
                    className: "size-8 animate-pulse rounded-max bg-grayscale-l2 ring-1 ring-inset ring-black/5 group-data-hidden_animate-none motion-reduce_animate-none"
                }), pe("div", {
                    className: "flex flex-col",
                    children: [pe("div", {
                        className: "my-0.5 h-[14px] w-16 animate-pulse rounded-sm bg-grayscale-l2 group-data-hidden_animate-none motion-reduce_animate-none"
                    }), pe("div", {
                        className: "my-px h-3 w-37 animate-pulse rounded-sm bg-grayscale-l2 group-data-hidden_animate-none motion-reduce_animate-none"
                    })]
                })]
            }), pe("iframe", {
                className: "relative z-40 max-h-8 w-full overflow-hidden border-none opacity-100 data-hidden_absolute data-hidden_inset-0 data-hidden_opacity-0",
                "data-testid": "recognition-iframe",
                "data-visible": h,
                ref: e => {
                    e && (p.current = e, e.getAttribute("src") || e.setAttribute("src", t))
                },
                scrolling: "no",
                tabIndex: 0
            }), pe("div", {
                className: "absolute inset-y-0 right-0 z-50 w-1 bg-gradient-to-r from-transparent to-white opacity-100 data-hidden_opacity-0",
                "data-visible": "button" === u.localPresentationMode
            })]
        }), "button" === f && pe(si, {
            color: "purple",
            processing: m
        }), pe(di, {})]
    })
}));
ui.displayName = "LoginIframe";
const pi = Ge((({
        ariaLabel: e,
        children: t,
        iframeUrl: n,
        onClick: o,
        visible: r
    }, i) => {
        const a = Te(null),
            s = Te(null),
            l = Te(null),
            {
                state: c,
                flowVersion: d
            } = ri();
        Ce((() => {
            var e;
            const t = e => {
                "Enter" === e.key && "button" === c.localPresentationMode && o()
            };
            null === (e = s.current) || void 0 === e || e.addEventListener("keydown", t);
            const n = s.current;
            return () => {
                null == n || n.removeEventListener("keydown", t)
            }
        }), [o, c.localPresentationMode]);
        const u = "button" === c.localPresentationMode ? {
            onClick: o,
            role: "button",
            tabIndex: 0
        } : {};
        return Ie(i, (() => ({
            focus: () => {
                var e, t;
                "button" === c.localPresentationMode ? null === (e = s.current) || void 0 === e || e.focus() : null === (t = a.current) || void 0 === t || t.focus()
            },
            iframe: l
        })), [c.localPresentationMode]), pe("div", Object.assign({
            "aria-hidden": !r,
            className: ir("relative w-full select-none border transition-all duration-300 ease-out data-hidden_invisible data-hidden_hidden motion-reduce_transition-none", "account_menu" !== d && "backdrop-blur-xl", "button" === c.localPresentationMode ? "rounded-login-button bg-core-idp-social-logins focus_outline-none focus_ring focus_ring-purple-l1 focus-visible_outline-none focus-visible_ring focus-visible_ring-purple-l1" : "rounded-login-card bg-white bg-opacity-5 shadow-card", "button" === c.localPresentationMode && !c.processing && "cursor-pointer hover_opacity-80", "dark" === c.parentTheme ? "border-checkout-branded-dark" : "border-checkout-branded"),
            "data-testid": "login-recognition",
            "data-visible": r
        }, u, {
            ref: s,
            children: pe("div", {
                className: ir("flex flex-col transition-all duration-300 ease-out", "button" === c.localPresentationMode ? "p-shop-login" : "p-4"),
                "data-testid": "login-recognition-content",
                children: [pe(ui, {
                    ref: l,
                    src: n
                }), pe(ci, {
                    ariaLabel: e,
                    onClick: o,
                    ref: a,
                    children: t
                })]
            })
        }))
    })),
    hi = {
        consented: !1,
        cookied: !1,
        dismissed: !1,
        footerPolicy: void 0,
        loaded: !1,
        localPresentationMode: "button",
        loginHint: void 0,
        matched: !1,
        mountedTimestamp: void 0,
        parentTheme: "light",
        processing: !1,
        textVariant: void 0
    };

function fi(e, t) {
    switch (t.type) {
        case "dismiss":
            return Object.assign(Object.assign({}, e), {
                dismissed: !0,
                localPresentationMode: "button"
            });
        case "iframeLoaded":
            return Object.assign(Object.assign({}, e), {
                consented: Boolean(t.payload.consented),
                cookied: t.payload.userFound,
                footerPolicy: t.payload.footerPolicy,
                loaded: !0,
                localPresentationMode: t.payload.presentation,
                matched: Boolean(t.payload.loginHintMatch)
            });
        case "mounted":
            return Object.assign(Object.assign({}, e), {
                mountedTimestamp: Date.now()
            });
        case "resetState":
            return hi;
        case "setLocalPresentationMode":
            return Object.assign(Object.assign({}, e), {
                localPresentationMode: t.payload
            });
        case "setParentTheme":
            return Object.assign(Object.assign({}, e), {
                parentTheme: t.payload.parentTheme
            });
        case "setProcessing":
            return Object.assign(Object.assign({}, e), {
                processing: t.payload
            });
        case "userMatched":
            return Object.assign(Object.assign({}, e), {
                cookied: t.payload.userCookieExists,
                localPresentationMode: t.payload.userCookieExists ? "button" : "card",
                loginHint: void 0,
                matched: !0
            });
        default:
            return e
    }
}

function mi({
    children: e,
    presentationMode: t = "button",
    flowVersion: n,
    textVariant: o
}) {
    const r = ur(),
        {
            analyticsData: i,
            produceMonorailEvent: a,
            trackUserAction: s
        } = St(),
        {
            log: l,
            recordCounter: d,
            recordHistogram: u
        } = Mt(),
        p = Te(!1),
        h = Te(!1),
        f = Ne((() => (e => {
            switch (e) {
                case "account_menu":
                case "customer_accounts":
                case "email_capture":
                case "phone_capture":
                    return e;
                case void 0:
                    return "unspecified";
                default:
                    return "0"
            }
        })(n)), [n]),
        m = Ae((e => {
            const {
                analyticsTraceId: t,
                flowVersion: n
            } = i;
            a({
                event: {
                    schemaId: "shop_identity_presentation_mode_change/1.0",
                    payload: Object.assign({
                        analyticsTraceId: t,
                        flowVersion: n
                    }, e)
                }
            })
        }), [i, a]),
        v = Ae((({
            action: e,
            previousState: t,
            state: n
        }) => {
            switch (e.type) {
                case "iframeLoaded":
                    {
                        const o = Boolean(!e.payload.consented && e.payload.footerPolicy && "card" === n.localPresentationMode);
                        if (r("loaded", {
                                disclaimerVisible: o,
                                presentation: n.localPresentationMode,
                                userFound: e.payload.userFound
                            }), h.current) break;
                        const i = "card" === t.localPresentationMode && "button" === n.localPresentationMode && !e.payload.userFound,
                            a = "button" === t.localPresentationMode && "button" === n.localPresentationMode && e.payload.userFound;
                        if (h.current = !0, n.mountedTimestamp ? u("shop_js_iframe_load_duration", {
                                attributes: {
                                    flowVersion: f
                                },
                                value: Date.now() - n.mountedTimestamp
                            }) : l({
                                body: "ShopLogin: No mounted timestamp was found when tracking iframe load duration",
                                attributes: {
                                    flowVersion: f
                                }
                            }), i) {
                            m({
                                currentMode: "button",
                                previousMode: "card",
                                reason: "user_not_recognized"
                            });
                            break
                        }
                        if (a) {
                            m({
                                currentMode: "button",
                                previousMode: "button",
                                reason: "user_recognized"
                            });
                            break
                        }
                        break
                    }
                case "userMatched":
                    r("shop_user_matched", {
                        presentation: n.localPresentationMode
                    }), r("lookup_end"), m({
                        currentMode: "card",
                        previousMode: "button",
                        reason: "email_matched"
                    });
                    break;
                case "dismiss":
                    "card" === t.localPresentationMode && "button" === n.localPresentationMode && m({
                        currentMode: "button",
                        previousMode: "card",
                        reason: "dismissed"
                    })
            }
        }), [r, f, l, u, m]),
        g = Ae(((e, n) => {
            const o = Object.assign({}, e);
            if ("iframeLoaded" === n.type) {
                const r = function({
                        dismissed: e,
                        originalPresentationMode: t,
                        userMatched: n,
                        userRecognized: o
                    }) {
                        return n && !e ? "card" : "button" === t ? "button" : o && !e ? "card" : "button"
                    }({
                        dismissed: e.dismissed,
                        originalPresentationMode: t,
                        userRecognized: n.payload.userFound
                    }),
                    i = Object.assign(Object.assign({}, n), {
                        payload: Object.assign(Object.assign({}, n.payload), {
                            presentation: r
                        })
                    }),
                    a = fi(e, i);
                return v({
                    action: i,
                    previousState: o,
                    state: a
                }), a
            }
            const r = fi(e, n);
            return v({
                action: n,
                previousState: o,
                state: r
            }), r
        }), [t, v]),
        [_, y] = je(g, function({
            presentationMode: e = "button",
            textVariant: t
        }) {
            var n;
            let o;
            try {
                o = null !== (n = new URL(c.location.href).searchParams.get("login_hint")) && void 0 !== n ? n : void 0
            } catch (e) {
                o = void 0
            }
            return Object.assign(Object.assign({}, hi), {
                localPresentationMode: e,
                loginHint: o,
                textVariant: t
            })
        }({
            presentationMode: t,
            textVariant: o
        }));
    Ce((() => {
        y({
            type: "mounted"
        }), r("mounted")
    }), [y, r]), Ce((() => {
        p.current || (p.current = !0, d("shop_js_feature_initialized", {
            attributes: {
                flowVersion: f
            }
        }))
    }), [f, d]);
    const b = Ae((e => {
            s({
                userAction: e
            }), d("shop_js_user_action", {
                attributes: {
                    action: e,
                    flowVersion: f
                }
            })
        }), [f, d, s]),
        w = Ne((() => ({
            dispatch: y,
            flowVersion: f,
            state: _,
            trackUserAction: b
        })), [y, f, _, b]);
    return pe(oi.Provider, {
        value: w,
        children: e
    })
}

function vi(e, t) {
    const n = yi(e),
        o = yi(t);
    return (Math.max(n, o) + .05) / (Math.min(n, o) + .05)
}

function gi(e) {
    let t = 0,
        n = 0,
        o = 0;
    return 4 === e.length ? (t = Number(`0x${e[1]}${e[1]}`), n = Number(`0x${e[2]}${e[2]}`), o = Number(`0x${e[3]}${e[3]}`)) : 7 === e.length && (t = Number(`0x${e[1]}${e[2]}`), n = Number(`0x${e[3]}${e[4]}`), o = Number(`0x${e[5]}${e[6]}`)), [t, n, o]
}

function _i(e) {
    var t;
    if (!e) return "#ffffff";
    const o = null === (t = c.getComputedStyle(e).getPropertyValue("--color-background")) || void 0 === t ? void 0 : t.trim();
    if (o) return o;
    for (const t of function*(e) {
            let t = e;
            for (; t;) {
                if (t.parentElement) t = t.parentElement;
                else if (t instanceof ShadowRoot) t = t.host;
                else {
                    if (!(t instanceof Element)) break; {
                        const e = t.getRootNode();
                        if (!(e instanceof ShadowRoot)) break;
                        t = e.host
                    }
                }
                if (yield t, t === n.body) break
            }
        }(e)) {
        const e = c.getComputedStyle(t).getPropertyValue("background-color");
        if (e && "rgba(0, 0, 0, 0)" !== e) return e
    }
    return "#ffffff"
}

function yi(e) {
    const t = [e[0], e[1], e[2]].map((function(e) {
        const t = e / 255;
        return t <= .03928 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4)
    }));
    return .2126 * t[0] + .7152 * t[1] + .0722 * t[2]
}

function bi(e) {
    const t = e.match(/\d+/g) || [],
        [n = 0, o = 0, r = 0] = t.map((e => Number(e)));
    return [n, o, r]
}

function wi(e) {
    return e <= .04045 ? e / 12.92 : Math.pow((e + .055) / 1.055, 2.4)
}

function xi(e) {
    let t;
    if (e.startsWith("#") && (t = gi(e)), e.startsWith("rgb(") && (t = bi(e)), !t) return !1;
    const n = function(e) {
        return e <= 216 / 24389 ? e * (24389 / 27) : 116 * Math.pow(e, 1 / 3) - 16
    }(function(e) {
        return .2126 * wi(e[0]) + .7152 * wi(e[1]) + .0722 * wi(e[2])
    }([t[0] / 255, t[1] / 255, t[2] / 255]));
    return n < 50
}

function ki(e) {
    const {
        recordCounter: t
    } = Mt();
    return Ne((() => {
        try {
            if (e && function(e) {
                    const t = new c.URL(e);
                    if (("localhost" === t.hostname || "127.0.0.1" === t.hostname) && "https:" !== t.protocol) throw new Error("using_localhost");
                    if ("https:" !== t.protocol) throw new Error("not_using_https");
                    if ("/" !== t.pathname) throw new Error("has_path");
                    if (t.hash) throw new Error("has_hash");
                    if (t.search) throw new Error("has_search");
                    return !0
                }(e)) return e
        } catch (e) {
            e instanceof Error && t("shop_js_invalid_storefront_origin", {
                attributes: {
                    error: e
                }
            })
        }
        return c.location.origin
    }), [e, t])
}

function Ei({
    source: e
}) {
    const {
        notify: t
    } = wt(), {
        recordCounter: n
    } = Mt(), o = Ae((e => {
        "completed" === e.type && (n("shop_js_cart_sync_finalize_fetch"), function({
            onError: e,
            onResolve: t
        }) {
            fetch(`${c.location.origin}/services/login_with_shop/buyer/finalize`).then((e => t(e.status))).catch((t => e(t)))
        }({
            onError: e => {
                const o = function(e) {
                    if (e instanceof Error) return e;
                    switch (typeof e) {
                        case "string":
                            return new Error(e);
                        case "object":
                            return "message" in e ? new Error(e.message) : new Error(JSON.stringify(e));
                        default:
                            return new Error(String(e))
                    }
                }(e);
                n("shop_js_cart_sync_finalize_error"), t(o)
            },
            onResolve: e => {
                n("shop_js_cart_sync_finalize_resolve", {
                    attributes: {
                        status: e
                    }
                })
            }
        }))
    }), [t, n]), {
        destroy: r
    } = mr({
        allowedOrigins: [cr, c.location.origin],
        handler: o,
        source: e
    });
    return {
        destroy: r
    }
}
const Si = ({
    ctx: e
}) => {
    const {
        log: t
    } = Mt(), n = Te(null), {
        instanceId: o
    } = Ct(), {
        destroy: r
    } = Ei({
        source: n
    });
    Ce((() => {
        const e = n.current;
        return () => {
            e && r()
        }
    }), [r]);
    const i = Ne((() => {
        var n, r;
        const i = c.location.origin,
            a = null === (n = c.Shopify) || void 0 === n ? void 0 : n.shop;
        if (!a) return t({
            body: "Missing Shopify domain from window.Shopify",
            attributes: {
                analyticsTraceId: o,
                domain: c.location.origin
            }
        }), "";
        if (null === (r = c.Shopify) || void 0 === r ? void 0 : r.designMode) return "";
        const s = new URLSearchParams({
            analytics_trace_id: o,
            target_origin: i,
            client_handle: a
        });
        e && s.set("ctx", e);
        return `${cr}/pay/hop?${s}`
    }), [e, o, t]);
    return pe("iframe", {
        "aria-hidden": "true",
        className: "hidden",
        "data-testid": "shop-cart-sync-iframe",
        ref: n,
        src: i,
        tabIndex: -1,
        title: "Shop Pay cart sync"
    })
};
or((e => {
    var {
        element: t
    } = e, n = _(e, ["element"]);
    return pe(qo, {
        element: t,
        featureName: "ShopCartSync",
        children: pe(Si, Object.assign({}, n))
    })
}), {
    name: "shop-cart-sync",
    props: {
        ctx: "string"
    },
    shadow: "open"
});
const Pi = e => {
    const t = e || c.location.origin;
    try {
        return new c.URL(t).hostname
    } catch (e) {
        return console.error(`[Shop Pay] Store URL (${t}) is not valid`, e), null
    }
};

function Mi({
    channel: e,
    paymentOption: t,
    source: n,
    sourceToken: o,
    storeUrl: r,
    variants: i
}) {
    const a = Pi(r);
    if (!a) return "#";
    let s = new c.URL(`https://${a}/checkout`);
    if (i) {
        const e = i.split(",").map((e => {
                const [t, n] = e.split(":"), o = n ? Number(n) : 1;
                return {
                    id: Number(t),
                    quantity: isNaN(o) ? 1 : o
                }
            })),
            t = e.map((e => `${e.id}:${e.quantity}`)).join(",");
        s = new c.URL(`https://${a}/cart/${t}`)
    }
    const l = new URLSearchParams(s.search);
    return l.append("payment", t || "shop_pay"), n && l.append("source", n), o && l.append("source_token", o), e && l.append("channel", e), `${s.href}?${l}`
}

function ji(e, t) {
    Boolean(c.customElements) && (c.Shopify || (c.Shopify = {}), c.Shopify.SignInWithShop || (c.Shopify.SignInWithShop = {}), c.Shopify.SignInWithShop[e] = t)
}

function Ci() {
    var e;
    const t = null === (e = n.querySelector("script#shop-js-features")) || void 0 === e ? void 0 : e.innerHTML;
    return t ? JSON.parse(t) : {}
}
const Oi = new Error("Operation aborted");

function Ti(e) {
    return y(this, arguments, void 0, (function*(e, t = {}, {
        maxRetries: n = 3,
        retryDelay: o = 1e3,
        signal: r
    } = {}) {
        try {
            if (null == r ? void 0 : r.aborted) return Promise.reject(Oi);
            const n = yield fetch(e, t);
            if (!n.ok) throw new Error(`HTTP error! status: ${n.status}`);
            return n
        } catch (i) {
            if (null == r ? void 0 : r.aborted) return Promise.reject(Oi);
            if (n - 1 > 0) return yield new Promise((e => setTimeout(e, o))), (null == r ? void 0 : r.aborted) ? Promise.reject(Oi) : Ti(e, t, {
                maxRetries: n - 1,
                retryDelay: o,
                signal: r
            });
            throw i
        }
    }))
}
class Ii extends Error {
    constructor() {
        super("FedCM is not supported")
    }
}
class Ni extends Error {
    constructor() {
        super("FedCM was cancelled")
    }
}
const Ai = e => y(void 0, void 0, void 0, (function*() {
    if (!("IdentityCredential" in c)) throw new Ii;
    const {
        mediation: t = "optional",
        analyticsTraceId: n,
        monorailTracker: o,
        signal: r
    } = e, i = yield function(e) {
        return y(this, void 0, void 0, (function*() {
            let t = "/services/login_with_shop/fedcm/provider";
            e && (t += `?analytics_trace_id=${encodeURIComponent(e)}`);
            try {
                const e = yield Ti(t, {
                    method: "GET"
                }, {
                    maxRetries: 5,
                    retryDelay: 1e3
                }), n = yield e.json();
                return {
                    configURL: n.configURL,
                    clientId: n.clientId,
                    state: n.state,
                    nonce: n.nonce,
                    params: {
                        nonce: n.nonce
                    }
                }
            } catch (e) {
                throw new Mn("Failed to fetch FedCM Provider", "FetchFedCMProviderError")
            }
        }))
    }(n);
    if (!i) return;
    const a = yield function(e, t, n) {
        return Bt.credentials.get({
            identity: {
                providers: [t]
            },
            mediation: e,
            signal: n
        })
    }(t, i, r);
    if (!a) throw null == o || o.trackUserAction({
        userAction: "FEDCM_CANCELLED"
    }), new Ni;
    return function(e, t, n) {
        return y(this, void 0, void 0, (function*() {
            try {
                const o = yield Ti("/services/login_with_shop/fedcm/callback", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: new URLSearchParams({
                        raw_id_token: e,
                        state: t
                    }).toString()
                }, {
                    maxRetries: 5,
                    retryDelay: 1e3
                });
                return null == n || n.trackUserAction({
                    userAction: "FEDCM_COMPLETED"
                }), o
            } catch (e) {
                throw new Mn("Failed to fetch FedCM Callback", "FetchFedCMPCallbackError")
            }
        }))
    }(null == a ? void 0 : a.token, i.state, o)
}));

function Li({
    onElementFound: e,
    selector: t
}) {
    const o = new WeakSet,
        r = new MutationObserver((e => {
            let t = !1;
            for (const n of e)
                if (n.addedNodes.length > 0) {
                    t = !0;
                    break
                }
            t && i()
        }));

    function i() {
        n.querySelectorAll(t).forEach((t => {
            o.has(t) || (e(t), o.add(t))
        }))
    }
    return function() {
        y(this, void 0, void 0, (function*() {
            yield function() {
                if (n.body) return Promise.resolve();
                return new Promise((e => {
                    c.addEventListener("DOMContentLoaded", (() => e()))
                }))
            }(), i(), r.observe(n.body || n.documentElement, {
                childList: !0,
                subtree: !0
            })
        }))
    }(), r
}

function Ri({
    onFallback: e,
    onVisible: t
}) {
    const n = new IntersectionObserver((r => {
        for (const i of r) {
            const {
                isIntersecting: r,
                target: a
            } = i;
            r && (o(a) ? t(a) : e(a), n.unobserve(a))
        }
    }), {
        threshold: 1
    });

    function o(e) {
        let t = e;
        for (; t;) {
            if (!["", "1"].includes(getComputedStyle(t).opacity)) return !1;
            t = t.parentElement
        }
        return !0
    }
    return n
}
var zi, Di;
class Ui {
    constructor(e, t) {
        zi.set(this, void 0), Di.set(this, void 0), e && (w(this, zi, e, "f"), w(this, Di, (e => {
            t(e.target.value)
        }), "f"), b(this, zi, "f").addEventListener("input", b(this, Di, "f")))
    }
    destroy() {
        b(this, zi, "f") && b(this, Di, "f") && b(this, zi, "f").removeEventListener("input", b(this, Di, "f"))
    }
}
zi = new WeakMap, Di = new WeakMap;
const Fi = "shop-toast-manager";

function $i(e) {
    let t = n.querySelector(Fi);
    t || (t = n.createElement(Fi), n.body.appendChild(t)), customElements.whenDefined(Fi).then((() => {
        t.renderToast(e)
    })).catch((() => {}))
}
ji("renderToast", $i);
export {
    it as $, Te as A, Cn as B, or as C, Ge as D, _ as E, Mr as F, Jo as G, Hr as H, Cr as I, Zr as J, Zo as K, Yr as L, g as M, v as N, t as O, kt as P, Gr as Q, qo as R, rr as S, Ne as T, Qr as U, ni as V, Fn as W, ei as X, Br as Y, $r as Z, y as _, uo as a, Ar as a0, f as a1, ri as a2, hr as a3, Jr as a4, Xo as a5, Wr as a6, cr as a7, qr as a8, mi as a9, Ni as aA, u as aB, Pn as aC, ki as aD, Xr as aE, de as aF, Le as aG, gi as aH, bi as aI, vi as aJ, lr as aK, Fr as aL, Sn as aM, Mi as aN, Pi as aO, Vr as aP, _i as aa, xi as ab, li as ac, pi as ad, jr as ae, s as af, Kr as ag, ji as ah, dr as ai, kn as aj, pr as ak, xr as al, hn as am, vn as an, Bo as ao, Ro as ap, Bt as aq, tr as ar, Ci as as, Ai as at, Ri as au, Li as av, Ui as aw, p as ax, Lr as ay, Ii as az, Ct as b, n as c, Me as d, Rr as e, Nr as f, ir as g, pe as h, c as i, Sr as j, B as k, wt as l, ur as m, yr as n, St as o, Mt as p, Ae as q, br as r, vr as s, Ie as t, ar as u, Ur as v, kr as w, Mn as x, Ce as y, wr as z
};
//# sourceMappingURL=chunk.common_QsV4w3tJ.en.esm.js.map