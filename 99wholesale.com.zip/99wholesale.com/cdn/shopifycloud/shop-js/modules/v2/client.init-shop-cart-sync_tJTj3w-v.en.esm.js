import {
    _ as t,
    aq as e,
    aj as n,
    c as r,
    ar as i,
    ah as o
} from "./chunk.common_QsV4w3tJ.en.esm.js";
import "./chunk.modal_B1su6BWj.en.esm.js";

function s() {
    return t(this, void 0, void 0, (function*() {
        if (c()) return !1;
        if ("userAgentData" in e && e.userAgentData) try {
            const t = e.userAgentData.brands || [];
            return t.some((({
                brand: t
            }) => /chrome|edge|chromium/i.test(t)))
        } catch (t) {}
        return !(void 0 === e || !e.userAgent) && function() {
            const t = e.userAgent;
            if (c()) return !1;
            const n = /(chrome|crios)\/([\w.]+)/i.test(t),
                r = /(edg|edge|edga|edgios)\/([\w.]+)/i.test(t),
                i = /(opr|opera|brave|vivaldi)\/([\w.]+)/i.test(t);
            return (n || r) && !i
        }()
    }))
}

function c() {
    const t = e.userAgent;
    return /iphone|ipad|ipod|crios|edgios/i.test(t)
}

function a(e) {
    return t(this, void 0, void 0, (function*() {
        const t = new n("initShopCartSync");
        try {
            let t, n = !1;
            if (!(yield s())) return;
            t = r.querySelector("shop-cart-sync"), t || (t = i("shop-cart-sync"), n = !0), t.setAttribute("experiments", JSON.stringify((null == e ? void 0 : e.experiments) || {})), (null == e ? void 0 : e.ctx) && t.setAttribute("ctx", e.ctx), n && r.body.appendChild(t)
        } catch (e) {
            e instanceof Error && t.notify(e)
        }
    }))
}
o("initShopCartSync", a);
//# sourceMappingURL=client.init-shop-cart-sync_tJTj3w-v.en.esm.js.map