{
    "token": "hWN9er4XoW7IBmPZWwLzpiHU?key=14539003acbb69a7eac5c2bc120ecc6e",
    "note": "",
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "INR",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "discount_codes": []
}