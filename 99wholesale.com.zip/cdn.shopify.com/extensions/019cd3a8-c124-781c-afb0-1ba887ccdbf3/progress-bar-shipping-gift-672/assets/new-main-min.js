let render = !0,
    freegiftpopup = !1,
    renderingdelay = !1;
var final_cart_total_upsell, final_cart_quantity_upsell, amrosia_custom_quantity = "",
    current_currency_price_kai = Number(Shopify.currency.rate);

function closeMessage() {
    const e = document.getElementById("bmsmstickyMessage");
    e.style.display = "none", e.style.visibility = "hidden"
}

function toggleScrollIndicator() {
    const e = document.querySelector(".bmsm-gift-popup-content"),
        t = document.querySelector(".scroll-indicator");
    requestAnimationFrame((() => {
        const o = e.scrollHeight > e.clientHeight;
        t.style.display = o ? "block" : "none"
    }))
}
const defaultGiftPopupStyles = {
    popupHeaderText: "Choose any 1 free gift from below",
    popupHeaderFontsize: 17,
    popupImageWidth: "90%",
    popupImageWidthMobile: "90%",
    popupImageHeight: "250px",
    popupImageHeightMobile: "210px",
    selectButtonText: "Select Gift",
    selectButtonTextSize: 14,
    selectButtonColor: {
        r: 0,
        g: 122,
        b: 255
    },
    selectButtonTextColor: {
        r: 255,
        g: 255,
        b: 255,
        a: 1
    },
    closeButtonText: "Close",
    closeButtonColor: {
        r: 51,
        g: 51,
        b: 51,
        a: 1
    },
    closeButtonTextColor: {
        r: 255,
        g: 255,
        b: 255,
        a: 1
    },
    popupWidth: "80%",
    popupWidthMobile: "90%"
};

function getGiftPopupStyles() {
    try {
        const t = (window.activeMetaobjects || []).find((e => e && e.placementStyles && e.placementStyles.giftPopup));
        var e = t && t.placementStyles && t.placementStyles.giftPopup || {};
        "300px" == e.popupImageWidth && (e = defaultGiftPopupStyles);
        return { ...defaultGiftPopupStyles,
            ...e,
            selectButtonColor: e.selectButtonColor || defaultGiftPopupStyles.selectButtonColor,
            selectButtonTextColor: e.selectButtonTextColor || defaultGiftPopupStyles.selectButtonTextColor,
            closeButtonColor: e.closeButtonColor || defaultGiftPopupStyles.closeButtonColor,
            closeButtonTextColor: e.closeButtonTextColor || defaultGiftPopupStyles.closeButtonTextColor
        }
    } catch (e) {
        return defaultGiftPopupStyles
    }
}

function showGiftPopup(e) {
    var t;
    t = "bpikvw-a1.myshopify.com" == window.Shopify.shop ? JSON.parse(e) : JSON.parse(decodeURIComponent(e));
    const o = getGiftPopupStyles(),
        i = "function" == typeof isMobileDeviceKai ? isMobileDeviceKai() : window.innerWidth <= 767,
        n = document.getElementById("bmsm-gift-popup"),
        s = document.querySelector(".bmsm-gift-popup-content");
    if (s) {
        const e = i ? o.popupWidthMobile : o.popupWidth;
        e && (s.style.width = e)
    }
    if ("iymt0v-hw.myshopify.com" !== window.Shopify.shop || isMobileDeviceKai() || (s.style.width = "60%"), "danielle-guizio-ny.myshopify.com" != window.Shopify.shop && "flex" === n.style.display) return;
    const r = document.getElementById("gift-options");
    r.innerHTML = "", r.className = "bmsm-gift-options";
    const l = t.reduce(((e, t) => {
        const o = `${t.discount_id}_${t.tier_id}_${t.tier_minSpend}`;
        return e[o] || (e[o] = {
            discount_id: t.discount_id,
            tier_id: t.tier_id,
            tier_minSpend: t.tier_minSpend,
            noofgifts: t.noofgifts || 1,
            products: {},
            giftpopup: t.giftpopup
        }), e[o].products[t.product_id] || (e[o].products[t.product_id] = {
            product_name: t.product_name,
            featured_image: t.featured_image,
            product_id: t.product_id,
            variants: []
        }), e[o].products[t.product_id].variants.push(t), e
    }), {});
    if (Object.values(l).forEach((e => {
            const t = document.createElement("div");
            t.className = "bmsm-gift-group-header";
            const l = o.popupHeaderFontsize || 17,
                a = (o.popupHeaderText || (null !== e.giftpopup && void 0 !== e.giftpopup ? e.giftpopup : "Choose any {noofgifts} gift from below")).replace("{noofgifts}", e.noofgifts);
            t.innerHTML = `<h3 style="font-size:${l}px;">${a}</h3>`, "d1336f-2.myshopify.com" == window.Shopify.shop && (t.innerHTML = "<h3>Containers available at special price for you</h3>"), "b6f6ed-34.myshopify.com" == window.Shopify.shop && (t.innerHTML = '<h5 style="color:black;margin-top:20px;" >Elige un regalo de la siguiente lista.</h5>'), "wkn7z2-1x.myshopify.com" == window.Shopify.shop && (t.innerHTML = null !== e.giftpopup && void 0 !== e.giftpopup ? `<h3 style="font-family:var(--heading-font-family);" >${e.giftpopup.replace("{noofgifts}",e.noofgifts)}</h3>` : `<h3 style="font-family:var(--heading-font-family);" >Choose any ${e.noofgifts} gift from below</h3>`), "incenseaustralia.myshopify.com" == window.Shopify.shop && (t.innerHTML = null !== e.giftpopup && void 0 !== e.giftpopup ? `<h3 style="color:black;">${e.giftpopup.replace("{noofgifts}",e.noofgifts)}</h3>` : `<h3 style="color:black;" >Choose any ${e.noofgifts} gift from below</h3>`), "peachade.myshopify.com" == window.Shopify.shop && (t.innerHTML = null !== e.giftpopup && void 0 !== e.giftpopup ? `<h3 style="color:black;margin-top:20px;">${e.giftpopup.replace("{noofgifts}",e.noofgifts)}</h4>` : `<h3 style="color:black;margin-top:20px;">Choose any ${e.noofgifts} gift from below</h4>`), "ripit-grips.myshopify.com" == window.Shopify.shop && (t.innerHTML = null !== e.giftpopup && void 0 !== e.giftpopup ? `<h4 style="color:black;margin-top:10px;">${e.giftpopup.replace("{noofgifts}",e.noofgifts)}</h4>` : `<h4 style="color:black;margin-top:10px;">Choose any ${e.noofgifts} gift from below</h4>`), "thetotelibrary.myshopify.com" == window.Shopify.shop && (t.innerHTML = null !== e.giftpopup && void 0 !== e.giftpopup ? `<h5 style="color:black;margin-top:20px;">${e.giftpopup.replace("{noofgifts}",e.noofgifts)}</h4>` : `<h5 style="color:black;margin-top:20px;">Choose any ${e.noofgifts} gift from below</h4>`), r.appendChild(t);
            const c = document.createElement("div");
            c.className = "bmsm-gift-group", c.style.display = "flex", c.style.flexWrap = "wrap", c.style.gap = "20px", "doukissa-nomikou.myshopify.com" === window.Shopify.shop && isMobileDeviceKai() && (c.style.flexWrap = "nowrap", c.style.overflowX = "auto", s.style.width = "100%", c.style.height = "400px"), "doukissa-nomikou.myshopify.com" === window.Shopify.shop && (s.style.setProperty("height", "auto", "important"), n.style.setProperty("height", "auto", "important")), Object.values(e.products).forEach((e => {
                const t = document.createElement("div");
                t.className = "bmsm-gift-card", "doukissa-nomikou.myshopify.com" === window.Shopify.shop && isMobileDeviceKai() && (t.style.width = "150px"), "iymt0v-hw.myshopify.com" !== window.Shopify.shop || isMobileDeviceKai() || (t.style.width = "240px"), "iymt0v-hw.myshopify.com" === window.Shopify.shop && isMobileDeviceKai() && (t.style.width = "60%");
                let i = e.product_name.replace(/[^a-zA-Z0-9\s]/g, "").replace(/\s+/g, "-").replace(/^-+/, "").toLowerCase();
                var n = e.product_id.match(/(\d+)$/)[1];
                i = /^[0-9]/.test(i) ? `id-${i}` : i;
                let s = o.selectButtonText || "Select",
                    r = o.closeButtonText || "Close";
                "d06409-1b.myshopify.com" === window.Shopify.shop ? (s = "Auswählen", r = "Schließen") : "7ch3mm-ys.myshopify.com" === window.Shopify.shop ? window.location.href.includes("/de") ? (s = "Auswählen", r = "Schließen") : (s = "Choisir", r = "Fermer") : "iymt0v-hw.myshopify.com" === window.Shopify.shop && (s = "Auswählen", r = "Schließen");
                const l = document.querySelector(".bmsm-gift-popup-close-btn");
                l && (l.innerText = r, o.closeButtonColor && (l.style.backgroundColor = applyColor(o.closeButtonColor)), o.closeButtonTextColor && (l.style.color = applyColor(o.closeButtonTextColor)));
                const a = e.featured_image,
                    p = a.startsWith("https://cdn.shopify.com") ? a : `/cdn/shop/${a}`;
                if ("pie-me-cafe.myshopify.com" === window.Shopify.shop || "b6f6ed-34.myshopify.com" == window.Shopify.shop) t.innerHTML = `\n    <div style="display:flex;width:100%;height:100%;align-items:flex-start;\n                padding:12px;border-radius:6px;font-family:sans-serif;max-width:600px;">\n      \n     \n      <img src="${p}" alt="${e.product_name}" \n           style="width:60px;height:auto;margin-right:12px;border-radius:4px;flex-shrink:0;">\n      \n     \n      <div style="display:flex;flex-direction:column;flex:1;">\n        \n     \n        <p style="font-size:12px;font-weight:600;margin:0 0 4px 0;">\n          Gratis ${e.product_name}\n        </p>\n        \n      \n        <div style="margin-bottom:8px;">\n          <span style="font-size:14px;color:#666;text-decoration:line-through;margin-right:6px;">\n             ${formatMoney1(e.variants[0].price,2)}\n          </span>\n          <span style="font-size:14px;font-weight:bold;color:#000;">\n            gratis\n          </span>\n        </div>\n        \n        \x3c!-- Button at bottom --\x3e\n        <button id="${i}-select-btn" \n                style="align-self:flex-start;background-color:#e74c3c;color:#fff;\n                       border:none;padding:6px 12px;border-radius:4px;cursor:pointer;\n                       font-size:14px;">\n          seleccionar\n        </button>\n        \n      </div>\n    </div>\n  `;
                else {
                    let o = "";
                    if (1 === e.variants.length && "Default Title" === e.variants[0].variant_name) {
                        const t = e.variants[0];
                        o = "evolution-wheels-2.myshopify.com" === window.Shopify.shop ? "" : "d1336f-2.myshopify.com" === window.Shopify.shop && t.compare_at_price > 0 ? `<div class="bmsm-gift-price">${formatMoney1(t.compare_at_price,2)}</div>` : "doukissa-nomikou.myshopify.com" === window.Shopify.shop ? `<div class="bmsm-gift-price">${formatMoney1(0,2)}</div>` : "incenseaustralia.myshopify.com" === window.Shopify.shop ? `\n              <div class="bmsm-gift-price" style="color:black;">\n                ${formatMoney1(0,2)}\n                <span style="text-decoration: line-through; margin-left: 6px;">\n                  ${formatMoney1(t.price,2)}\n                </span>\n              </div>\n          ` : "thetotelibrary.myshopify.com" == window.Shopify.shop ? `\n \n              <div class="bmsm-gift-price" style="color:black;">\n              \n                <span style="text-decoration: line-through; margin-left: 6px;">\n                  ${formatMoney1(t.price,2)}\n                </span>\n                 <span style="color:green; margin-left: 6px;">\n                  ${formatMoney1(0,2)}\n                   </span>\n                \n              </div>\n          ` : `<div class="bmsm-gift-price">${formatMoney1(t.price,2)}</div>`
                    } else {
                        const t = e.variants.map((e => {
                            const t = e.variant_featured_image,
                                o = t.startsWith("https://cdn.shopify.com") ? t : `/cdn/shop/${t}`;
                            let i;
                            return i = "7ch3mm-ys.myshopify.com" === window.Shopify.shop ? window.location.href.includes("/de") ? `${e.variant_name} - kostenlos` : `${e.variant_name} - gratuit` : "evolution-wheels-2.myshopify.com" === window.Shopify.shop ? `${e.variant_name}` : "thetotelibrary.myshopify.com" == window.Shopify.shop ? `${e.variant_name} - Free` : `${e.variant_name} - ${formatMoney1(e.price,2)}`, `<option value="${e.variant_id}" data-image="${o}">\n                        ${i}\n                      </option>`
                        })).join("");
                        o = `\n              <select id="${i}-variants" class="bmsm-gift-variants">\n                ${t}\n              </select>\n            `, "danielle-guizio-ny.myshopify.com" == window.Shopify.shop && (o = `\n              <select id="variants-${n}" class="bmsm-gift-variants">\n                ${t}\n              </select>\n            `)
                    }
                    const r = '\n  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">\n    <polyline points="20 6 9 17 4 12"></polyline>\n  </svg>\n';
                    "evolution-wheels-2.myshopify.com" === window.Shopify.shop && (s = r);
                    let l = "";
                    "incenseaustralia.myshopify.com" === window.Shopify.shop && (l = 'style="color: black;"'), t.innerHTML = `\n            <img id="${i}-image" src="${p}" alt="${e.product_name}" class="bmsm-gift-image">\n            <p class="bmsm-gift-title" ${l}>${e.product_name}</p>\n            ${o}\n            <button id="${i}-select-btn" class="bmsm-gift-select-btn">\n              ${s}\n            </button>\n          `, "danielle-guizio-ny.myshopify.com" == window.Shopify.shop && (t.innerHTML = `\n            <img id="image-${n}" src="${p}" alt="${e.product_name}" class="bmsm-gift-image">\n            <p class="bmsm-gift-title" ${l}>${e.product_name}</p>\n            ${o}\n            <button id="select-btn-${n}" class="bmsm-gift-select-btn">\n              ${s}\n            </button>\n          `)
                }
                c.appendChild(t);
                var d = t.querySelector(`#${i}-variants`);
                "danielle-guizio-ny.myshopify.com" == window.Shopify.shop && (d = t.querySelector(`#variants-${n}`));
                var m = t.querySelector(`#${i}-image`);
                "danielle-guizio-ny.myshopify.com" == window.Shopify.shop && (m = t.querySelector(`#image-${n}`)), d && d.addEventListener("change", (function() {
                    const e = d.options[d.selectedIndex].getAttribute("data-image");
                    e && (m.src = e)
                }));
                var y = t.querySelector(`#${i}-select-btn`);
                "danielle-guizio-ny.myshopify.com" == window.Shopify.shop && (y = t.querySelector(`#select-btn-${n}`)), y && y.addEventListener("click", (function() {
                    let o;
                    if (d) {
                        const t = d.value;
                        o = e.variants.find((e => e.variant_id === t))
                    } else 1 === e.variants.length && (o = e.variants[0]);
                    o && (t.classList.add("bmsm-gift-card-selected"), addGiftToCart(o.variant_id, o.discount_id, o.tier_minSpend))
                }))
            })), r.appendChild(c), r.querySelectorAll(".bmsm-gift-image").forEach((e => {
                var t, n = i ? o.popupImageHeightMobile : o.popupImageHeight,
                    s = i ? o.popupImageWidthMobile : o.popupImageWidth;
                "iymt0v-hw.myshopify.com" == window.Shopify.shop && (s = i ? "60%" : "240px"), "doukissa-nomikou.myshopify.com" == window.Shopify.shop && i && (s = "150px"), s && (e.style.width = s), n && (e.style.height = "number" == typeof(t = n) ? `${t}px` : t)
            }));
            r.querySelectorAll(".bmsm-gift-select-btn").forEach((e => {
                o.selectButtonColor && (e.style.backgroundColor = applyColor(o.selectButtonColor)), o.selectButtonTextColor && (e.style.color = applyColor(o.selectButtonTextColor)), o.selectButtonTextSize && (e.style.fontSize = `${o.selectButtonTextSize}px`)
            })), "javasokb2b.myshopify.com" === window.Shopify.shop && (r.querySelectorAll(".bmsm-gift-variants").forEach((e => {
                e.style.display = "none"
            })), r.querySelectorAll(".bmsm-gift-price").forEach((e => {
                e.style.display = "none"
            })), r.querySelectorAll(".bmsm-gift-select-btn").forEach((e => {
                e.style.backgroundColor = "#297373"
            }))), "iymt0v-hw.myshopify.com" == window.Shopify.shop && r.querySelectorAll(".bmsm-gift-select-btn").forEach((e => {
                e.style.backgroundColor = "#974950"
            })), "peachade.myshopify.com" == window.Shopify.shop && (r.querySelectorAll(".bmsm-gift-select-btn").forEach((e => {
                e.style.backgroundColor = "#f6b5c0"
            })), document.querySelector(".bmsm-gift-popup-close-btn").style.backgroundColor = "#825952"), "wkn7z2-1x.myshopify.com" == window.Shopify.shop && (r.querySelectorAll(".bmsm-gift-select-btn").forEach((e => {
                e.style.backgroundColor = "#F2D2BD", e.style.fontFamily = "var(--heading-font-family)"
            })), document.querySelector(".bmsm-gift-popup-close-btn").style.backgroundColor = "#ffffff", document.querySelector(".bmsm-gift-popup-close-btn").style.border = "1px solid black", document.querySelector(".bmsm-gift-popup-close-btn").style.color = "black", document.querySelector(".bmsm-gift-popup-close-btn").style.fontFamily = "var(--heading-font-family)", r.querySelectorAll(".bmsm-gift-variants").forEach((e => {
                e.style.backgroundColor = "#ffffff", e.style.border = "1px solid black", e.style.borderRadius = "4px", e.style.fontFamily = "var(--heading-font-family)"
            })), r.querySelectorAll(".bmsm-gift-title").forEach((e => {
                e.style.fontFamily = "var(--heading-font-family)"
            }))), "d06409-1b.myshopify.com" == window.Shopify.shop && r.querySelectorAll(".bmsm-gift-select-btn").forEach((e => {
                e.style.backgroundColor = "#CC6206"
            }))
        })), "flex" !== n.style.display && (document.querySelector(".bmsm-gift-popup-content").addEventListener("touchmove", (function(e) {
            e.stopPropagation()
        }), {
            passive: !1
        }), n.style.display = "flex", n.style.visibility = "visible", s.style.display = "block", s.style.visibility = "visible", toggleScrollIndicator()), window.Shopify && "mdblend.myshopify.com" === window.Shopify.shop) {
        const e = document.querySelector(".bmsm-gift-popup");
        e && (e.style.opacity = "1")
    }
}

function addGiftToCart(e, t, o) {
    const i = [{
        id: e.replace("gid://shopify/ProductVariant/", ""),
        quantity: 1,
        properties: {
            _discountid: t,
            _tier_minSpend: o.toString(),
            _added_by: "bmsm_pb"
        }
    }];
    sessionStorage.setItem(e.replace("gid://shopify/ProductVariant/", ""), (new Date).toISOString()), fetch(window.Shopify.routes.root + "cart/add.js", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            items: i
        })
    }).then((e => e.json())).then((e => {
        closeGiftPopup(), fetchAndUpdateMultipleSections("add", e, window.pageType, t)
    })).catch((e => {}))
}

function closeGiftPopup() {
    document.getElementById("bmsm-gift-popup").style.display = "none"
}

function showGiftCarousel(e) {
    let t = [];
    if (Array.isArray(e)) t = e;
    else if ("string" == typeof e) try {
        t = JSON.parse(e)
    } catch (o) {
        try {
            t = JSON.parse(decodeURIComponent(e))
        } catch (e) {
            return
        }
    }
    if (!t || 0 === t.length) return void destroyGiftCarousels();
    const o = ensureGiftCarouselWrapper();
    if (!o) return;
    o.style.display = "block", o.style.visibility = "visible", document.querySelectorAll(".bmsm-achievement-text").forEach((e => {
        e.dataset.bmsmPrevDisplay || (e.dataset.bmsmPrevDisplay = e.style.display || ""), e.style.display = "none"
    }));
    const i = groupGiftsForCarousel(t);
    var n = !1;
    "confetti-gifts-co.myshopify.com" == window.Shopify.shop && (n = !0);
    let s = [];
    if (n) s = i.filter((e => !e.giftAdded));
    else {
        let e = null,
            t = -1;
        i.forEach((o => {
            const i = "na" === o.tierMinSpend ? -1 : parseFloat(o.tierMinSpend) || -1;
            i > t && (t = i, e = o)
        })), e && (s = [e])
    }
    if (!s.length) return void destroyGiftCarousels();
    const r = new Set;
    s.forEach((e => {
        const t = `bmsm-gift-carousel-${e.discountId}-${e.tierMinSpend}`;
        r.add(t);
        let i = document.getElementById(t);
        i || (i = document.createElement("div"), i.id = t, i.className = "bmsm-gift-carousel-section bmsm-upsell-carousel", o.appendChild(i), attachGiftCarouselEvents(i)), renderGiftCarouselSection(i, e)
    })), o.querySelectorAll(".bmsm-gift-carousel-section").forEach((e => {
        if (!r.has(e.id)) {
            const t = e.querySelector(".bmsm-gift-splide");
            if (t && t._bmsmSplide) {
                try {
                    t._bmsmSplide.destroy(!0)
                } catch (e) {}
                delete t._bmsmSplide
            }
            e.remove()
        }
    }))
}

function ensureGiftCarouselWrapper() {
    let e = document.getElementById("bmsm-gift-carousel-wrapper");
    if (e) return e;
    const t = document.querySelector(".bmsm-cart-drawer-block") || document.getElementById("bmsm-cartDrawerBlock") || document.querySelector(".bmsm-product-page-block") || document.getElementById("bmsm-productPageBlock");
    return t ? (e = document.createElement("div"), e.id = "bmsm-gift-carousel-wrapper", e.className = "bmsm-gift-carousel-wrapper", t.appendChild(e), e) : null
}

function destroyGiftCarousels() {
    const e = document.getElementById("bmsm-gift-carousel-wrapper");
    e ? (e.querySelectorAll(".bmsm-gift-splide").forEach((e => {
        if (e._bmsmSplide) {
            try {
                e._bmsmSplide.destroy(!0)
            } catch (e) {}
            delete e._bmsmSplide
        }
    })), e.remove(), document.querySelectorAll(".bmsm-achievement-text").forEach((e => {
        e.style.display = e.dataset.bmsmPrevDisplay || ""
    }))) : document.querySelectorAll(".bmsm-achievement-text").forEach((e => {
        e.style.display = e.dataset.bmsmPrevDisplay || ""
    }))
}

function groupGiftsForCarousel(e) {
    const t = e.reduce(((e, t) => {
        const o = t.tier_minSpend ? ? t.tier_minspend ? ? t.tierMinSpend ? ? "na",
            i = `${t.discount_id}_${o}`;
        if (!e[i]) {
            const n = t.noofgifts || 1;
            let s = `Choose any ${n} gift`;
            t.giftpopup && (s = t.giftpopup.replace("{noofgifts}", n)), e[i] = {
                discountId: t.discount_id,
                tierMinSpend: o,
                heading: s,
                noOfGifts: n,
                items: []
            }
        }
        return e[i].items.push(t), e
    }), {});
    return Object.values(t)
}

function renderGiftCarouselSection(e, t) {
    const o = `${e.id}-splide`,
        i = t.items.map((e => `<li class="splide__slide">${createGiftCarouselCard(e)}</li>`)).join(""),
        n = window.Shopify && "confetti-gifts-co.myshopify.com" === window.Shopify.shop;
    var s = `Select Gift for orders ₹${t.tierMinSpend}+`;
    "1" == t.tierMinSpend && (s = "Select Gift for orders upto ₹2000");
    const r = n ? `\n      <div class="bmsm-gift-carousel-header">\n        <div class="bmsm-gift-group-title">\n          ${"na"===t.tierMinSpend?"Free Gifts":s}\n        </div>\n      </div>\n    ` : "";
    e.innerHTML = `\n    ${r}\n    <div class="splide bmsm-gift-splide" id="${o}">\n      <div class="splide__track">\n        <ul class="splide__list">\n          ${i}\n        </ul>\n      </div>\n    </div>\n  `, setupGiftCarouselSplide(e)
}

function createGiftCarouselCard(e) {
    const t = e.variant_featured_image || e.featured_image || "",
        o = t ? t.startsWith("http") ? t : `/cdn/shop/${t.replace(/^\/+/,"")}` : "",
        i = "number" == typeof e.price ? e.price : 0,
        n = "number" == typeof e.compare_at_price && e.compare_at_price > 0 ? e.compare_at_price : i,
        s = formatMoney1(0, 2),
        r = n > 0 ? formatMoney1(n, 2) : "",
        l = e.variant_name && "Default Title" !== e.variant_name ? e.variant_name : "";
    return `\n      <div class="bmsm-upsell-product-card" data-product-id="${e.product_id||""}">\n        <div class="bmsm-upsell-product-image">\n          ${o?`<img src="${o}" alt="${e.product_name||""}" loading="lazy" onerror="this.style.display='none'">`:""}\n        </div>\n        <div class="bmsm-upsell-product-info">\n          <h4 class="bmsm-upsell-product-title" title="${e.product_name||""}">\n            ${e.product_name||""}\n          </h4>\n          ${l?`<p class="bmsm-gift-carousel-variant">${l}</p>`:""}\n          <div class="bmsm-upsell-product-price">\n            ${r?`<span class="bmsm-upsell-compare-price">${r}</span>`:""}\n            <span class="bmsm-upsell-current-price">${s}</span>\n          </div>\n          <div class="bmsm-upsell-variant-cart-row">\n            <button\n              class="bmsm-upsell-add-to-cart"\n              data-variant-id="${e.variant_id}"\n              data-discount-id="${e.discount_id}"\n              data-tier-min="${e.tier_minSpend??e.tier_minspend??""}"\n            >\n              <span class="label">${window.bmsmGiftCarouselCta||"Select Gift"}</span>\n            </button>\n          </div>\n        </div>\n      </div>\n    `
}

function attachGiftCarouselEvents(e) {
    "true" !== e.dataset.bmsmGiftBound && (e.dataset.bmsmGiftBound = "true", e.addEventListener("click", (e => {
        const t = e.target.closest(".bmsm-upsell-add-to-cart");
        if (!t) return;
        const o = t.getAttribute("data-variant-id"),
            i = t.getAttribute("data-discount-id"),
            n = t.getAttribute("data-tier-min");
        o && addGiftToCart(o, i, n)
    })))
}

function setupGiftCarouselSplide(e) {
    const t = e.querySelector(".bmsm-gift-splide");
    if (!t) return;
    if (t._bmsmSplide) {
        try {
            t._bmsmSplide.destroy(!0)
        } catch (e) {}
        delete t._bmsmSplide
    }
    const o = () => {
        try {
            e.style.display = "block", e.style.visibility = "visible";
            const o = new Splide(t, getOptionsForContainer(e));
            t._bmsmSplide = o, o.mount()
        } catch (e) {}
    };
    "undefined" == typeof Splide ? loadSplide().then(o).catch((e => {})) : o()
}
const formatMoney1 = (e, t, o = !0) => {
    const i = window.Shopify.currency.active,
        n = /^[a-z]{2}-[A-Z]{2}$/.test(window.Shopify.locale) ? window.Shopify.locale : `${window.Shopify.locale}-${window.Shopify.country}`,
        s = roundup(parseFloat(e));
    let r = 0;
    "d06409-1b.myshopify.com" === window.Shopify.shop && (r = 0 === t ? 0 : 2), "63bfd6-5f.myshopify.com" === window.Shopify.shop && (r = 2);
    let l = new Intl.NumberFormat(n, {
        style: "currency",
        currency: i,
        minimumFractionDigits: r,
        maximumFractionDigits: r
    }).format(s);
    return "63bfd6-5f.myshopify.com" === window.Shopify.shop && (l = l.replace(/\s+/g, "")), l
};

function refreshCartData(e) {
    "2b2641-3.myshopify.com" != window.Shopify.shop && setTimeout((() => {
        initializeUpsellsFromActiveMetaobjects()
    }), 900), window.bmsmcustomdiv = !1, "welkom01-c31b.myshopify.com" === window.Shopify.shop && window.location.href.startsWith("https://theragcompany.eu/") || "incenseaustralia.myshopify.com" == window.Shopify.shop && window.customerTags ? .includes("Wholesale") || (render || 3 === e) && (render = !1, fetch("/cart.js").then((e => e.json())).then((t => {
        if ((parseFloat(window.bmsmcartlength) || 0) === t.item_count && 1 === e) return;
        parseFloat(sessionStorage.getItem("bmsmCartLength")) === t.item_count ? window.bmsmshowGiftPopup = !1 : (window.bmsmshowGiftPopup = !0, sessionStorage.setItem("bmsmCartLength", t.item_count)), window.bmsmcartlength = t.item_count;
        let o = {
            promoBar: {
                nometaobjects: 0,
                isprogressbar: !1
            },
            productPageBlock: {
                nometaobjects: 0,
                isprogressbar: !1
            },
            cartDrawerBlock: {
                nometaobjects: 0,
                isprogressbar: !1
            },
            customprogressbar: {
                nometaobjects: 0,
                isprogressbar: !1
            },
            stickyprogressbar: {
                nometaobjects: 0,
                isprogressbar: !1
            }
        };
        const i = window.Shopify.country,
            n = parseFloat(window.Shopify.currency.rate),
            s = window.Shopify.locale;
        let r = [],
            l = window.pageType;
        "the-dragontree-apothecary.myshopify.com" != window.Shopify.shop ? (l.startsWith("product.") && (l = "product"), l.startsWith("collection.") && (l = "collection")) : l = "product";
        const a = window.location.pathname;
        "all" === (a.startsWith("/collections/") ? a.split("/")[2] : null) && (l = "index"), window.activeMetaobjects && window.activeMetaobjects.length > 0 && window.activeMetaobjects.forEach((a => {
            if (document.referrer) {
                const e = new URL(document.referrer);
                if (e.searchParams.has("bmsmpreviewid")) {
                    const t = e.searchParams.get("bmsmpreviewid"),
                        o = new URL(window.location.href);
                    o.searchParams.set("bmsmpreviewid", t), window.history.pushState({}, "", o)
                }
            }
            const c = window.location.href,
                p = a.discountId,
                d = new URLSearchParams(new URL(c).search);
            if (d.has("bmsmpreviewid")) {
                if (d.get("bmsmpreviewid") !== p) return
            } else if (p.includes("bmsmPreview")) return;
            if (d.has("bmsmpreviewid")) {
                if (d.get("bmsmpreviewid") === p) {
                    const e = document.getElementById("bmsmstickyMessage");
                    e.style.display = "block", e.style.visibility = "visible"
                }
            }
            var m = a.selectedMarkets || [];
            if ("c2d5db-7b.myshopify.com" == window.Shopify.shop && (m = []), "skalli-essentials.myshopify.com" == window.Shopify.shop && "1213" == p && "US" == window.Shopify.country) return;
            if (m.length > 0 && !(Array.isArray(m) && "string" == typeof m[0] ? m.includes(i) : m.some((e => e.marketCountryCode === i)))) return;
            if (window.kaicart && (r = JSON.parse(window.kaicart), window.productId && window.kaicurrenctproduct)) {
                const e = window.productId,
                    t = window.kaicurrenctproduct.map((e => e.handle)),
                    o = r.find((t => t.product_id === e));
                o ? o.collections = Array.from(new Set([...o.collections, ...t])) : r.push({
                    product_id: e,
                    collections: t
                })
            }
            let y = !1,
                u = !1,
                f = !1,
                h = !1,
                w = !1,
                g = !1,
                b = !1,
                S = !0;
            if (a.tiers && a.tiers.length > 0) {
                const {
                    cartCondition: e,
                    displayCondition: o = !1
                } = a.tiers[0];
                if ("1 product in cart" === e && 0 === t.items.length) {
                    const e = document.querySelector(`.bmsm-tier-timeline[id="${a.discountId}"]`);
                    return void(e && (e.style.display = "none"))
                } {
                    const e = document.querySelector(`.bmsm-tier-timeline[id="${a.discountId}"]`);
                    e && "none" === e.style.display && (e.style.display = "block")
                }
                if (o) {
                    const e = new URLSearchParams(window.location.search).get("variant");
                    e && e !== window.selectedVariantId && (window.selectedVariantId = e);
                    window.productId;
                    const t = (window.kaicurrenctproduct || []).map((e => e.handle)),
                        o = "gid://shopify/ProductVariant/" + window.selectedVariantId,
                        i = window.location.pathname,
                        n = i.startsWith("/collections/") ? i.split("/")[2] : null;
                    "collection" !== l && "product" !== l && "index" !== l && (S = !1), a.selectedCollectionIds.length > 0 && "collection" === l && (n && a.selectedCollectionIds.includes(n) || (S = !1)), a.selectedExcludedCollectionIds.length > 0 && "collection" === l && n && a.selectedExcludedCollectionIds.includes(n) && (S = !1), "product" === l && (0 !== a.selectedProductVariantIds.length && a.selectedProductVariantIds.includes(o) || 0 !== a.selectedCollectionIds.length && t.some((e => a.selectedCollectionIds.includes(e))) || !(a.selectedProductVariantIds.length > 0 || a.selectedCollectionIds.length > 0) || (S = !1)), a.selectedExcludedProductVariantIds.length > 0 && "product" === l && a.selectedExcludedProductVariantIds.includes(o) && (S = !1), a.selectedExcludedCollectionIds.length > 0 && "product" === l && t.some((e => a.selectedExcludedCollectionIds.includes(e))) && (S = !1), 0 === a.selectedCollectionIds.length && 0 === a.selectedExcludedCollectionIds.length && (a.selectedProductVariantIds.length > 0 || a.selectedExcludedProductVariantIds.length > 0) && "collection" === l && (S = !1), S && (y = !0, u = !0, f = !0, h = !0, w = !0, g = !0, b = !0)
                } else y = !0, u = !0, f = !0, h = !0, w = !0, g = !0, b = !0
            }
            const v = a.discountType || "value",
                _ = a.selectedProductVariantIds || [],
                x = a.selectedProductIds || [];
            var C = a.selectedCollectionIds || [];
            const k = a.selectedExcludedProductVariantIds || [],
                $ = a.selectedExcludedProductIds || [],
                E = a.selectedExcludedCollectionIds || [];
            "algebra-and-beyond.myshopify.com" == window.Shopify.shop && "/" === window.location.pathname && (C = []);
            const T = 0 === _.length && 0 === x.length && 0 === C.length && 0 === k.length && 0 === $.length && 0 === E.length,
                q = 0 === _.length && 0 === x.length && 0 === C.length,
                B = t.items.filter((e => {
                    const t = e.properties._discountid || null,
                        o = e.properties._tier_minSpend || null,
                        i = e.properties._added_by || null,
                        n = e.properties._bundle_data || null;
                    if (null !== i && null !== t && null !== o) return !1;
                    if ("doukissa-nomikou.myshopify.com" === window.Shopify.shop && n) return !1;
                    if (T) return !0;
                    const s = `gid://shopify/ProductVariant/${e.variant_id}`,
                        l = `gid://shopify/Product/${e.product_id}`,
                        a = l.replace("gid://shopify/Product/", ""),
                        c = _.includes(s),
                        p = x.includes(l),
                        d = r.find((e => e.product_id.toString() === a.toString()));
                    let m = !1,
                        y = !1;
                    d && (m = d.collections.some((e => C.includes(e))), y = E.length > 0 && d.collections.some((e => E.includes(e))));
                    const u = k.length > 0 && k.includes(s),
                        f = $.length > 0 && $.includes(l);
                    return !(u || f || y) && (c || p || m || q)
                })),
                I = a.tiers[0] ? .calcDiscount ? ? !1;
            let M = 0;
            if (M = I && a.tiers.every((e => "free_gift" === e.tierType || "free_shipping" === e.tierType)) ? B.reduce(((e, t) => e + t.final_line_price), 0) / 100 : B.reduce(((e, t) => e + t.final_line_price + t.line_level_total_discount), 0) / 100, "c2d5db-7b.myshopify.com" === window.Shopify.shop) {
                const e = B.filter((e => 0 !== e.line_price));
                M = I && a.tiers.every((e => "free_gift" === e.tierType || "free_shipping" === e.tierType)) ? e.reduce(((e, t) => e + t.final_line_price), 0) / 100 : e.reduce(((e, t) => e + t.final_line_price + t.line_level_total_discount), 0) / 100, t.discount_codes && t.discount_codes.some((e => "WELCOME10" === e.code && !0 === e.applicable)) && (M -= .1 * M)
            }
            const A = (t.cart_level_discount_applications || []).filter((e => "discount_code" === e.type)).reduce(((e, t) => e + (t.total_allocated_amount || 0)), 0) / 100,
                F = Math.max(M - A, 0);
            if (M = F, "capsole-6168.myshopify.com" == window.Shopify.shop && ["871", "873"].includes(String(a.discountId)) && t.items.forEach((e => {
                    e.selling_plan_allocation && e.selling_plan_allocation.selling_plan && /1 Month|3 Month|6 Month|3 Months|6 Months/i.test(e.selling_plan_allocation.selling_plan.name) && (M -= (e.final_line_price || 0) / 100)
                })), "capsole-6168.myshopify.com" == window.Shopify.shop && ["872", "874"].includes(String(a.discountId)) && t.items.forEach((e => {
                    e.selling_plan_allocation || (M -= (e.final_line_price || 0) / 100)
                })), "wiwsk1-1w.myshopify.com" === window.Shopify.shop) {
                t.items.some((e => e.total_discount > 0)) && t.items.forEach((e => {
                    e.total_discount > 0 && (M -= (e.total_discount || 0) / 100)
                }))
            }
            "1101" != p && "1077" != p || t.items.forEach((e => {
                e.discounts && e.discounts.length > 0 && e.discounts.forEach((e => {
                    if ("Bundle-Vorteil" === e.title) {
                        const t = e.amount || 0;
                        M -= t / 100
                    }
                }))
            })), "2b2641-3.myshopify.com" != window.Shopify.shop && "bv4ipw-0k.myshopify.com" != window.Shopify.shop || t.items.forEach((e => {
                e.discounts && e.discounts.length > 0 && e.discounts.forEach((e => {
                    const t = e.amount || 0;
                    M -= t / 100
                }))
            }));
            const L = B.reduce(((e, t) => {
                const o = 8432173547805 === t.product_id,
                    i = window.Shopify && "jeesauce-com.myshopify.com" === window.Shopify.shop;
                return e + (o && i ? 2 * t.quantity : t.quantity)
            }), 0);
            let P = B.reduce(((e, t) => t.properties && t.properties._YmqItemPrice ? e + parseFloat(t.properties._YmqItemPrice) * n * t.quantity : e), 0);
            if (window.Shopify && "c2d5db-7b.myshopify.com" === window.Shopify.shop) {
                P = B.filter((e => {
                    const t = e.properties && e.properties._added_by,
                        o = e.properties && e.properties._discountid && e.properties._tier_minSpend;
                    return !("bmsm_pb" === t && o)
                })).reduce(((e, t) => t.properties && t.properties._YmqItemPrice ? e + parseFloat(t.properties._YmqItemPrice) * n * t.quantity : e), 0)
            }
            if ("manupskin.myshopify.com" == window.Shopify.shop) {
                t.items.some((e => e.selling_plan_allocation && e.selling_plan_allocation.selling_plan)) && (M = 100)
            }
            M += P, final_cart_total_upsell = M, final_cart_quantity_upsell = L, window.kaieligible = !0;
            var j = "value" === v ? M : L;
            if ("ambrosia-nutraceuticals.myshopify.com" == window.Shopify.shop && "" != amrosia_custom_quantity && (amrosia_custom_quantity = parseInt(amrosia_custom_quantity, 10), j = amrosia_custom_quantity), window.kaieligibleDiscountIds = window.kaieligibleDiscountIds || [], a.tiers && a.tiers.length > 0) {
                const {
                    cartCondition: e
                } = a.tiers[0];
                if ("eligible" === e && 0 === j) {
                    const e = document.querySelector(`.bmsm-tier-timeline[id="${a.discountId}"]`);
                    e && (e.style.display = "none"), window.kaieligibleDiscountIds.push(a.discountId), window.kaieligible = !1
                } else {
                    const e = document.querySelector(`.bmsm-tier-timeline[id="${a.discountId}"]`);
                    e && "none" === e.style.display && (e.style.display = "block")
                }
            }
            let z = a.tiers;
            z = z.sort(((e, t) => parseFloat(e.minSpend) - parseFloat(t.minSpend))), z = z.map(((e, t) => (null !== e.tierId && void 0 !== e.tierId || (e.tierId = t), e)));
            const D = m.find((e => e.marketCountryCode === i && e.tiers));
            z = D ? z.map((e => {
                const t = D.tiers.find((t => t.tierId === e.tierId));
                return t ? { ...e,
                    minSpend: t.trigger ? t.trigger : e.minSpend,
                    value: t.value ? t.value : e.value
                } : { ...e,
                    minSpend: "value" === v ? parseFloat(e.minSpend) * n : e.minSpend,
                    value: "amount" === e.tierType ? parseFloat(e.value) * n : e.value
                }
            })) : z.map((e => ({ ...e,
                minSpend: "value" === v ? parseFloat(e.minSpend) * n : e.minSpend,
                value: "amount" === e.tierType ? parseFloat(e.value) * n : e.value
            }))), "c2d5db-7b.myshopify.com" === window.Shopify.shop && "LB" === i && (z = z.map((e => "free_shipping" === e.tierType ? { ...e,
                minSpend: 50
            } : e)));
            const H = z[0].selectedLanguages;
            let G = z[0].enableTranslations || !1;
            if (H && H.length > 0 && G && (z = z.map((e => {
                    const t = H.find((t => t.tierId === e.tierId && t.locale === s));
                    return t && (null !== t.nudgeText && "" !== t.nudgeText && (e.nudgeText = t.nudgeText), null !== t.achievementText && "" !== t.achievementText && (e.achievementText = t.achievementText), null !== t.freegiftname && "" !== t.freegiftname && (e.freegiftname = t.freegiftname), null !== t.amountsuffix && "" !== t.amountsuffix && (e.amountsuffix = t.amountsuffix), null !== t.discountLabel && "" !== t.discountLabel && (e.discountLabel = t.discountLabel), null !== t.freeshippingname && "" !== t.freeshippingname && (e.freeshippingname = t.freeshippingname), null !== t.mysterygiftordernote && "" !== t.mysterygiftordernote && (e.mysterygiftordernote = t.mysterygiftordernote), null !== t.discountTag && "" !== t.discountTag && (e.discountTag = t.discountTag), null !== t.giftpopup && "" !== t.giftpopup && (e.giftpopup = t.giftpopup), null !== t.claimtext && "" !== t.claimtext && (e.claimtext = t.claimtext)), e
                })), a.variant_stock_array && a.variant_stock_array.length > 0 && (a.variant_stock_array = a.variant_stock_array.map((e => {
                    const t = H.find((t => t.tierId.toString() === e.tier_id && t.locale === s && a.discountId === e.discount_id));
                    return t && (null !== t.giftpopup && "" !== t.giftpopup && (e.giftpopup = t.giftpopup), null !== t.claimtext && "" !== t.claimtext && (e.claimtext = t.claimtext)), e
                })))), z = z.sort(((e, t) => parseFloat(e.minSpend) - parseFloat(t.minSpend))), a.variant_stock_array && a.variant_stock_array.length > 0 && a.variant_stock_array.forEach((e => {
                    if (e.discount_id === a.discountId) {
                        const t = z.find((t => t.tierId.toString() === e.tier_id));
                        t && (e.tier_minSpend = parseFloat(t.minSpend))
                    }
                })), z && Array.isArray(z) && z.length > 0) {
                const i = z.slice().reverse().find((e => j >= parseFloat(e.minSpend))),
                    n = z.find((e => j < parseFloat(e.minSpend))),
                    s = z.slice().reverse().find((e => j >= parseFloat(e.minSpend) && ("free_gift" === e.tierType || "bogo" === e.tierType) && !0 !== e.nodisc));
                if (window.bmsmpreviousTier = i ? i.minSpend : 0, !window.BMSMSectionRefresh) {
                    let e = {},
                        o = a.tiers[0].replaceGifts ? ? !1;
                    t.items.forEach((t => {
                        const n = t.properties._discountid === p;
                        let r = !1;
                        r = i && o ? parseFloat(t.properties._tier_minSpend || 0) !== parseFloat(s ? .minSpend ? ? -1) : parseFloat(t.properties._tier_minSpend || 0) > j;
                        const l = "bmsm_pb" === t.properties._added_by;
                        var a = t.final_line_price > 0 || 0 === t.price,
                            c = t.final_line_price > 0;
                        "1uhrmb-ix.myshopify.com" != window.Shopify.shop && "kacy56-1a.myshopify.com" != window.Shopify.shop || "1" == t.final_line_price && (c = !1), "mg-naturals.myshopify.com" != window.Shopify.shop && "mg-naturals.myshopify.com" != window.Shopify.shop && "pectiv-4913.myshopify.com" != window.Shopify.shop && "pectiv-ksa.myshopify.com" != window.Shopify.shop && "63bfd6-5f.myshopify.com" != window.Shopify.shop && "equidae-botanical-horse-care.myshopify.com" != window.Shopify.shop && "1uhrmb-ix.myshopify.com" != window.Shopify.shop && "thefazlab.myshopify.com" != window.Shopify.shop && "danielle-guizio-ny.myshopify.com" != window.Shopify.shop || (a = !0);
                        let d = n && r && l && a;
                        "fashioncore-gr.myshopify.com" !== window.Shopify.shop && "7dbb89-30.myshopify.com" !== window.Shopify.shop || (d = n && r && l);
                        let m = !1;
                        if (!r && n && l && c) {
                            const e = sessionStorage.getItem(t.variant_id);
                            if (e) {
                                const o = Date.now(),
                                    i = e ? new Date(e).getTime() : null,
                                    n = i ? (o - i) / 1e3 : 0;
                                m = i && n > 3, "kasbahmen.myshopify.com" != window.Shopify.shop && m && sessionStorage.setItem(t.variant_id, "deleted")
                            }
                        }
                        d && sessionStorage.removeItem(t.variant_id), (d || m) && (e[t.key] = 0);
                        const y = 0 === t.price,
                            u = t.quantity > 1;
                        n && y && l && u && (e[t.key] = 1)
                    })), Object.keys(e).length > 0 && (window.BMSMSectionRefresh = !0, updateCartQuantity("update", e, p))
                }
                let r;
                r = "value" === v ? n ? formatMoney1(parseFloat(n.minSpend) - j, 2) : "" : n ? "" + (parseFloat(n.minSpend) - j) : "";
                let c = "&nbsp;";
                i && (c = i.achievementText.replace("{Value}", formatTierValue(i)).replace("{noofgifts}", i.noofgifts)), "" === c.trim() && (c = "&nbsp;");
                let d = a.placementStyles.announcementBar.text,
                    m = n ? n.nudgeText.replace("{Trigger - Current}", r).replace("{Value}", formatTierValue(n)).replace("{noofgifts}", n.noofgifts) : "&nbsp;";
                a.placementStyles.announcementBar && a.placementStyles.announcementBar.text && n ? d = a.placementStyles.announcementBar.text.replace("{Trigger - Current}", r).replace("{Value}", formatTierValue(n)).replace("{noofgifts}", n.noofgifts) : a.placementStyles.announcementBar && a.placementStyles.announcementBar.text && !n && (d = c);
                let S = d,
                    _ = d;
                if (!window.BMSMSectionRefresh) {
                    let e = a.tiers[0].replaceGifts ? ? !1,
                        o = z.filter((e => {
                            const t = Array.isArray(e.giftProductId) ? 1 === e.giftProductId.length && Array.isArray(e.giftProductId[0] ? .variants) && 1 === e.giftProductId[0].variants.length ? e.giftProductId[0].variants[0] ? .id : null : e.giftProductId;
                            return j >= parseFloat(e.minSpend) && "free_gift" === e.tierType && (!e.gifttype || null === e.gifttype || "define_free_gift" === e.gifttype) && !0 !== e.nodisc && null !== t
                        }));
                    if (e && o.length > 0) {
                        const e = z.slice().reverse().find((e => j >= parseFloat(e.minSpend) && ("free_gift" === e.tierType || "bogo" === e.tierType)));
                        o = e && "define_free_gift" === e.gifttype ? o.filter((t => t.minSpend === e.minSpend)) : []
                    }
                    let i = [];
                    if (o.forEach((e => {
                            const o = (Array.isArray(e.giftProductId) ? 1 === e.giftProductId.length && Array.isArray(e.giftProductId[0] ? .variants) && 1 === e.giftProductId[0].variants.length ? e.giftProductId[0].variants[0] ? .id : null : e.giftProductId).replace("gid://shopify/ProductVariant/", "");
                            let n = !0;
                            n = t.items.some((e => void 0 !== e.properties ? ._discountid && void 0 !== e.properties ? ._tier_minSpend && void 0 !== e.properties ? ._added_by && "bmsm_pb" === e.properties ? ._added_by && o === `${e.variant_id}`));
                            const s = sessionStorage.getItem(o);
                            "sz0efx-qg.myshopify.com" === window.Shopify.shop ? s && "error" === s && (n = !0) : "ambrosia-nutraceuticals.myshopify.com" === window.Shopify.shop || "canyoncreekringco.myshopify.com" === window.Shopify.shop || !s || "deleted" !== s && "error" !== s || (n = !0), !s || "ckc-trade.myshopify.com" !== window.Shopify.shop && "ckc-consumer.myshopify.co" !== window.Shopify.shop && "airyday-trial.myshopify.com" !== window.Shopify.shop || (n = !0);
                            let r = a.tiers[0].giftDelete ? ? !1;
                            s && r && (n = !0), n || (i.push({
                                id: o,
                                quantity: 1,
                                properties: {
                                    _discountid: p,
                                    _tier_minSpend: e.minSpend,
                                    _added_by: "bmsm_pb"
                                }
                            }), sessionStorage.setItem(o.replace("gid://shopify/ProductVariant/", ""), (new Date).toISOString()))
                        })), i.length > 0 && (window.BMSMSectionRefresh = !0, updateCartQuantity("add", i, p), "doukissa-nomikou.myshopify.com" === window.Shopify.shop && i.forEach(((e, t) => {
                            const o = a.variant_stock_array.find((t => t.variant_id === `gid://shopify/ProductVariant/${e.id}`));
                            if (o) {
                                const t = document.createElement("div");
                                t.id = `gift-added-popup-${e.id}`, t.className = "bmsm-gift-popup-toast";
                                const i = document.createElement("img");
                                i.src = `/cdn/shop/${o.featured_image}`, i.alt = o.product_name, i.className = "bmsm-gift-popup-image";
                                const n = document.createElement("div");
                                n.className = "bmsm-gift-popup-text";
                                const s = document.createElement("strong");
                                s.innerText = "Gift added!";
                                const r = document.createElement("p");
                                r.innerText = o.product_name, n.appendChild(s), n.appendChild(r);
                                const l = document.createElement("span");
                                l.innerHTML = "&times;", l.className = "bmsm-gift-popup-close", l.addEventListener("click", (() => {
                                    t.remove()
                                })), t.appendChild(i), t.appendChild(n), t.appendChild(l), document.body.appendChild(t), setTimeout((() => {
                                    t.remove()
                                }), 5e3)
                            }
                        }))), o) {
                        let e = document.querySelector('form[action$="/cart"]:not([action*="/cart/add"]):not([id^="product"])');
                        if (e) {
                            const t = e.querySelectorAll('a[href*="/products/"][href*="?variant="]'),
                                i = o.map((e => Array.isArray(e.giftProductId) && 1 === e.giftProductId.length && Array.isArray(e.giftProductId[0] ? .variants) && 1 === e.giftProductId[0].variants.length ? e.giftProductId[0].variants[0] ? .id.replace("gid://shopify/ProductVariant/", "") : "string" == typeof e.giftProductId ? e.giftProductId.replace("gid://shopify/ProductVariant/", "") : null)).filter(Boolean);
                            t.forEach((e => {
                                const t = new URL(e.href, window.location.origin).searchParams.get("variant");
                                if (i.includes(t)) {
                                    let t = e.parentElement.parentElement;
                                    const o = t ? .textContent ? .trim().replace(",", "."),
                                        i = null !== t.querySelector("s"),
                                        n = Array.from(t.querySelectorAll("*")).filter((e => /\d/.test(e.textContent))).some((e => {
                                            const t = window.getComputedStyle(e);
                                            return t.textDecorationLine.includes("line-through") || t.textDecoration.includes("line-through")
                                        })),
                                        s = /\b0[.,]00\b/;
                                    !i && !n && o && s.test(o) && t.querySelectorAll("input, button").forEach((e => {
                                        e.disabled = !0
                                    }))
                                }
                            }))
                        }
                    }
                }
                if (calculateAndShowEligibleGifts(j, t, z, p, a.variant_stock_array, a.tiers[0].replaceGifts ? ? !1), !window.BMSMSectionRefresh) {
                    let e = a.tiers[0].replaceGifts ? ? !1,
                        o = z.filter((e => "free_gift" === e.tierType && "mystery_gift" === e.gifttype && !0 !== e.nodisc)).map((e => e.mysterygiftordernote)).filter((e => null !== e)),
                        i = [];
                    if (o) {
                        if (i = z.filter((e => j >= parseFloat(e.minSpend) && "free_gift" === e.tierType && "mystery_gift" === e.gifttype && !0 !== e.nodisc)), e && i.length > 0) {
                            const e = z.slice().reverse().find((e => j >= parseFloat(e.minSpend) && ("free_gift" === e.tierType || "bogo" === e.tierType)));
                            i = e && "mystery_gift" === e.gifttype ? i.filter((t => t.minSpend === e.minSpend)) : []
                        }
                        let n = [],
                            s = t.note ? t.note.split(",").map((e => e.trim())) : [];
                        s = s.filter((e => !o.includes(e))), i.forEach((e => {
                            n.push(e.mysterygiftordernote)
                        })), n.forEach((e => {
                            s.includes(e) || s.push(e)
                        })), s.length > 0 && t.note !== s.join(", ") ? (window.BMSMSectionRefresh = !0, updateCartQuantity("note", s.join(", "), p)) : 0 === s.length && "" != t.note && updateCartQuantity("note", "", p)
                    }
                }
                if (a.placementStyles.announcementBar && a.placementStyles.announcementBar.enable && y) {
                    const e = a.placementStyles.announcementBar.pages || "All";
                    if (isPageApplicable(e)) {
                        const e = document.getElementById("bmsm-announcement-bar");
                        e && (document.body.insertAdjacentElement("afterbegin", e), e.innerHTML = d || `${"&nbsp;"!==c?c:""}${"&nbsp;"!==c&&"&nbsp;"!==m?", ":""}${"&nbsp;"!==m?m:""}`, e.classList.add("bmsm-announcement-bar"), e.style.display = "block", e.style.backgroundColor = applyColor(a.placementStyles.announcementBar.backgroundColor), e.style.color = applyColor(a.placementStyles.announcementBar.textColor), e.style.fontFamily = a.placementStyles.announcementBar.font, e.style.fontSize = a.placementStyles.announcementBar.fontSize)
                    }
                }
                if (a.placementStyles.promoBar && a.placementStyles.promoBar.enable && u) {
                    const i = a.placementStyles.promoBar.pages || "All";
                    if (isPageApplicable(i) && ("index" === l || "collection" === l || "product" === l || "search" === l)) {
                        const i = document.getElementById("bmsm-promoBar");
                        if (i) {
                            let n = document.querySelector("main");
                            n || (n = document.querySelector('[role="main"]')), n && n.insertAdjacentElement("afterbegin", i), i.style.display = "block", i.classList.add("bmsm-promo-bar", "page-width"), renderTimeline("bmsm-promoBar", a, z, j, c, m, v, o, l, e, t), o.promoBar.isprogressbar = !0, o.promoBar.nometaobjects += 1
                        }
                    }
                }
                if (a.placementStyles.productPageBlock && a.placementStyles.productPageBlock.enable && f && "product" === l) {
                    const i = document.getElementById("bmsm-productPageBlock");
                    if (i) {
                        let n;
                        const s = window.activeMetaobjects.find((e => e ? .tiers ? .[0] ? .cssConfig)) ? .tiers[0] ? .cssConfig;
                        if (s && s.productPageBlock && s.productPageBlock.pdp_classname && "string" == typeof s.productPageBlock.pdp_classname) {
                            const e = s ? .productPageBlock ? .pdp_classname;
                            n = document.querySelector(e)
                        }
                        n || (n = document.querySelector('form[action$="/cart/add"][method="post"][id^="product-form-template"]')), n || (n = document.querySelector('form[action$="/cart/add"][method="post"][id*="product"][id*="form"][id*="template"]')), n || (n = document.querySelector('form[action$="/cart/add"][method="post"][id^="product-form"]')), n || (n = document.querySelector('form[action$="/cart/add"][method="post"][id^="product_form"]')), n || (n = document.querySelector('form[action="/cart/add"][method="post"][id^="AddToCartForm-template"]')), n && (n.insertAdjacentElement("afterbegin", i), i.style.display = "block", renderTimeline("bmsm-productPageBlock", a, z, j, c, m, v, o, l, e, t), o.productPageBlock.isprogressbar = !0, o.productPageBlock.nometaobjects += 1)
                    }
                }
                const {
                    cartCondition: x
                } = a.tiers[0];
                if (a.placementStyles.cartDrawerBlock && a.placementStyles.cartDrawerBlock.enable && ("eligible" !== x || 0 !== j))
                    if ("cart" === l && "futterwolke.myshopify.com" !== window.Shopify.shop && "manupskin.myshopify.com" !== window.Shopify.shop && "naqedcz.myshopify.com" !== window.Shopify.shop && "uk6dhk-17.myshopify.com" !== window.Shopify.shop && "equidae-botanical-horse-care.myshopify.com" !== window.Shopify.shop && "aarivayu.myshopify.com" !== window.Shopify.shop && "skalli-essentials.myshopify.com" !== window.Shopify.shop) {
                        const i = document.getElementById("bmsm-cartDrawerBlock");
                        if (i) {
                            let n = document.querySelector("main");
                            n || (n = document.querySelector('[role="main"]')), n && n.insertAdjacentElement("afterbegin", i), i.style.display = "block", i.classList.add("bmsm-cart-drawer-block", "page-width"), renderTimeline("bmsm-cartDrawerBlock", a, z, j, c, m, v, o, l, e, t), o.cartDrawerBlock.isprogressbar = !0, o.cartDrawerBlock.nometaobjects += 1
                        }
                    } else {
                        let i = document.getElementById("bmsm-cartDrawerBlock");
                        if (!i) {
                            i = document.createElement("div"), i.classList.add("bmsm-cart-drawer-block"), i.id = "bmsm-cartDrawerBlock";
                            const e = window.cartDrawerBlock;
                            e && (i.innerHTML = e.trim());
                            window.cartDrawerBlockBG && (i.style.backgroundColor = applyColor(window.cartDrawerBlockBG))
                        }
                        if (i) {
                            (insertCartBlock(t.item_count, i) || renderingdelay) && (renderTimeline("bmsm-cartDrawerBlock", a, z, j, c, m, v, o, l, e, t), 0 !== t.items.length && (window.cartDrawerBlock = i.innerHTML.trim()), renderingdelay = !1, o.cartDrawerBlock.isprogressbar = !0, o.cartDrawerBlock.nometaobjects += 1)
                        }
                    }
                if (a.placementStyles.customprogressbar && a.placementStyles.customprogressbar.enable && h) {
                    a.placementStyles.promoBar.pages;
                    const i = document.getElementById("bmsm-customprogressbar");
                    i && (i.style.display = "block", renderTimeline("bmsm-customprogressbar", a, z, j, c, m, v, o, l, e, t), o.customprogressbar.isprogressbar = !0, o.customprogressbar.nometaobjects += 1)
                }
                if (a.placementStyles.stickyprogressbar && a.placementStyles.stickyprogressbar.enable && g) {
                    const i = a.placementStyles.promoBar.pages || "All";
                    if (isPageApplicable(i) && ("index" === l || "collection" === l || "product" === l || "search" === l)) {
                        const i = document.getElementById("bmsm-stickyprogressbar");
                        i && (document.body.appendChild(i), i.style.display = "block", i.classList.add("bmsm-promo-bar"), renderTimeline("bmsm-stickyprogressbar", a, z, j, c, m, v, o, l, e, t), o.stickyprogressbar.isprogressbar = !0, o.stickyprogressbar.nometaobjects += 1)
                    }
                }
                if (a.placementStyles.customtextbar && a.placementStyles.customtextbar.enable && w) {
                    const e = a.placementStyles.announcementBar.pages || "All";
                    if (isPageApplicable(e)) {
                        const e = document.getElementById("bmsm-customtextbar");
                        e && (e.innerHTML = S || `${"&nbsp;"!==c?c:""}${"&nbsp;"!==c&&"&nbsp;"!==m?", ":""}${"&nbsp;"!==m?m:""}`, e.classList.add("bmsm-customtextbar"), e.style.display = "block", e.style.backgroundColor = applyColor(a.placementStyles.announcementBar.backgroundColor), e.style.color = applyColor(a.placementStyles.announcementBar.textColor), e.style.fontFamily = a.placementStyles.announcementBar.font, e.style.fontSize = a.placementStyles.announcementBar.fontSize)
                    }
                }
                if (a.placementStyles.stickyannouncementBar && a.placementStyles.stickyannouncementBar.enable && b) {
                    const e = a.placementStyles.announcementBar.pages || "All";
                    if (isPageApplicable(e)) {
                        const e = document.getElementById("bmsm-stickyannouncementbar");
                        e && (e.innerHTML = _ || `${"&nbsp;"!==c?c:""}${"&nbsp;"!==c&&"&nbsp;"!==m?", ":""}${"&nbsp;"!==m?m:""}`, e.classList.add("bmsm-stickyannouncementbar"), e.style.display = "block", e.style.backgroundColor = applyColor(a.placementStyles.announcementBar.backgroundColor), e.style.color = applyColor(a.placementStyles.announcementBar.textColor), e.style.fontFamily = a.placementStyles.announcementBar.font, e.style.fontSize = a.placementStyles.announcementBar.fontSize)
                    }
                }
            }
        }))
    })).catch((e => {})), render = !0)
}

function isHidden(e) {
    for (; e;) {
        if ("none" === window.getComputedStyle(e).display) return !0;
        e = e.parentElement
    }
    return !1
}

function getHiddenElementWidth(e) {
    if (!e) return 0;
    const t = e.cloneNode(!0),
        o = document.createElement("div");
    o.style.cssText = "\n                visibility: hidden;\n                position: absolute;\n                top: -9999px;\n                left: -9999px;\n                width: auto;\n                height: auto;\n                overflow: hidden;\n                white-space: nowrap;\n                display: block;\n                z-index: -9999;\n            ", t.style.cssText = "\n            display: block !important;\n            position: static !important;\n            visibility: visible !important;\n            transform: none !important;\n            width: auto !important;\n            height: auto !important;\n        ", o.appendChild(t), document.body.appendChild(o);
    const i = t.clientWidth;
    return document.body.removeChild(o), i
}

function renderTimeline(e, t, o, i, n, s, r, l, a, c, p) {
    const d = document.getElementById(e),
        m = document.documentElement,
        y = document.body;
    var u = "rtl" === m.getAttribute("dir") || "rtl" === y.getAttribute("dir");
    "pectiv-4913.myshopify.com" != window.Shopify.shop && "pectiv-ksa.myshopify.com" != window.Shopify.shop || "ar" != window.Shopify.locale || (u = !0), "bb9tff-6w.myshopify.com" == window.Shopify.shop && (u = !0);
    let f = o[0].evenSpace ? ? !1;
    const h = window.Shopify && window.Shopify.country;
    if (window.Shopify && "c2d5db-7b.myshopify.com" === window.Shopify.shop && "LB" === h && (o = o.map((e => "free_shipping" === e.tierType ? { ...e,
            minSpend: 50
        } : e)), f = !0), d) {
        const m = t.placementStyles.promoBar,
            y = 100,
            h = (Math.max(...o.map((e => parseFloat(e.minSpend)))), Math.min(...o.map((e => parseFloat(e.minSpend))))),
            g = Math.max(...o.map((e => parseFloat(e.minSpend)))),
            b = o.length;
        let S = b > 0 ? y / b : 0;
        const v = y - S,
            _ = g - h || 1;
        let x = S + (i - h) / _ * v;
        if (x = i < h ? i / h * S : S + (i - h) / _ * v, g === h && (x = i / h * y), f) {
            const e = [...o].map(((e, t) => ({
                    tier: e,
                    i: t
                }))).reverse().find((e => i >= parseFloat(e.tier.minSpend))) ? .i,
                t = void 0 !== e ? o[e] : void 0,
                n = o.find((e => i < parseFloat(e.minSpend))),
                s = y / b;
            if (n)
                if (t) {
                    const o = parseFloat(t.minSpend),
                        r = parseFloat(n.minSpend);
                    x = s * (e + 1) + (i - o) / (r - o) * s
                } else x = i / parseFloat(n.minSpend) * s;
            else x = 100
        }
        const C = Math.min(Math.max(x, 0), 100);
        if (0 !== c) {
            const r = Array.from(d.children).find((e => e.id === `${t.discountId}`)) || d.querySelector(`[id="${t.discountId}"]`);
            if (r) {
                const l = r.querySelector(".bmsm-progress-indicator");
                parseFloat(l.style.width);
                l && (l.style.width = `${C}%`);
                const a = r.querySelector(".bmsm-achievement-text");
                if (a) {
                    const e = calculateAndShowEligibleGifts(i, p, o, t.discountId, t.variant_stock_array, t.tiers[0].replaceGifts ? ? !1);
                    let r = "";
                    if (e && e.length > 0) {
                        const t = e.sort(((e, t) => parseInt(t.tier_id) - parseInt(e.tier_id))).find((() => !0)),
                            o = `<a href="#" onclick="showGiftPopup('${encodeURIComponent(JSON.stringify(e))}')">`;
                        r = null !== t.claimtext && void 0 !== t.claimtext ? t.claimtext.replace("<link>", o).replace("</link>", "</a>") : `Claim your Free Gift ${o}here</a>`
                    }
                    "&nbsp;" == n && "mesarey.myshopify.com" == window.Shopify.shop && (n = ""), a.innerHTML = "&nbsp;" !== s ? freegiftpopup ? n + "<br/>" + r : n : freegiftpopup ? r : "&nbsp;", "2b2641-3.myshopify.com" == window.Shopify.shop && (a.style.display = "none"), "w2vjns-k2.myshopify.com" != window.Shopify.shop && "yvxd2k-1p.myshopify.com" != window.Shopify.shop || (a.style.display = "none"), "chhapa.myshopify.com" == window.Shopify.shop && (a.style.marginTop = "30px")
                }
                const c = r.querySelector(".bmsm-nudge-text");
                c && (c.innerHTML = `${"&nbsp;"!==s?""===s||""===s.trim()?"&nbsp;":s:n}`);
                const y = o.filter((e => i >= parseFloat(e.minSpend))).map((e => e.tierId));
                if (Array.from(r.querySelectorAll(".bmsm-icon-container")).forEach((e => {
                        const t = parseFloat(e.getAttribute("id"));
                        y && y.includes(t) ? e.style.border = `2px solid ${applyColor(m.progressIndicatorColor)}` : e.style.border = `2px solid ${applyColor(m.timelineColor)}`
                    })), "xsmall1" === m.template || "xsmall2" === m.template || "xsmall3" === m.template) {
                    const e = m.milestoneFontSize && !isNaN(parseFloat(m.milestoneFontSize.replace("px", ""))) ? parseFloat(m.milestoneFontSize.replace("px", "")) : 12,
                        t = m.fontSize && !isNaN(parseFloat(m.fontSize.replace("px", ""))) ? parseFloat(m.fontSize.replace("px", "")) : 12,
                        o = parseFloat(m.timelineHeight.replace("px", "")) || 10;
                    r.querySelectorAll(".bmsm-nudge-text").forEach((i => {
                        const n = parseInt(window.getComputedStyle(i).lineHeight, 10),
                            s = Math.round(i.scrollHeight / n);
                        let l = 0;
                        s > 1 && (l = i.offsetHeight / s), r.querySelectorAll(".bmsm-milestone-xsvalue").forEach((i => {
                            const n = parseInt(window.getComputedStyle(i).lineHeight, 10),
                                s = Math.round(i.scrollHeight / n);
                            let r = 0;
                            s > 1 && (r = i.offsetHeight / s), "xsmall2" === m.template && (i.style.top = s > 1 ? `calc(${t+l+5}px)` : `calc(${t+l+e+5}px)`), "xsmall3" === m.template && (i.style.top = s > 1 ? `calc(${l+r/2+10+1.8*t+(o-e*s*1.2)/2-7}px)` : `calc(${l+10+1.8*t+(o-1.2*e)/2-7}px)`), "xsmall1" === m.template && (i.style.top = `calc(${10+t+l+o+e}px)`), "mesarey.myshopify.com" == window.Shopify.shop && (i.style.top = "calc(34.6px)")
                        }))
                    }))
                }
                if (m.backgroundColor && (d.style.backgroundColor = applyColor(m.backgroundColor), a.style.backgroundColor = applyColor(m.backgroundColor), r.style.backgroundColor = applyColor(m.backgroundColor)), "bmsm-cartDrawerBlock" === e) {
                    let e = document.getElementById("bmsm-cartDrawerBlock");
                    window.cartDrawerBlock = e.innerHTML.trim()
                }
                return
            }
        }
        0 === l[e.replace(/^bmsm-/, "")].nometaobjects && (d.innerHTML = "");
        const k = document.createElement("div");
        k.classList.add("bmsm-tier-timeline"), k.id = t.discountId, isMobileDeviceKai() && "2b2641-3.myshopify.com" === window.Shopify.shop && "bmsm-cartDrawerBlock" === e ? k.style.marginBottom = "30px" : k.style.marginBottom = "10px", "desinoor-in.myshopify.com" === window.Shopify.shop && (k.style.marginBottom = null, k.style.marginTop = "10px");
        const $ = document.querySelector(".product-form__buttons");
        if ($ && "bmsm-productPageBlock" === e) {
            const e = window.getComputedStyle($).getPropertyValue("max-width");
            k.style.maxWidth = e
        } else k.style.width = "100%";
        isMobileDeviceKai() && "dafna-beauty.myshopify.com" === window.Shopify.shop && "cart" === a && "bmsm-cartDrawerBlock" === e && (k.style.width = "88%");
        const E = document.createElement("div");
        E.classList.add("bmsm-nudge-text"), E.innerHTML = `${"&nbsp;"!==s?""===s||""===s.trim()?"&nbsp;":s:n}`, E.style.color = applyColor(m.textColor), E.style.fontFamily = m.font || "Arial", E.style.fontSize = m.fontSize || "16px", isMobileDeviceKai() && "2b2641-3.myshopify.com" === window.Shopify.shop && (E.style.fontSize = "14px");
        const T = 1.5 * parseFloat(m.iconSize.replace("px", "")) || 36,
            q = (parseFloat(m.fontSize.replace("px", "")), m.milestoneFontSize && !isNaN(parseFloat(m.milestoneFontSize.replace("px", ""))) ? parseFloat(m.milestoneFontSize.replace("px", "")) : 12),
            B = parseFloat(m.timelineHeight.replace("px", "")) || 10;
        E.style.marginBottom = `calc(${q+T/2+5}px)`, "small" !== m.template && "xsmall" !== m.template && "xsmall1" !== m.template && "xsmall2" !== m.template && "xsmall3" !== m.template || ("small" === m.template && (E.style.marginBottom = `calc(${T/2-B/2+5}px)`, k.style.paddingBottom = `calc(${T/2-B/2+5}px)`), "xsmall" === m.template && (E.style.marginBottom = "10px", k.style.paddingBottom = "10px"), "xsmall1" === m.template && (E.style.marginBottom = "10px", k.style.paddingBottom = `calc(${2*q+10}px)`), "xsmall2" === m.template && (E.style.marginBottom = `calc(${2*q+5}px)`, k.style.paddingBottom = "5px"), "xsmall3" === m.template && (E.style.marginBottom = "10px", k.style.paddingBottom = "5px")), k.appendChild(E);
        const I = document.createElement("div");
        I.classList.add("bmsm-progress-bar"), I.style.backgroundColor = applyColor(m.timelineColor), "bmsm-promoBar" === e && (I.style.width = "90%"), "langhans-suppenmanufaktur.myshopify.com" == window.Shopify.shop && "bmsm-promoBar" === e && (I.style.width = "70%"), "cart" === a && "bmsm-cartDrawerBlock" === e && (I.style.width = "100%"), "Impulse" === window.Shopify.theme.schema_name && (I.style.width = "90%", "bmsm-promoBar" === e && (d.style.marginTop = "20px"), "cart" === a && "bmsm-cartDrawerBlock" === e && (d.style.marginTop = "40px")), "iijki2-zc.myshopify.com" === window.Shopify.shop && "cart" === a && "bmsm-cartDrawerBlock" === e && (I.style.width = "90%"), "d06409-1b.myshopify.com" === window.Shopify.shop && (isMobileDeviceKai() ? k.style.width = "95%" : k.style.width = "97%"), "materiales-didacticos-chile.myshopify.com" === window.Shopify.shop && (k.style.width = "90%"), "Palo Alto" === window.Shopify.theme.schema_name && (I.style.width = "95%");
        const M = o[0].cssConfig || {};
        if (M) {
            const t = isMobileDeviceKai() ? "Mobile" : "Desktop",
                o = e.replace("bmsm-", ""),
                i = M[o];
            let n = null;
            if ("cartDrawerBlock" === o) {
                n = i ? .["cart" === a ? "Cart" : "Cart Drawer"] ? .[t]
            } else n = i ? .[t];
            if (n) {
                const {
                    width: e,
                    marginTop: t,
                    marginBottom: o
                } = n;
                null != e && "" !== e && (I.style.width = e), e !== t && null !== t && "" !== t && (k.style.marginTop = t), null != o && "" !== o && (k.style.marginBottom = o)
            }
        }
        I.style.height = m.timelineHeight || "10px", I.style.display = "block", k.appendChild(I);
        const A = document.createElement("div");
        A.classList.add("bmsm-progress-indicator"), A.style.width = `${C}%`, A.style.backgroundColor = applyColor(m.progressIndicatorColor), A.style.height = m.timelineHeight || "10px", A.style.display = "block", I.appendChild(A);
        let F = 0,
            L = "0% 0%";
        o.forEach(((e, t) => {
            let i = S + (parseFloat(e.minSpend) - h) / _ * v;
            f && (i = y / o.length * (t + 1));
            const n = e.iconSVG ? 1.5 * parseFloat(m.iconSize.replace("px", "")) || 36 : 10,
                s = d.parentElement,
                l = s.parentElement;
            let a = s.clientWidth;
            0 === a && s && isHidden(s) && (a = getHiddenElementWidth(s)), 0 === a && l && isHidden(l) ? a = getHiddenElementWidth(l) : 0 === a && l && (a = .9 * l.clientWidth), 0 === a && (a = isMobileDeviceKai() ? 259 : 369), "Impulse" === window.Shopify.theme.schema_name && (a *= .9);
            const c = a - n / 2,
                p = i / 100 * a,
                w = Math.min(Math.max(p, 0), c);
            let b = w / a * 100;
            b < 0 && (b = i), g === h && (i = y);
            let C = 0 === t ? 0 : S + (parseFloat(o[t - 1].minSpend) - h) / _ * v;
            f && (C = 0 === t ? 0 : y / o.length * t);
            const $ = C / 100 * a;
            let T = Math.min(Math.max($, 0), c) / a * 100,
                q = t === o.length - 1 ? 100 : S + (parseFloat(o[t + 1].minSpend) - h) / _ * v;
            f && (q = t === o.length - 1 ? 100 : y / o.length * (t + 2));
            const B = q / 100 * a;
            Math.min(Math.max(B, 0), c);
            const M = m.milestoneFontSize && !isNaN(parseFloat(m.milestoneFontSize.replace("px", ""))) ? parseFloat(m.milestoneFontSize.replace("px", "")) : 12,
                A = e.iconSVG ? parseFloat(m.timelineHeight.replace("px", "")) || 24 : 10,
                P = e.iconSVG ? `calc(-${M+4}px)` : `calc(-${M+A/2+4}px)`,
                j = e.iconSVG ? `calc(${M+A+18}px)` : `calc(${M+A+8}px)`;
            let z;
            0 === M ? (z = `calc(-${n/2}px)`, E.style.marginBottom = `calc(${n/2}px)`) : z = `calc(-${M+n/2}px)`;
            const D = t > 0 ? o[t - 1] : null,
                H = t < o.length - 1 ? o[t + 1] : null;
            let G = S + (parseFloat(e.minSpend) - h) / _ * a,
                N = D ? S + (parseFloat(D.minSpend) - h) / _ * a : 0,
                V = H ? S + (parseFloat(H.minSpend) - h) / _ * a : a;
            f && (G = a / o.length * (t + 1), N = D ? a / o.length * t : 0, V = H ? a / o.length * (t + 2) : a);
            const U = G - N,
                W = V - G;
            let O = .3 * (U + W);
            D || (O = .1 * a + .3 * W), H || (O = .3 * U + .1 * a), O > 90 && (O = 90), u && (b = 100 - b);
            const R = document.createElement("div");
            R.classList.add("bmsm-tier-milestone"), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && "200" == e.minSpend && (b += 4), R.style.left = `${b}%`, R.style.top = z, "small" !== m.template && "xsmall" !== m.template || (R.style.top = `${P}`), R.id = e.tierId;
            const J = document.createElement("div");
            if (J.classList.add("bmsm-milestone-trigger"), J.style.fontSize = m.milestoneFontSize || "12px", J.style.color = applyColor(m.milestoneTextColor), J.id = e.tierId, "0px" === m.milestoneFontSize && (J.style.display = "none"), "e58605.myshopify.com" === window.Shopify.shop && (J.style.marginBottom = "5px"), J.innerText = "value" === r ? formatMoney1(parseFloat(e.minSpend), 0) : `${e.minSpend}`, "7e580f-2.myshopify.com" === window.Shopify.shop && (J.innerHTML = "&nbsp;"), R.appendChild(J), e.iconSVG) {
                const s = document.createElement("div");
                s.classList.add("bmsm-icon-container"), s.style.width = n || "24px", s.style.height = n || "24px", s.style.top = P, s.style.border = `2px solid ${applyColor(x>=i?m.progressIndicatorColor:m.timelineColor)}`, s.id = e.tierId, s.innerHTML = e.iconSVG, s.dataset.minspend = e.minSpend, "thetotelibrary.myshopify.com" === window.Shopify.shop && document.addEventListener("click", (function(e) {
                    const t = e.target.closest(".bmsm-icon-container");
                    if (!t) return;
                    const o = Number(t.dataset.minspend);
                    let i = "";
                    120 === o ? i = "https://thetotelibrary.com/products/tote-bag-insert" : 150 === o ? i = "https://thetotelibrary.com/products/the-mini-tote" : 200 === o && (i = "https://thetotelibrary.com/products/coastal-carryall-tote-bag"), i && (e.preventDefault(), e.stopPropagation(), window.location.href = i)
                }));
                var K = !1;
                if (e.iconURL && "" !== e.iconURL) {
                    K = !0;
                    var Q = m.iconSize || "24px",
                        Y = "50%";
                    "pectiv-ksa.myshopify.com" == window.Shopify.shop && (Y = "22%"), s.innerHTML = `\n                        <img \n                          src="${e.iconURL}" \n                          alt="Free surprise" \n                          style="width:${Q}; height:${Q}; border-radius:${Y};" \n                        />\n                      `
                }
                if ("c2d5db-7b.myshopify.com" == window.Shopify.shop && ("free_shipping" == e.tierType ? s.innerHTML = '<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" width="26" height="26" xmlns:v="https://vecta.io/nano"><path d="M89.093 59.853l2.419-.011 7.999-.019 5.747-.02 18.859-.041 6.509-.012 30.598-.042 35.23-.077 27.285-.048 16.269-.036 15.331-.017 5.592-.02c14.497-.102 28.412 1.233 41.444 8.24l1.996 1.037C310.137 71.879 315.165 75.589 320 80l1.844 1.566c12.522 11.355 21.058 30.011 22.33 46.717.295 6.52.264 13.045.258 19.571l.031 6.567.043 17.724.06 18.562.095 35.103.116 39.983L345 348l1.248-1.88 1.637-2.462 1.623-2.442c9.162-13.603 24.261-22.821 40.215-26.321 19.298-3.65 38.597-.388 55.277 10.105 7.732 5.808 15.643 13.285 20 22l.155-42.405.071-19.693.058-19.024.033-7.238.023-10.18.033-2.986c-.071-16.217-6.251-30.716-17.373-42.474-16.825-15.916-39.344-18.434-61.186-22.5l-7.846-1.5-2.374-.43c-5.851-1.149-12.205-2.837-16.251-7.465-2.294-5.215-3.541-9.532-1.648-15.18 2.12-4.818 4.349-7.763 9.305-9.926 7.644-.706 14.979.463 22.449 1.977l3.201.629 6.663 1.337 10.044 1.975C434.02 156.6 453.645 163.853 471 181l1.984 1.766c14.467 13.139 23.045 35.136 24.386 54.361.187 4.224.172 8.444.148 12.671l.021 4.796-.002 12.847.006 13.512-.021 22.641.007 26.147.01 22.534.006 13.424-.02 12.591.005 4.612-.023 6.303-.005 3.559c-.74 4.756-2.984 7.902-6.566 11.049-4.231 2.593-8.339 2.304-13.125 2.25l-2.271-.014L470 406l-.32 2.121c-3.237 13.712-14.633 25.942-26.152 33.422-18.691 10.776-38.727 13.02-59.527 7.457-18.1-5.975-31.428-17.232-40.441-33.836-1.312-2.663-2.456-5.408-3.559-8.164l-138-1-1 5c-7.098 16.629-19.6 28.8-36.199 35.938-18.08 6.859-36.975 6.898-55.051-.187C91.396 438.445 79.308 425.64 72 407l-1.706-.018-17.618-.245-6.57-.084-9.458-.142-2.955-.019c-5.294-.114-9.135-.499-13.693-3.492-3.505-3.884-5.123-6.263-5.134-11.452l-.014-2.855.001-3.158-.011-3.339-.019-11.153-.02-7.967-.039-23.976-.015-11.299-.039-37.581-.006-9.758-.001-2.45-.066-39.215-.054-40.291-.036-22.609-.02-19.273-.017-9.818c-.083-16.631.307-31.598 8.553-46.495l1.158-2.136C28.196 91.157 33.216 85.567 39 80l1.949-2.008C53.427 65.92 72.056 59.849 89.093 59.853zm-34.304 48.546c-6.754 9.822-8.945 18.915-8.909 30.542l-.003 3.057.009 10.152v7.273l.008 15.664.012 22.648.018 36.745.021 35.692.001 2.223.004 11.039L46 375h23l1.563-7.625C74.403 350.349 83.3 335.759 98 326c18.357-10.508 38.022-14.086 58.727-8.969 9.108 2.695 16.391 6.356 23.898 12.199 2.246 1.805 2.246 1.805 4.563 2.758 2.343 1.308 2.726 2.595 3.813 5.012a154.6 154.6 0 0 0 3.25 3.938C200.3 351.214 202.814 362.254 206 375h107l.195-86.455.024-17.506.003-2.216.086-35.362.068-36.324.047-20.389.03-19.209.024-7.032c.1-16.094-.298-29.252-10.477-42.507l-1.75-2.625c-7.999-8.443-19.108-14.065-30.781-14.509l-4.158-.013-2.324-.011-7.698-.019-5.525-.02-18.139-.041-6.256-.012-29.401-.042-33.879-.077-26.222-.048-15.643-.036-14.735-.017a675.5 675.5 0 0 1-5.382-.02c-18.059-.131-34.157 3.326-46.317 17.889zm54.086 248.789c-8.22 9.525-9.614 19.641-9.05 31.825.853 9.697 6.308 17.718 13.464 23.995 8.876 6.735 18.654 9.162 29.711 7.992 11.267-2.156 19.477-7.916 26.125-17.187 5.821-9.091 7.296-18.833 5.406-29.445-2.623-9.961-7.972-18.527-16.531-24.367-16.617-8.979-35.998-6.686-49.125 7.188zm268 0c-8.22 9.525-9.614 19.641-9.05 31.825.853 9.697 6.308 17.718 13.464 23.995 8.876 6.735 18.654 9.162 29.711 7.992 9.291-1.778 16.673-5.97 23-13l2.063-2.187c6.444-9.354 8.406-20.35 6.477-31.469-2.677-9.951-7.969-18.495-16.539-24.344-16.617-8.979-35.998-6.686-49.125 7.188zm-126.75-182.063c4.286 2.795 7.224 5.923 8.875 10.875.664 6.774-1.289 11.634-5.504 16.868-1.78 1.926-3.612 3.778-5.48 5.618l-2.105 2.122-6.875 6.853-4.79 4.794-10.034 10-12.845 12.832-9.891 9.877-4.735 4.734-6.627 6.592-1.967 1.98c-5.076 4.993-8.682 6.897-15.987 7.092-5.389-.906-9.241-4.066-13.016-7.815l-2.76-2.722-2.927-2.936-3.047-3.031-6.351-6.355-8.13-8.092-6.277-6.265-2.999-2.98c-11.03-10.912-11.03-10.912-11.938-18.574.633-5.951 2.69-9.709 7.285-13.594 3.001-1.85 5.364-2.32 8.875-2.375l2.492-.086c6.659 1.166 11.456 7.017 16 11.633l2.059 2.068 6.448 6.51 4.398 4.426L173 236c6.186-5.055 11.747-10.671 17.342-16.358l5.174-5.234 14.697-14.867 9.03-9.124 3.416-3.467 4.793-4.839 2.742-2.778c5.987-4.976 12.365-6.931 19.932-4.207z"/></svg>' : "percentage" == e.tierType ? s.innerHTML = '<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" width="26" height="26" xmlns:v="https://vecta.io/nano"><path d="M295.602 45.891c2.589 2.26 5.008 4.644 7.398 7.109l6.618 6.76 4.612 4.769c11.056 11.339 21.1 14.48 36.594 14.709l12.338.067c20.402-.022 36.36 5.064 51.557 19.323 10.953 11.385 17.515 26.301 17.625 42.078l.044 2.443.112 7.663c.245 25.464.245 25.464 14.273 46.141l8.271 7.859c13.732 12.911 22.913 27.991 24.158 47.344.252 17.941-4.632 34.925-17.309 48.023L459 303l-6.76 6.618-4.769 4.612c-12.16 11.856-14.542 22.706-14.78 39.134l-.072 10.024c-.079 20.169-5.214 37.302-19.729 51.952-15.327 14.105-32.366 16.907-52.266 17.16-18.342.235-31.977.414-45.578 14.273l-7.859 8.271c-12.96 13.783-27.884 22.682-47.239 24.193-18.146.413-34.646-4.654-48.023-17.309l-7.195-7.297-2.355-2.395-4.605-4.766c-12.481-12.798-24.15-14.616-41.304-14.856l-7.358-.072c-20.476-.186-37.656-4.761-52.453-19.634-10.561-11.571-16.691-25.53-16.902-41.227l-.1-5.006-.131-7.832c-.303-19.07-1.606-31.505-15.904-45.356l-6.664-6.302c-13.732-12.911-22.913-27.991-24.158-47.344-.252-17.941 4.632-34.925 17.309-48.023L53 209l6.76-6.618 4.769-4.612c12.16-11.856 14.542-22.706 14.78-39.134l.072-10.024c.08-20.474 5.178-36.783 19.748-51.807 11.184-10.524 25.866-16.845 41.188-17.051l5.006-.1 7.832-.131c19.07-.303 31.505-1.606 45.356-15.904l6.302-6.664c24.194-25.732 61.103-32.639 90.79-11.064zM230 79c-20.787 21.128-37.241 32.116-67.375 32.5-22.272-.154-22.272-.154-41.441 10.098-8.037 8.521-9.283 19.541-9.395 30.758l-.086 4.826-.104 7.49c-.27 23.515-6.803 39.878-23.599 56.329l-4.152 4.016-2.152 2.1-4.176 3.978c-7.175 6.932-11.093 14.609-11.77 24.594.275 14.619 9.797 23.123 19.688 32.688l2.775 2.672c7.501 7.345 13.736 14.892 18.1 24.516l1.426 3.066c3.796 10.142 3.626 20.069 3.762 30.746-.154 22.272-.154 22.272 10.098 41.441 8.521 8.037 19.541 9.283 30.758 9.395l4.826.086 7.49.104c23.515.27 39.878 6.803 56.329 23.599l4.016 4.152 2.1 2.152 3.978 4.176c6.661 6.895 14.74 11.528 24.469 11.832 11.434-.201 18.688-5.425 26.438-13.312 20.787-21.128 37.241-32.116 67.375-32.5 22.272.154 22.272.154 41.441-10.098 8.091-8.577 9.297-19.658 9.359-30.941l.072-4.949.078-7.68c.145-23.007 7.344-39.687 23.674-55.832l4.156-4.023 2.151-2.096 4.173-3.973c7.175-6.933 11.093-14.609 11.77-24.594-.275-14.619-9.797-23.123-19.687-32.687l-2.775-2.672c-7.506-7.349-13.775-14.955-18.1-24.578l-1.426-3.102c-2.598-6.74-3.555-12.826-3.605-19.98l-.044-2.443-.112-7.663c.218-22.567.218-22.567-10.098-42.004-8.521-8.037-19.541-9.283-30.758-9.395l-4.826-.086-7.49-.104c-23.515-.27-39.878-6.803-56.329-23.599l-4.016-4.152-2.1-2.152-3.978-4.176c-6.661-6.895-14.74-11.528-24.469-11.832C245.004 65.889 237.75 71.113 230 79zm101.313 200.313c10.25 7.741 18.705 17.592 20.688 30.688 1.281 14.14.381 27.025-8.25 38.875-8.377 9.734-18.747 18.039-31.99 19.346-16.739.801-28.696-1.895-41.725-12.877-8.629-8.006-13.702-18.292-14.352-30-.559-16.687 3.106-28.674 14.629-41.094 16.295-15.422 42.416-17.271 61-4.937zm-40.687 32.313c-2.204 4.578-2.422 8.381-1.625 13.375 2.33 4.839 5.161 7.67 10 10 4.994.797 8.797.579 13.375-1.625 3.584-3.243 6.22-5.84 7.008-10.773.256-5.684-.447-9.251-4.383-13.602-4.351-3.936-7.918-4.639-13.602-4.383-4.934.787-7.531 3.424-10.773 7.008zm-55.313-160.313C245.951 159.326 253.352 168.688 256 182c1.489 14.779-.002 27.633-9.156 39.754C239.353 230.88 229.965 238.189 218 240c-14.14 1.281-27.025.381-38.875-8.25-9.734-8.377-18.039-18.747-19.346-31.99-.801-16.739 1.895-28.696 12.877-41.725 15.889-17.126 43.436-19.479 62.656-6.723zm-40.687 32.313c-2.204 4.578-2.422 8.381-1.625 13.375 2.33 4.839 5.161 7.67 10 10 4.994.797 8.797.579 13.375-1.625 3.584-3.243 6.22-5.84 7.008-10.773.256-5.684-.447-9.251-4.383-13.602-4.351-3.936-7.918-4.639-13.602-4.383-4.934.787-7.531 3.424-10.773 7.008zM322 180c4.885 2.268 7.732 5.115 10 10 1.008 7.487.471 11.839-4 18a149.32 149.32 0 0 1-5.059 5.333l-1.503 1.519-4.965 4.981-3.569 3.594-9.682 9.718-6.057 6.074-21.152 21.193-19.679 19.754-16.923 16.974-10.095 10.133-9.505 9.517-3.473 3.494c-11.704 11.856-11.704 11.856-20.808 13.037-6.46-.621-10.363-3.409-14.531-8.32-2.575-4.738-2.487-9.872-1-15 2.628-4.285 5.538-7.789 9.086-11.34l1.511-1.521 4.993-4.988 3.588-3.599 9.731-9.73 10.188-10.191 17.109-17.098 19.775-19.778 16.984-16.989 10.141-10.144 9.534-9.525 3.497-3.5 4.777-4.766 2.699-2.697c5.585-4.996 11.135-4.912 18.386-4.135z"/></svg>' : "free_gift" == e.tierType && (s.innerHTML = '<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" width="26" height="26" xmlns:v="https://vecta.io/nano"><path d="M247 57c2.814 2.542 5.453 5.191 8 8 3.465-1.483 5.604-3.47 8.25-6.125C272.282 50.603 284.027 45.358 296 43l3.375-.687C319.145 40.608 337.273 44.621 353 57l2.305 1.77C368.251 69.409 376.798 85.461 379 102c1.027 14.153-.006 26.902-6.117 39.879l-1.636 3.49L370 148l2.135.004 20.034.128 10.297.063 11.871.097 3.688-.012c9.011.153 15.728 2.07 22.632 8l1.844 2.219 1.906 2.219c3.582 5.127 3.895 9.83 3.9 15.952l.025 2.614.039 8.54.027 5.96.027 12.496.089 15.954.038 12.315.038 5.878c.114 11.59.181 20.752-7.652 30.01C432.8 277 432.8 277 427 277l.011 2.035.196 49.211.095 23.799.075 20.763.047 10.976c.226 29.292.226 29.292-4.423 41.217l-.834 2.242c-6.987 17.191-20.207 29.502-36.733 37.321-9.879 4.136-19.727 5.589-30.375 5.578l-2.659.009-8.785.012-6.314.015-17.133.024-10.719.012-33.579.027-38.682.051-29.95.033-17.863.025-16.823.01a1174.95 1174.95 0 0 0-6.144.013c-20.537.094-38.748-2.188-55.407-15.371l-2.527-1.957C95.554 442.314 87.603 426.506 85 410c-.271-4.412-.253-8.811-.227-13.231l-.001-3.935.025-10.603.016-11.111.043-21.004.043-23.928L85 277l-2.863-.423c-5.67-1.043-9.567-4.922-13.45-9.015-4.096-6.221-5.132-11.19-5.092-18.492l-.021-2.624-.009-8.536-.016-5.966.003-12.485-.038-15.961-.012-12.315-.018-5.883.013-8.241-.029-2.43c.093-7.155 2.601-13.274 7.719-18.379l1.543-1.609c7.856-5.679 15.341-6.24 24.836-6.25l3.863-.05 10.076-.079 10.318-.102L142 148l-1.247-2.631-1.636-3.49-1.622-3.443c-6.967-16.006-6.58-35.228-.496-51.436 7.787-18.591 20.332-31.956 38.789-40.254C199.738 37.394 226.525 41.682 247 57zm-73.375 31.688C166.7 98.093 164.73 107.414 166 119c1.937 9.248 6.912 17.06 14.391 22.852 8.713 5.562 17.522 7.624 27.773 7.441l2.782-.013 8.679-.093 5.934-.041L240 149l.11-15.149.041-5.138c.373-22.644.373-22.644-10.264-42.038-8.362-7.814-17.984-12.259-29.539-11.922-10.499 1.101-19.866 5.934-26.723 13.934zm106.063 1.125c-6.677 9.589-7.862 19.687-7.785 31.063l.004 2.454.031 7.671.014 5.238L272 149l17.395.165 5.906.062 8.535.067 2.628.047c11.169.003 21.75-3.653 29.802-11.566 7.605-8.873 10.517-17.691 10.109-29.352C345.297 98.587 341.03 90.909 334 84c-7.534-5.835-16.867-9.754-26.52-9.344-11.567 1.603-20.43 6.09-27.793 15.156zM96 182v63h144v-63H96zm176 0v63h144v-63H272zm-154 96l-.195 45.318-.106 27.737-.075 20.204-.047 10.687-.031 11.963-.044 3.535c.055 11.082 2.992 19.882 10.232 28.329 3.658 3.595 7.568 6.183 12.266 8.227l1.743.768c9.282 3.424 19.184 2.606 28.922 2.525l5.331-.009 19.63-.096L240 437V278H118zm154 0v159l44.375.188 13.962.083 8.329.016 5.524.03c14.216.347 14.216.347 27.81-3.317l2.883-1.254C385.209 426.719 390.882 418.437 394 407c.517-4.375.508-8.689.454-13.091l.002-3.818-.05-10.256-.032-10.758-.085-20.324-.098-27.498L394 278H272z" fill="#03061d"/></svg>')), "pie-me-cafe.myshopify.com" == window.Shopify.shop && ("30" == e.minSpend ? s.innerHTML = "<img src=https://cdn.shopify.com/s/files/1/0708/6089/8478/files/free-surprise_y7v0hz.png?v=1758883255\n                        alt= Free surprise\n                        style= width:45px;height:45px;border-radius:50%;>" : "49" == e.minSpend ? s.innerHTML = "<img src=https://cdn.shopify.com/s/files/1/0708/6089/8478/files/free-mash_18pbnhq.png?v=1758883257\n                        alt= Free surprise\n                       style= width:45px;height:45px;border-radius:50%;>" : "69" == e.minSpend ? s.innerHTML = "<img src=https://cdn.shopify.com/s/files/1/0708/6089/8478/files/free-bun_flhjxi.png?v=1758883257\n                        alt= Free surprise\n                      style= width:45px;height:45px;border-radius:50%;>" : "89" == e.minSpend && (s.innerHTML = "<img src=https://cdn.shopify.com/s/files/1/0708/6089/8478/files/free-pie_3lvic4.png?v=1758883257\n                        alt= Free surprise\n                      style= width:45px;height:45px;border-radius:50%;>")), "pectiv-4913.myshopify.com" == window.Shopify.shop && "180" == e.minSpend && (s.innerHTML = "<img src=https://cdn.shopify.com/s/files/1/0708/6089/8478/files/pouch_1s45mr9_1.png?v=1759935002\n\n                        style= width:30px;height:30px;border-radius:22%;>"), "pie-me-cafe.myshopify.com" !== window.Shopify.shop && "pectiv-4913.myshopify.com" !== window.Shopify.shop && !K) {
                    const e = s.querySelector("svg");
                    e.setAttribute("width", m.iconSize || "24px"), e.setAttribute("height", m.iconSize || "24px"), "2b2641-3.myshopify.com" == window.Shopify.shop && (e.style.position = "relative"), e.querySelectorAll("path").forEach((e => {
                        m.iconFillColor && e.setAttribute("fill", applyColor(m.iconFillColor)), m.iconStrokeColor && e.setAttribute("stroke", applyColor(m.iconStrokeColor)), m.iconStrokeWidth && e.setAttribute("stroke-width", m.iconStrokeWidth)
                    }))
                }
                if ("49" == e.minSpend && "pectiv-4913.myshopify.com" == window.Shopify.shop) {
                    const e = s.querySelector("svg");
                    e.setAttribute("width", m.iconSize || "24px"), e.setAttribute("height", m.iconSize || "24px"), e.querySelectorAll("path").forEach((e => {
                        m.iconFillColor && e.setAttribute("fill", applyColor(m.iconFillColor)), m.iconStrokeColor && e.setAttribute("stroke", applyColor(m.iconStrokeColor)), m.iconStrokeWidth && e.setAttribute("stroke-width", m.iconStrokeWidth)
                    }))
                }
                let r;
                if ("xsmall" === m.template || "xsmall1" === m.template || "xsmall2" === m.template || "xsmall3" === m.template) {
                    const i = 5,
                        n = w / a * 100,
                        s = (w + i) / a * 100,
                        l = i / a * 100,
                        c = (parseFloat(m.iconSize.replace("px", "")), m.milestoneFontSize && !isNaN(parseFloat(m.milestoneFontSize.replace("px", ""))) ? parseFloat(m.milestoneFontSize.replace("px", "")) : 12),
                        p = m.fontSize && !isNaN(parseFloat(m.fontSize.replace("px", ""))) ? parseFloat(m.fontSize.replace("px", "")) : 12,
                        d = parseFloat(m.timelineHeight.replace("px", "")) || 10;
                    if (t !== o.length - 1 && (L += `, ${n}% 0%, ${n}% 100%, ${s}% 100%, ${s}% 0%`), "xsmall1" === m.template || "xsmall2" === m.template || "xsmall3" === m.template) {
                        let i;
                        r = document.createElement("div"), r.classList.add("bmsm-milestone-xsvalue"), i = "xsmall1" === m.template ? `calc(${10+p+d+c}px)` : "xsmall2" === m.template ? `calc(${p+c+5}px)` : "xsmall3" === m.template ? `calc(${10+1.8*p+(d-1.2*c)/2-7}px)` : "0px", r.style.position = "absolute", r.style.fontSize = m.milestoneFontSize || "12px", r.style.color = applyColor(m.milestoneTextColor), r.style.top = i;
                        const n = (100 - parseFloat(I.style.width || "95%")) / 2;
                        if (u) {
                            r.style.right = 0 === t || t === o.length - 1 ? `${T+n}%` : `${T+n+2*l}%`;
                            const e = 0 === t ? 100 - b + 2 * l : t === o.length - 1 ? 100 - T - 2 * n - 2 * l : 100 - b - T - 2 * l,
                                i = t === o.length - 1 && "albayan-perfume.myshopify.com" === window.Shopify.shop ? e + 10 : e;
                            r.style.width = `${i}%`
                        } else r.style.left = 0 === t ? `${T+n}%` : `${T+l}%`, r.style.width = `${0===t?b:b-T-l}%`;
                        r.style.textAlign = "center", r.style.display = "flex", r.style.alignItems = "center", r.style.justifyContent = "center", r.id = e.tierId, "amount" === e.tierType ? r.innerText = null !== e.discountLabel && void 0 !== e.discountLabel ? e.discountLabel.replace("{Value}", formatMoney1(parseFloat(e.value), 0)) : formatMoney1(parseFloat(e.value), 0) + ` ${e.amountsuffix||"off"}` : "percentage" === e.tierType ? r.innerText = null !== e.discountLabel && void 0 !== e.discountLabel ? e.discountLabel.replace("{Value}", `${roundup(e.value)}%`) : `${roundup(e.value)}% ${e.amountsuffix||"off"}` : "free_shipping" === e.tierType ? r.innerText = e.freeshippingname ? ? "Free Shipping" : "free_gift" === e.tierType ? r.innerText = e.freegiftname ? ? "Free Gift" : "bogo" === e.tierType && (r.innerText = null !== e.freegiftname && void 0 !== e.freegiftname ? e.freegiftname : `Buy ${parseFloat(e.minSpend)-parseFloat(e.noofgifts)} Get ${e.noofgifts} ${"100"===e.value?"Free":`@${e.value}%`}`), k.appendChild(r)
                    }
                }
                R.appendChild(s)
            }
            const Z = document.createElement("div");
            let X = (a - 20) / o.length;
            if (Z.classList.add("bmsm-milestone-value"), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && (X = 68), "my-qamis-homme.myshopify.com" != window.Shopify.shop && "2x4scx-is.myshopify.com" != window.Shopify.shop || (X = 125), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && "100" == e.minSpend && (X = 95), Z.style.maxWidth = t === o.length - 1 ? "75%" : `${X}px`, Z.style.fontSize = m.milestoneFontSize || "12px", Z.style.color = applyColor(m.milestoneTextColor), Z.style.top = j, "my-qamis-homme.myshopify.com" != window.Shopify.shop && "2x4scx-is.myshopify.com" != window.Shopify.shop || (Z.style.marginTop = "1px"), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && "200" == e.minSpend && (O = 68), "thetotelibrary.myshopify.com" == window.Shopify.shop && "200" == e.minSpend || "thetotelibrary.myshopify.com" == window.Shopify.shop && (Z.style.whiteSpace = "nowrap"), "my-qamis-homme.myshopify.com" != window.Shopify.shop && "2x4scx-is.myshopify.com" != window.Shopify.shop || (O = 125), "smaltosw.myshopify.com" == window.Shopify.shop && (O = 100), "iymt0v-hw.myshopify.com" == window.Shopify.shop && (O = 100), "confetti-gifts-co.myshopify.com" == window.Shopify.shop && (O = 115), "confetti-gifts-co.myshopify.com" == window.Shopify.shop && "3000" == e.minSpend && (O = 150), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && "100" == e.minSpend && (O = 95), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && "120" == e.minSpend && (O = 68), "thetotelibrary.myshopify.com" == window.Shopify.shop && "1" == final_cart_quantity_upsell && "150" == e.minSpend && (O = 68), Z.style.width = `${O}px`, "dafna-beauty.myshopify.com" === window.Shopify.shop && (Z.style.hyphens = "none"), "7e580f-2.myshopify.com" === window.Shopify.shop && (Z.style.width = "100%", Z.style.maxWidth = "100%"), "curvy-com.myshopify.com" === window.Shopify.shop && (Z.style.width = "100%", Z.style.maxWidth = "100%"), Z.id = e.tierId, "0px" === m.milestoneFontSize && (Z.style.display = "none"), "amount" === e.tierType) Z.innerText = null !== e.discountLabel && void 0 !== e.discountLabel ? e.discountLabel.replace("{Value}", formatMoney1(parseFloat(e.value), 0)) : formatMoney1(parseFloat(e.value), 0) + ` ${e.amountsuffix||"off"}`;
            else if ("percentage" === e.tierType) Z.innerText = null !== e.discountLabel && void 0 !== e.discountLabel ? e.discountLabel.replace("{Value}", `${roundup(e.value)}%`) : `${roundup(e.value)}% ${e.amountsuffix||"off"}`;
            else if ("free_shipping" === e.tierType) Z.innerText = e.freeshippingname ? ? "Free Shipping";
            else if ("free_gift" === e.tierType) {
                const t = e.freegiftname ? ? "Free Gift";
                if ("confetti-gifts-co.myshopify.com" === window.Shopify ? .shop) {
                    const e = t.match(/^(.*?)\s*(\(.*\))$/);
                    e ? Z.innerHTML = `\n                      <div>${e[1]}</div>\n                      <div>${e[2]}</div>\n                    ` : Z.innerText = t
                } else Z.innerText = t
            } else "bogo" === e.tierType && (Z.innerText = null !== e.freegiftname && void 0 !== e.freegiftname ? e.freegiftname : `Buy ${parseFloat(e.minSpend)-parseFloat(e.noofgifts)} Get ${e.noofgifts} ${"100"===e.value?"Free":`@${e.value}%`}`);
            R.appendChild(Z), I.appendChild(R);
            parseFloat(m.fontSize.replace("px", ""));
            F = n / 2
        }));
        const P = calculateAndShowEligibleGifts(i, p, o, t.discountId, t.variant_stock_array, t.tiers[0].replaceGifts ? ? !1);
        let j = "";
        if (P && P.length > 0) {
            const e = P.sort(((e, t) => parseInt(t.tier_id) - parseInt(e.tier_id))).find((() => !0)),
                t = `<a href="#" onclick="showGiftPopup('${encodeURIComponent(JSON.stringify(P))}')">`;
            j = null !== e.claimtext && void 0 !== e.claimtext ? e.claimtext.replace("<link>", t).replace("</link>", "</a>") : `Claim your Free Gift ${t}here</a>`
        }
        const z = document.createElement("div");
        switch (z.classList.add("bmsm-achievement-text"), "&nbsp;" == n && "mesarey.myshopify.com" == window.Shopify.shop && (n = ""), z.innerHTML = "&nbsp;" !== s ? freegiftpopup ? n + "<br/>" + j : n : freegiftpopup ? j : "&nbsp;", z.style.color = applyColor(m.textColor), z.style.fontFamily = m.font || "Arial", z.style.fontSize = m.fontSize || "16px", z.style.marginTop = `calc(${F}px)`, "chhapa.myshopify.com" == window.Shopify.shop && (z.style.marginTop = "calc(30px)"), "2b2641-3.myshopify.com" == window.Shopify.shop && (z.style.display = "none"), k.appendChild(z), m.template) {
            case "regular":
                break;
            case "medium":
                z.style.display = "none";
                break;
            case "small":
                z.style.display = "none", k.querySelectorAll(".bmsm-milestone-value, .bmsm-milestone-trigger").forEach((e => {
                    e.style.display = "none"
                }));
                break;
            case "xsmall1":
            case "xsmall2":
            case "xsmall3":
            case "xsmall":
                z.style.display = "none", L += ", 100% 0%, 100% 100%, 0% 100%";
                const e = k.querySelector(".bmsm-progress-bar");
                e && (e.style.clipPath = `polygon(${L})`), k.querySelectorAll(".bmsm-milestone-value, .bmsm-milestone-trigger, .bmsm-icon-container").forEach((e => {
                    e.style.display = "none"
                }));
                break;
            default:
                break
        }
        d.appendChild(k);
        const D = t.discountId;
        let H = D.match(/^\d/) ? `#\\3${D[0]} ${D.slice(1)}` : `#${D}`;
        const G = d.querySelector(`.bmsm-tier-timeline${H}`);
        if ("xsmall1" === m.template || "xsmall2" === m.template || "xsmall3" === m.template) {
            const t = m.milestoneFontSize && !isNaN(parseFloat(m.milestoneFontSize.replace("px", ""))) ? parseFloat(m.milestoneFontSize.replace("px", "")) : 12,
                o = m.fontSize && !isNaN(parseFloat(m.fontSize.replace("px", ""))) ? parseFloat(m.fontSize.replace("px", "")) : 12,
                i = parseFloat(m.timelineHeight.replace("px", "")) || 10;
            G.querySelectorAll(".bmsm-nudge-text").forEach((e => {
                const n = parseInt(window.getComputedStyle(e).lineHeight, 10),
                    s = Math.round(e.scrollHeight / n);
                let r = 0;
                s > 1 && (r = e.offsetHeight / s), G.querySelectorAll(".bmsm-milestone-xsvalue").forEach((e => {
                    const n = parseInt(window.getComputedStyle(e).lineHeight, 10),
                        s = Math.round(e.scrollHeight / n);
                    let l = 0;
                    s > 1 && e.offsetHeight, "xsmall2" === m.template && (e.style.top = s > 1 ? `calc(${o+r+5}px)` : `calc(${o+r+t+5}px)`), "xsmall3" === m.template && (e.style.top = s > 1 ? `calc(${r+10+1.8*o+(i-t*s*1.2)/2-7}px)` : `calc(${r+10+1.8*o+(i-1.2*t)/2-7}px)`), "xsmall1" === m.template && (e.style.top = `calc(${10+o+r+i+t}px)`)
                }))
            })), "woodentwist-ae.myshopify.com" === window.Shopify.shop && "bmsm-cartDrawerBlock" === e && "cart" !== a && 0 === window.bmsmcartlength && k.querySelectorAll(".bmsm-milestone-xsvalue").forEach((e => {
                "calc(34.6px)" === e.style.top && (e.style.top = "calc(63.6px)")
            })), "mesarey.myshopify.com" == window.Shopify.shop && k.querySelectorAll(".bmsm-milestone-xsvalue").forEach((e => {
                e.style.top;
                e.style.top = "calc(34.5px)"
            }))
        }
        const N = G.querySelector(".bmsm-achievement-text"),
            V = (N && N.innerHTML || "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
        if (G) {
            const e = G.querySelectorAll(".bmsm-milestone-value");
            let t = 0;
            const o = G;
            if (isHidden(o)) {
                const e = o.cloneNode(!0),
                    i = document.createElement("div");
                i.style.visibility = "hidden", i.style.position = "absolute", i.style.top = "-9999px", i.style.left = "-9999px", i.appendChild(e), document.body.appendChild(i);
                e.querySelectorAll(".bmsm-milestone-value").forEach((e => {
                    const o = e.offsetHeight;
                    o > t && (t = o)
                })), document.body.removeChild(i)
            } else e.forEach((e => {
                const o = e.offsetHeight;
                o > t && (t = o)
            }));
            F += t, "desinoor-in.myshopify.com" === window.Shopify.shop && (F += 5), "iymt0v-hw.myshopify.com" === window.Shopify.shop && (F -= 8), "thetotelibrary.myshopify.com" === window.Shopify.shop && (F -= 15), N.style.marginTop = `calc(${F}px)`;
            var w = "32.5px";
            if ("mesarey.myshopify.com" == window.Shopify.shop && (w = "0px"), "thetotelibrary.myshopify.com" == window.Shopify.shop && (w = N && N.parentElement && N.parentElement.parentElement && "bmsm-productPageBlock" === N.parentElement.parentElement.id ? "0px" : "25px"), "medium" === m.template && (G.style.paddingBottom = V ? `calc(${F}px)` : w), "medium" !== m.template || "w2vjns-k2.myshopify.com" != window.Shopify.shop && "yvxd2k-1p.myshopify.com" != window.Shopify.shop || (G.style.paddingBottom = "20px"), "medium" === m.template && "iymt0v-hw.myshopify.com" === window.Shopify.shop) {
                G.parentElement.style.paddingBottom = "70px", G.style.paddingBottom = "0"
            }
        }
        if (m.backgroundColor && (d.style.backgroundColor = applyColor(m.backgroundColor), N.style.backgroundColor = applyColor(m.backgroundColor), G.style.backgroundColor = applyColor(m.backgroundColor), window.cartDrawerBlockBG = m.backgroundColor), "bmsm-cartDrawerBlock" === e) {
            let e = document.getElementById("bmsm-cartDrawerBlock");
            window.cartDrawerBlock = e.innerHTML.trim()
        }
    }
}

function roundup(e) {
    return "d06409-1b.myshopify.com" === window.Shopify.shop || "63bfd6-5f.myshopify.com" === window.Shopify.shop ? Number(parseFloat(e).toFixed(2)) : Math.ceil(e)
}

function formatTierValue(e) {
    return "amount" === e.tierType ? null !== e.discountLabel && void 0 !== e.discountLabel ? e.discountLabel.replace("{Value}", formatMoney1(parseFloat(e.value), 0)) : formatMoney1(parseFloat(e.value), 0) + ` ${e.amountsuffix||"off"}` : "percentage" === e.tierType ? null !== e.discountLabel && void 0 !== e.discountLabel ? e.discountLabel.replace("{Value}", `${roundup(parseFloat(e.value))}%`) : `${roundup(parseFloat(e.value))}% ${e.amountsuffix||"off"}` : "free_shipping" === e.tierType ? e.freeshippingname ? ? "Free Shipping" : "free_gift" === e.tierType ? e.freegiftname ? ? "Free Gift" : "bogo" === e.tierType ? null !== e.freegiftname && void 0 !== e.freegiftname ? e.freegiftname : `Buy ${parseFloat(e.minSpend)-parseFloat(e.noofgifts)} Get ${e.noofgifts} ${"100"===e.value?"Free":`@${e.value}%`}` : void 0
}

function insertCartBlock(e, t) {
    if ("doukissa-nomikou.myshopify.com" !== window.Shopify.shop || !window.location.href.startsWith("https://www.doukissanomikou.com/apps/bundles/bundle/")) {
        if (t && !renderingdelay) {
            const i = window.activeMetaobjects.find((e => e ? .tiers ? .[0] ? .cssConfig));
            if (i) {
                const n = i.tiers[0].cssConfig ? .cartDrawerBlock ? .["Cart Drawer"] ? .className || {},
                    s = n ? .Empty;
                var o = n ? .Not_Empty;
                if (0 === e && s && "string" == typeof s) {
                    const e = document.querySelector(s);
                    return e && t && (e.insertAdjacentElement("afterbegin", t), t.style.display = "block"), !0
                }
                if (e > 0 && o && "string" == typeof o) {
                    const e = document.querySelector(o);
                    return e && t && (e.insertAdjacentElement("afterbegin", t), t.style.display = "block"), !0
                }
            }
            const n = document.querySelectorAll('form[action$="/cart"]:not([action*="/cart/add"]):not([id^="product"])'),
                s = document.querySelector('a[href^="/cart"]'),
                r = n[0],
                l = n[1];
            if (r) {
                const o = r.parentElement,
                    i = o.parentElement;
                if (0 === e)
                    if ("MINI-CART" === o.tagName) r.insertAdjacentElement("afterbegin", t), t.style.marginTop = "20px";
                    else if (r.id && r.id.includes("Cart") && r.id.includes("Drawer")) r.insertAdjacentElement("afterbegin", t);
                else if ("rustic-kandangi.myshopify.com" === window.Shopify.shop) {
                    r.querySelector(".drawer__scrollable").insertAdjacentElement("afterbegin", t)
                } else if ("d06409-1b.myshopify.com" === window.Shopify.shop) {
                    const e = r.querySelector(".quick-cart__header");
                    if (e && e.insertAdjacentElement("afterend", t), l) {
                        const e = l.querySelector(".quick-cart__header");
                        e && e.insertAdjacentElement("afterend", t)
                    }
                } else o && r.insertAdjacentElement("beforebegin", t);
                else if (r.id.includes("cart") && r.id.includes("notification")) i.insertAdjacentElement("afterbegin", t);
                else if (o.className.includes("bottom") || o.className.includes("button") || o.className.includes("notes") || o.className.includes("footer")) i.insertAdjacentElement("afterbegin", t);
                else if ("MINI-CART" === o.tagName) r.insertAdjacentElement("afterbegin", t), t.style.marginTop = "20px";
                else if ("rustic-kandangi.myshopify.com" === window.Shopify.shop) {
                    r.querySelector(".drawer__scrollable").insertAdjacentElement("afterbegin", t)
                } else if ("desinoor-in.myshopify.com" === window.Shopify.shop) r.insertAdjacentElement("afterbegin", t);
                else if ("3jpmpp-qz.myshopify.com" === window.Shopify.shop || "greenbev.myshopify.com" === window.Shopify.shop) {
                    document.querySelector(".hdt-mini-cart__wrap.hdt-flex.hdt-flex-col").insertAdjacentElement("beforebegin", t)
                } else if ("d06409-1b.myshopify.com" === window.Shopify.shop) {
                    const e = r.querySelector(".quick-cart__main-content");
                    e && e.insertAdjacentElement("afterbegin", t);
                    const o = r.querySelector(".purchase-confirmation-popup__header");
                    if (o && o.insertAdjacentElement("afterend", t), l) {
                        const e = l.querySelector(".quick-cart__main-content");
                        e && e.insertAdjacentElement("afterbegin", t);
                        const o = l.querySelector(".purchase-confirmation-popup__header");
                        o && o.insertAdjacentElement("afterend", t)
                    }
                } else o.insertAdjacentElement("afterbegin", t);
                return t.style.display = "block", !0
            }
            if ("aflairza.myshopify.com" === window.Shopify.shop) {
                return document.querySelector(".drawer__body").insertAdjacentElement("beforebegin", t), t.style.display = "block", !0
            }
            if ("woodentwist-ae.myshopify.com" === window.Shopify.shop || "woodentwist.myshopify.com" === window.Shopify.shop) {
                return document.getElementById("halo-cart-sidebar").querySelector(".halo-sidebar-header").insertAdjacentElement("afterend", t), t.style.display = "block", !0
            }
            if ("Tema Vision Nichada" === window.Shopify.theme.schema_name || "Tema Vision® - Nichado" === window.Shopify.theme.schema_name) {
                return document.querySelector("cart-drawer .drawer__header").insertAdjacentElement("afterbegin", t), t.style.display = "block", !0
            }
            if ("veganologie-shop.myshopify.com" === window.Shopify.shop) {
                return document.querySelectorAll("div.drawer__content")[0].insertAdjacentElement("afterbegin", t), t.style.display = "block", !0
            }
            if (s && s.className.includes("cart") && s.className.includes("popup")) {
                const e = s.parentElement;
                if (e) return e.insertAdjacentElement("afterbegin", t), t.style.display = "block", !0
            } else {
                const e = ["cart-drawer", "mini-cart", "side-cart", "quick-cart"],
                    o = `/?sections=${e.join(",")}`;
                fetch(o, {
                    method: "GET"
                }).then((e => (e.ok, e.json()))).then((o => {
                    let i = !1;
                    for (const n of e) {
                        const e = o[n];
                        if (e) {
                            const s = (new DOMParser).parseFromString(e, "text/html");
                            let r = s.querySelector(n) ? .innerHTML;
                            r || (r = s.querySelector(`#shopify-section-${n}`) ? .innerHTML || s.querySelector(`#${n}`) ? .innerHTML);
                            let l = document.querySelector(n);
                            if (l || (l = document.querySelector(`#shopify-section-${n}`) || document.querySelector(`#${n}`)), l) {
                                l.insertAdjacentElement("afterbegin", t), t.style.display = "block", i = !0;
                                break
                            }
                            if (window.ajaxCart && "function" == typeof window.ajaxCart.load) {
                                if (s.querySelector(`#shopify-section-${n}`)) {
                                    const e = s.querySelector(`#shopify-section-${n}`);
                                    e.insertAdjacentElement("afterbegin", t), o[n] = e.outerHTML
                                } else if (s.querySelector(`#${n}`)) {
                                    const e = s.querySelector(`#${n}`);
                                    e.insertAdjacentElement("afterbegin", t), o[n] = e.outerHTML
                                }
                                window.ajaxCart.load({
                                    sections: o
                                }, !1, !1), t.style.display = "block", i = !0;
                                break
                            }
                        }
                    }
                    return i
                })).then((e => !!e && (refreshCartDataDebounced(200, 3), renderingdelay = !0, !0))).catch((e => !1))
            }
        }
        return !1
    }
}

function updateCartQuantity(e, t, o) {
    let i = null,
        n = 0;
    "add" === e ? i = JSON.stringify({
        items: t
    }) : "update" === e ? i = JSON.stringify({
        updates: t
    }) : "note" === e ? (i = JSON.stringify({
        note: t
    }), e = "update", n = 1) : "change" === e && (i = JSON.stringify(t), n = 1);
    var s = window.Shopify.routes.root + `cart/${e}.js`;
    return "mg-naturals.myshopify.com" == window.Shopify.shop && (s = `/cart/${e}.js`), 0 === n && disableElements(), fetch(s, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: i
    }).then((o => o.ok ? o.json() : (0 === n && enableElements(), "add" === e && t.forEach(((e, t) => {
        sessionStorage.setItem(e.id, "error")
    })), o.text().then((e => {
        throw new Error(`HTTP ${o.status}: ${e}`)
    }))))).then((t => {
        0 === n && enableElements(), 0 === n && fetchAndUpdateMultipleSections(e, t, window.pageType, o), window.BMSMSectionRefresh = !1
    })).catch((o => {
        "add" === e && t.forEach(((e, t) => {
            sessionStorage.setItem(e.id, "error"), sessionStorage.setItem("reason", o)
        }))
    }))
}

function cartrefreshevents(e) {
    if (window.ajaxCart && "function" == typeof window.ajaxCart.load) {
        const e = `/?sections=${["cart-drawer","mini-cart","side-cart","quick-cart"].join(",")}`;
        return fetch(e, {
            method: "GET"
        }).then((e => (e.ok, e.json()))).then((e => {
            window.ajaxCart.load({
                sections: e
            }, !0, !1)
        })), !0
    }
    if (window.sharedFunctions && "function" == typeof window.sharedFunctions.updateSidebarCart) return fetch("/cart.js").then((e => e.json())).then((e => {
        window.sharedFunctions.updateSidebarCart(e)
    })), !0;
    if (window.Alpine && Alpine.store && Alpine.store("xMiniCart")) {
        const e = Alpine.store("xMiniCart");
        return e && "function" == typeof e.reLoad && e.reLoad(), !0
    }
    if ("function" == typeof window.refreshCartContents) return window.refreshCartContents(), !0;
    if (window.theme && theme.miniCart && "function" == typeof theme.miniCart.generateCart) return theme.miniCart.generateCart(), !0;
    if (window.MinimogSettings && MinimogSettings.routes ? .cart) {
        const e = () => [{
            id: "cart-drawer",
            selector: "[data-minimog-cart-items]",
            block: "cart-items"
        }, {
            id: "cart-drawer",
            selector: "[data-minimog-cart-discounts]",
            block: "cart-footer"
        }, {
            id: "cart-drawer",
            selector: "[data-cart-subtotal]",
            block: "cart-footer"
        }, {
            id: "cart-drawer",
            selector: "[data-minimog-gift-wrapping]",
            block: "cart-footer"
        }];
        return fetch(`${MinimogSettings.routes.cart}?section_id=cart-drawer`).then((e => e.text())).then((t => {
            e().forEach((e => {
                if ("cart-items" === e.block) {
                    const o = e.selector ? document.querySelector(e.selector) : document.getElementById(e.id),
                        i = (new DOMParser).parseFromString(t, "text/html").querySelector(e.selector) ? .innerHTML;
                    o && i && (o.innerHTML = i)
                }
            }))
        })).catch((e => {})), !0
    }
    if ("Umino" == window.Shopify.theme.schema_name && setTimeout((() => {
            document.querySelectorAll(".bls-loading-image img").forEach((e => {
                e.style.setProperty("content", "none", "important"), e.style.opacity = "1", e.style.visibility = "visible";
                const t = e.closest(".bls-loading-image");
                t && t.classList.remove("bls-loading-image")
            }))
        }), 2e3), "w2vjns-k2.myshopify.com" == window.Shopify.shop || "yvxd2k-1p.myshopify.com" == window.Shopify.shop) {
        var t = new theme.CartDrawer;
        t.init(), t.open()
    }
    return "the-catholic-woodworker.myshopify.com" != window.Shopify.shop && "l-arome-soy-candles.myshopify.com" !== window.Shopify.shop && "i0f8hn-sh.myshopify.com" !== window.Shopify.shop && "ambrosia-nutraceuticals.myshopify.com" !== window.Shopify.shop || "cart" !== e ? ("m7ukgu-0z.myshopify.com" == window.Shopify.shop && localStorage.setItem("open_cart_drawer", !0), "company-co-thirtysix.myshopify.com" == window.Shopify.shop && localStorage.setItem("open_cart_drawer", !0), "tots-bubbles.myshopify.com" == window.Shopify.shop && localStorage.setItem("open_cart_drawer", !0), "tots-bubbles.myshopify.com" == window.Shopify.shop || "company-co-thirtysix.myshopify.com" == window.Shopify.shop || "az-delivery.myshopify.com" == window.Shopify.shop || "m7ukgu-0z.myshopify.com" == window.Shopify.shop || "equidae-botanical-horse-care.myshopify.com" == window.Shopify.shop || "mg-naturals.myshopify.com" == window.Shopify.shop ? (window.location.reload(), !0) : window.theme && theme.ajaxCart && "function" == typeof theme.ajaxCart.update ? (theme.ajaxCart.update(), !0) : (document.dispatchEvent(new CustomEvent("on:cart:change", {
        bubbles: !0,
        cancelable: !1,
        detail: {
            source: "kaiprogressbar"
        }
    })), document.dispatchEvent(new CustomEvent("cart:refresh", {
        detail: {
            source: "kaiprogressbar"
        }
    })), document.dispatchEvent(new CustomEvent("cart:build", {
        detail: {
            source: "kaiprogressbar"
        }
    })), document.dispatchEvent(new CustomEvent("dispatch:cart-drawer:refresh", {
        bubbles: !0,
        detail: {
            source: "kaiprogressbar"
        }
    })), document.body.dispatchEvent(new CustomEvent("label:modalcart:afteradditem", {
        detail: {
            source: "kaiprogressbar"
        }
    })), document.dispatchEvent(new CustomEvent("cart:refresh", {
        bubbles: !0,
        detail: {
            open: !0,
            source: "kaiprogressbar"
        }
    })), document.body.dispatchEvent(new CustomEvent("baseline:modalcart:afteradditem", {
        detail: {
            source: "kaiprogressbar"
        }
    })), document.dispatchEvent(new CustomEvent("cart:kai-refresh-custom", {
        detail: {
            source: "custom.js"
        }
    })), document.documentElement.dispatchEvent(new CustomEvent("cart:refresh", {
        bubbles: !0
    })), !1)) : (window.location.reload(), !0)
}

function fetchAndUpdateMultipleSections(e, t, o, i) {
    if (!cartrefreshevents(o))
        if ("cart" === o) {
            const t = `/?sections=${["main-cart-items","main-cart","cart-template","main-cart-footer","cart-footer"].join(",")}`;
            fetch(t, {
                method: "GET"
            }).then((e => (e.ok, e.json()))).then((e => {
                ["main-cart-items", "main-cart", "cart-template"].forEach((t => {
                    const o = e[t];
                    if (o) {
                        const e = (new DOMParser).parseFromString(o, "text/html").querySelector(`[id^="shopify-section"][id$=${t}]`) ? .innerHTML;
                        let i = null;
                        i = "main-cart-items" === t ? document.querySelector('[id^="shopify-section"][id$="cart-items"]') : document.querySelector(`[id^="shopify-section"][id$=${t}]`), i && e && (i.innerHTML = e)
                    }
                }))
            })).then((() => {
                "update" === e && updateCartTotalWithCustomCalculation(), refreshCartDataDebounced(200, 2)
            })).catch((e => {}))
        } else {
            const e = `/?sections=${["cart-drawer","mini-cart","side-cart","quick-cart"].join(",")}`;
            fetch(e, {
                method: "GET"
            }).then((e => (e.ok, e.json()))).then((e => {
                ["cart-drawer", "mini-cart", "side-cart", "quick-cart"].forEach((t => {
                    const o = e[t];
                    if (o) {
                        const e = (new DOMParser).parseFromString(o, "text/html");
                        let i = e.querySelector(t) ? .innerHTML;
                        i || (i = e.querySelector(`#shopify-section-${t}`) ? .innerHTML || e.querySelector(`#${t}`) ? .innerHTML), "quick-cart" === t && (i = e.querySelector(".quick-cart__items") ? .innerHTML), "quick-cart" === t && (cartDrawerFooterContent = e.querySelector(".quick-cart__footer") ? .innerHTML);
                        let n = document.querySelector(t);
                        if (n || (n = document.querySelector(`#shopify-section-${t}`) || document.querySelector(`#${t}`)), "quick-cart" === t && (n = document.querySelector(".quick-cart__items")), "quick-cart" === t && (currentFooterSection = document.querySelector(".quick-cart__footer")), o && n) {
                            const e = n.querySelector(".quick-cart__wrapper") ? .classList.contains("active");
                            n.innerHTML = i;
                            const o = n.querySelector(".quick-cart__wrapper");
                            e && o && o.classList.add("active"), "quick-cart" === t && cartDrawerFooterContent && currentFooterSection && (currentFooterSection.innerHTML = cartDrawerFooterContent)
                        }
                    }
                }))
            })).then((() => {
                refreshCartDataDebounced(200, 2)
            })).catch((e => {}))
        }
}

function applyColor(e) {
    const {
        r: t,
        g: o,
        b: i,
        a: n
    } = e;
    return `rgba(${t}, ${o}, ${i}, ${void 0!==n?n:1})`
}
const isPageApplicable = e => {
        const t = window.pageType;
        switch (e || "All") {
            case "All":
                return !0;
            case "HomePage":
                return "index" === t;
            case "All Product Pages":
                return "product" === t;
            case "All Collection Pages":
                return "collection" === t;
            case "All except HomePage":
                return "index" !== t;
            default:
                return !1
        }
    },
    debounceMap = new Map;

function refreshCartDataDebounced(e, t) {
    if (debounceMap.has(t)) return;
    "adesiem-danielle-guizio-ny-dev.myshopify.com" != window.Shopify.shop && "danielle-guizio-ny.myshopify.com" != window.Shopify.shop || (e = 600);
    const o = setTimeout((() => {
        refreshCartData(t), debounceMap.delete(t)
    }), e);
    debounceMap.set(t, o)
}

function observeCartChanges() {
    new PerformanceObserver((e => {
        e.getEntries().forEach((e => {
            const t = ["xmlhttprequest", "fetch"].includes(e.initiatorType),
                o = /\/cart\//.test(e.name);
            t && o && refreshCartDataDebounced(200, 1)
        }))
    })).observe({
        entryTypes: ["resource"]
    })
}

function ensureCustomDivExists(e) {
    if ("cart" === window.pageType && "8e4f20.myshopify.com" !== window.Shopify.shop && "futterwolke.myshopify.com" !== window.Shopify.shop && "naqedcz.myshopify.com" !== window.Shopify.shop && "manupskin.myshopify.com" !== window.Shopify.shop && "uk6dhk-17.myshopify.com" !== window.Shopify.shop && "aarivayu.myshopify.com" !== window.Shopify.shop && "skalli-essentials.myshopify.com" !== window.Shopify.shop) {
        const e = document.getElementById("bmsm-cartDrawerBlock");
        if (e) {
            let t = document.querySelector("main");
            t || (t = document.querySelector('[role="main"]')), t && t.insertAdjacentElement("afterbegin", e), e.style.display = "block"
        }
        return
    }
    document.getElementById("CartDrawer");
    let t = !1;
    document.querySelector('form[action$="/cart"]:not([action^="/cart/add"]):not([id^="product"])');
    let o = document.querySelector("#bmsm-cartDrawerBlock");
    if (!o) {
        o = document.createElement("div"), o.id = "bmsm-cartDrawerBlock", o.classList.add("bmsm-cart-drawer-block"), o.style.display = "block";
        window.cartDrawerBlockBG && (o.style.backgroundColor = applyColor(window.cartDrawerBlockBG))
    }
    const i = window.cartDrawerBlock;
    return i && (o.innerHTML = i.trim()), t = insertCartBlock(window.bmsmcartlength, o), !window.kaieligible && Array.isArray(window.kaieligibleDiscountIds) && window.kaieligibleDiscountIds.forEach((e => {
        const t = o.querySelector(`.bmsm-tier-timeline[id="${e}"]`);
        t && (t.style.display = "none")
    })), "c50cff-0d.myshopify.com" === window.Shopify.shop && fetch("/cart.js").then((e => (e.ok, e.json()))).then((e => {
        0 === e.items.length && document.querySelectorAll(".bmsm-progress-indicator").forEach((e => {
            e.style.width = "0%"
        }))
    })), o.innerHTML && "" === o.innerHTML.trim() && t && refreshCartDataDebounced(200, 3), t
}

function disableElements() {
    ["quantity-popover-container", "t4s-mini_cart__actions", "input-amount"].forEach((e => {
        document.querySelectorAll(`.${e}`).forEach((e => {
            e.style.pointerEvents = "none", e.style.opacity = "0.5"
        }))
    }))
}

function enableElements() {
    ["quantity-popover-container", "t4s-mini_cart__actions", "input-amount"].forEach((e => {
        document.querySelectorAll(`.${e}`).forEach((e => {
            e.style.pointerEvents = "", e.style.opacity = ""
        }))
    }))
}

function isMobileDeviceKai() {
    return /Mobi|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
}

function updateCartTotalWithCustomCalculation() {
    const e = parseFloat(window.Shopify.currency.rate);
    fetch("/cart.js").then((e => (e.ok, e.json()))).then((t => {
        const o = t.total_price / 100 + t.items.reduce(((t, o) => t + parseFloat(o._YmqItemPrice || 0) * o.quantity * e), 0),
            i = document.querySelectorAll(".totals__total-value, .cart_total_price"),
            n = formatMoney1Shop(o, window.moneyFormat || "{{amount}}");
        i.forEach((e => {
            e.innerText = n
        }))
    })).catch((e => {}))
}

function formatMoney1Shop(e, t) {
    t = t.replace(/<\/?[^>]+(>|$)/g, "");
    const o = (Math.round(100 * e) / 100).toFixed(2),
        i = roundup(e);
    return t.replace("{{amount}}", o).replace("{{amount_no_decimals}}", i.toString()).replace("{{amount_with_comma_separator}}", o.replace(".", ",")).replace("{{amount_no_decimals_with_comma_separator}}", i.toString().replace(".", ",")).replace("{{amount_with_apostrophe_separator}}", o.replace(".", "'")).replace("{{amount_no_decimals_with_space_separator}}", i.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ")).replace("{{amount_with_space_separator}}", o.replace(/\B(?=(\d{3})+(?!\d))/g, " ")).replace("{{amount_with_period_and_space_separator}}", o.replace(/\B(?=(\d{3})+(?!\d))/g, " ").replace(",", "."))
}

function calculateAndShowEligibleGifts(e, t, o, i, n, s) {
    const r = window.bmsmshowGiftPopup ? ? !0;
    if (!["adesiem-danielle-guizio-ny-dev.myshopify.com", "danielle-guizio-ny.myshopify.com", "the-philosophers-stoneground-online-store.myshopify.com"].includes(window.Shopify.shop)) {
        const e = o[0].giftPopupDisplay;
        if ("both" !== e && "cartchange" === e && !r) return void(freegiftpopup = !1)
    }
    let l = o.filter((t => e >= parseFloat(t.minSpend) && "free_gift" === t.tierType && "define_free_gift" === t.gifttype && !0 !== t.nodisc && (Array.isArray(t.giftProductId) && t.giftProductId.length > 1 || Array.isArray(t.giftProductId) && 1 === t.giftProductId.length && Array.isArray(t.giftProductId[0] ? .variants) && t.giftProductId[0].variants.length > 1)));
    if (s && l.length > 0) {
        const t = o.slice().reverse().find((t => e >= parseFloat(t.minSpend) && ("free_gift" === t.tierType || "bogo" === t.tierType)));
        l = t && "define_free_gift" === t.gifttype && (Array.isArray(t.giftProductId) && t.giftProductId.length > 1 || Array.isArray(t.giftProductId) && 1 === t.giftProductId.length && Array.isArray(t.giftProductId[0] ? .variants) && t.giftProductId[0].variants.length > 1) ? l.filter((e => e.minSpend === t.minSpend)) : []
    }
    if (l && l.length > 0) {
        var a = findEligibleGifts(t, l, n, i);
        if ("b6f6ed-34.myshopify.com" == window.Shopify.shop) {
            const e = new Set(t.items.map((e => String(e.variant_id))));
            a = a.filter((t => {
                const o = t.variant_id.split("/").pop();
                return !e.has(o)
            }))
        }
        return a.length > 0 ? (freegiftpopup = !0, setTimeout((() => {
            if ("qg0msp-jt.myshopify.com" == window.Shopify.shop) "19" == final_cart_total_upsell || "40" == final_cart_total_upsell || "80" == final_cart_total_upsell || "150" == final_cart_total_upsell || showGiftPopup(JSON.stringify(a));
            else {
                var e = o[0].giftPopupOption ? ? "popup";
                "wkn7z2-1x.myshopify.com" == window.Shopify.shop && (e = "carousel"), "carousel" == e ? showGiftCarousel(JSON.stringify(a)) : (destroyGiftCarousels(), showGiftPopup(JSON.stringify(a)))
            }
        }), 50)) : (freegiftpopup = !1, destroyGiftCarousels()), a
    }
    freegiftpopup = !1, destroyGiftCarousels()
}

function findEligibleGifts(e, t, o, i) {
    let n = [];
    return t.forEach((t => {
        let s = [];
        (Array.isArray(t.giftProductId) && t.giftProductId.length > 1 || Array.isArray(t.giftProductId) && 1 === t.giftProductId.length && Array.isArray(t.giftProductId[0] ? .variants) && t.giftProductId[0].variants.length > 1) && (s = t.giftProductId), s.forEach((s => {
            Array.isArray(s.variants) && s.variants.forEach((r => {
                let l = o.find((e => e.variant_id === r.id && !0 === e.available && (e.stock_quantity > 0 || "null" === e.inventory_management) && e.tier_id === t.tierId.toString() && e.discount_id === i.toString()));
                if ("the-philosophers-stoneground-online-store.myshopify.com" === window.Shopify.shop && (l = o.find((e => e.variant_id === r.id && !0 === e.available && e.tier_id === t.tierId.toString() && e.discount_id === i.toString()))), "the-philosophers-stoneground-online-store.myshopify.com" === window.Shopify.shop && l && (l.stock_quantity = 100), "thetotelibrary.myshopify.com" === window.Shopify.shop && "55647590416761" === r.id.replace("gid://shopify/ProductVariant/", "") && l && (l.stock_quantity = 100, l.inventory_management = "null"), "foundation-gift.myshopify.com" !== window.Shopify.shop && "ckc-trade.myshopify.com" !== window.Shopify.shop && "ckc-consumer.myshopify.com" !== window.Shopify.shop || (l = o.find((e => e.variant_id === r.id && !0 === e.available && e.tier_id === t.tierId.toString())), l && (l.stock_quantity = 100)), l) {
                    const o = e.items.reduce(((e, t) => t.id.toString() === r.id.replace("gid://shopify/ProductVariant/", "") ? e + t.quantity : e), 0);
                    (l.stock_quantity - o > 0 || "null" === l.inventory_management) && n.push({
                        product_id: s.id,
                        product_name: s.title,
                        variant_id: r.id,
                        variant_name: r.title,
                        giftpopup: t.giftpopup,
                        claimtext: t.claimtext,
                        price: l.price,
                        compare_at_price: l.compare_at_price,
                        featured_image: l.featured_image || "",
                        variant_featured_image: l.variant_featured_image || l.featured_image,
                        tier_minSpend: t.minSpend,
                        tier_id: t.tierId,
                        noofgifts: t.noofgifts,
                        discount_id: i,
                        inventory_management: l.inventory_management
                    })
                }
            }))
        }))
    })), n = n.filter((t => {
        const o = e.items.some((e => {
            const o = e.properties._discountid || null,
                i = e.properties._tier_minSpend || null,
                n = e.properties._added_by || null;
            return o === t.discount_id && i === t.tier_minSpend.toString() && "bmsm_pb" === n
        }));
        return !o
    })), n
}

function observeCustomDivRemoval() {
    const e = "bmsm-cartDrawerBlock",
        t = "bmsm-cart-drawer-block",
        o = new MutationObserver((i => {
            for (const n of i)
                for (const i of n.removedNodes) {
                    if (1 !== i.nodeType) continue;
                    let n = i.id === e && i.classList.contains(t);
                    "607a51.myshopify.com" !== window.Shopify.shop && "4ccbd0.myshopify.com" !== window.Shopify.shop || (n = i.classList.contains("t4s-minicart-recommendations__item")), "mellow-cosmetics.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("lb-variant-picker-cont") || i.classList.contains("ajax-cart__cart-form")), "c2d5db-7b.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("product-upsell__holder")), "tms-the-mom-store.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("side-panel-inner")), "t6tawi-kk.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("spinner-border") || i.classList.contains("ajaxcart__price")), "solit-socks-prod.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("swiper-slide")), "algebra-and-beyond.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("drawer__inner")), "danielle-guizio-ny.myshopify.com" === window.Shopify.shop && (n = i.classList.contains("side-panel-inner")), window.Shopify.shop, "the-dragontree-apothecary.myshopify.com" == window.Shopify.shop && (n = i.classList.contains("yv_load")), "my-qamis-homme.myshopify.com" != window.Shopify.shop && "2x4scx-is.myshopify.com" != window.Shopify.shop || (n = i.classList.contains("instafeed-modals-wrapper")), "iymt0v-hw.myshopify.com" == window.Shopify.shop && (n = i.classList.contains("price__suffix")), "smaltosw.myshopify.com" == window.Shopify.shop && (n = i.classList.contains("mini-cart") || i.classList.contains("mini-cart__navigation")), "d0k24w-bw.myshopify.com" == window.Shopify.shop && (n = i.classList.contains("product__popdown__outer"));
                    const s = i instanceof Element && i.querySelector ? .(`#${e}.${t}`);
                    if (n || s) {
                        o.disconnect(), ensureCustomDivExists(1);
                        let e = 200;
                        return isMobileDeviceKai() && "jt8v6e-qs.myshopify.com" === window.Shopify.shop && (e = 100), "c50cff-0d.myshopify.com" === window.Shopify.shop && (e = 100), "algebra-and-beyond.myshopify.com" === window.Shopify.shop && (e = 50), void setTimeout((() => {
                            o.observe(document.body, {
                                childList: !0,
                                subtree: !0
                            })
                        }), e)
                    }
                }
        }));
    o.observe(document.body, {
        childList: !0,
        subtree: !0
    })
}

function updateTierMinSpend(e, t, o) {
    if (!Array.isArray(e)) return;
    const i = e.find((e => e.discountId == t));
    if (!i) return;
    const n = i ? .tiers;
    Array.isArray(n) && (n[0].minSpend == String(Number(n[0].minSpend) * Number(o)) || (n[0].minSpend = String(Number(n[0].minSpend) * Number(o))))
}

function loadSplide() {
    return new Promise(((e, t) => {
        if ("undefined" != typeof Splide) return void e();
        const o = document.querySelector("script[data-bmsm-splide]"),
            i = document.querySelector("link[data-bmsm-splide]");
        document.querySelector("style[data-bmsm-splide-inline]");
        let n = 0;

        function s() {
            n -= 1, 0 === n && e()
        }
        if (!i) {
            n += 1;
            const e = document.createElement("link");
            e.rel = "stylesheet", e.href = "https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css", e.setAttribute("data-bmsm-splide", ""), e.onload = s, e.onerror = () => t(new Error("Failed to load Splide CSS")), document.head.appendChild(e)
        }
        if (!o) {
            n += 1;
            const e = document.createElement("script");
            e.src = "https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js", e.async = !0, e.defer = !0, e.setAttribute("data-bmsm-splide", ""), e.onload = s, e.onerror = () => t(new Error("Failed to load Splide JS")), document.head.appendChild(e)
        }
        0 === n && e()
    }))
}

function replaceUpcomingTierText(e, t, o, i, n, s, r = 0, l = 1) {
    let a;
    const c = Number(i) + Number(r),
        p = Number(n) + Number(l);
    if ("bogo" === s || "quantity" === s) {
        const e = o.filter((e => parseInt(e.minSpend) > n && parseInt(e.minSpend) <= p));
        a = e.length > 0 ? e[e.length - 1] : null
    } else {
        const e = o.filter((e => parseFloat(e.minSpend) > i && parseFloat(e.minSpend) <= c));
        a = e.length > 0 ? e[e.length - 1] : null
    }
    if (a || (a = "bogo" === s || "quantity" === s ? o.find((e => parseInt(e.minSpend) > n)) : o.find((e => parseFloat(e.minSpend) > i))), !a) return t;
    let d = "";
    switch (a.tierType) {
        case "percentage":
            {
                const e = parseFloat(a.value);d = a.discountLabel ? a.discountLabel.replace("{Value}", e + "%") : `${e}% Off`;
                break
            }
        case "fixed":
            {
                const e = formatMoney1Shop(parseFloat(a.value), window.moneyFormat || "{{amount}}");d = a.discountLabel ? a.discountLabel.replace("{Value}", e) : `${e} Off`;
                break
            }
        case "free_gift":
            d = a.freegiftname || "Free Gift";
            break;
        case "free_shipping":
            d = a.freeshippingname || "Free Shipping";
            break;
        default:
            d = "Reward"
    }
    return e.replace("{upcomingTier}", d)
}

function renderUpsellCarousel(e, t, o) {
    if (!e || !e.placementStyles.upsell || !o) return;
    const i = e.placementStyles.upsell,
        n = (i.recommendationType || "").toLowerCase(),
        s = (() => {
            switch (n) {
                case "selectedproducts":
                    return {
                        upsell_type: "selected_product",
                        selection: i.selectedProducts || []
                    };
                case "selectedcollections":
                    return {
                        upsell_type: "selected_collections",
                        selection: i.selectedCollections || []
                    };
                case "autorecommend":
                    return {
                        upsell_type: "ai",
                        selection: []
                    };
                case "none":
                    return {
                        upsell_type: "none",
                        selection: []
                    };
                default:
                    return {
                        upsell_type: "none",
                        selection: []
                    }
            }
        })();
    s && "none" !== s.upsell_type ? (o.style.display = "block", o.dataset.rendering = "true", showUpsellLoading(o), fetchUpsellProducts(s, t).then((t => {
        if (hideUpsellLoading(o), t && t.length > 0) {
            let a = o.querySelector(".bmsm-upsell-products");
            const c = o.querySelector(".bmsm-upsell-prev"),
                p = o.querySelector(".bmsm-upsell-next");
            if (c || p) {
                const t = e.placementStyle.upsell ? .upsellIconColor ? `rgba(${e.placementStyle.upsell.upsellIconColor.r}, ${e.placementStyle.upsell.upsellIconColor.g}, ${e.placementStyle.upsell.upsellIconColor.b}, ${e.placementStyle.upsell.upsellIconColor.a})` : "#6a5acd";
                c && (c.style.color = t), p && (p.style.color = t)
            }
            if (!a) {
                const t = o.id || "",
                    i = `\n          <div class="splide bmsm-upsell-splide" id="${t?t.replace("bmsm-upsellCarousel","bmsm-upsellSplide"):`bmsm-upsellSplide-${e.discountId}-${Date.now()}`}" aria-label="Upsell products">\n            <div class="splide__track">\n              <ul class="splide__list bmsm-upsell-products"></ul>\n            </div>\n          </div>`;
                o.innerHTML = i, a = o.querySelector(".bmsm-upsell-products")
            }
            var i = e.tiers[0].upsellSelectedLanguages,
                n = e.placementStyles.upsell.upsellButtonText,
                s = e.placementStyles.upsell.upsellFinishButtonText;
            if (e.tiers[0].enableTranslations) {
                var r = window.Shopify && Shopify.locale ? Shopify.locale : "en";
                (l = i.find((e => e.locale === r))) && l.addToCartText && (n = l.addToCartText)
            }
            if (e.tiers[0].enableTranslations) {
                var l;
                r = window.Shopify && Shopify.locale ? Shopify.locale : "en";
                (l = i.find((e => e.locale === r))) && l.addToCartFinishText && (s = l.addToCartFinishText)
            }
            if (a.innerHTML = t.map((t => `<li class="splide__slide">${createUpsellProductCard(t,e,n,s)}</li>`)).join(""), !a.children || 0 === a.children.length) return o.style.display = "none", void(o.dataset.rendering = "false");
            initUpsellCardInteractions(o, e), setupUpsellCarousel(o), o.dataset.rendered = "true", o.dataset.rendering = "false"
        } else o.style.display = "none", o.dataset.rendering = "false"
    })).catch((e => {
        hideUpsellLoading(o), o.style.display = "none", o.dataset.rendering = "false"
    }))) : o.style.display = "none"
}

function showUpsellLoading(e) {
    if (e.querySelector(".bmsm-upsell-loading")) return;
    const t = document.createElement("div");
    t.className = "bmsm-upsell-loading", t.id = "bmsm-upsellLoading", t.style.position = "relative", t.innerHTML = '<div class="bmsm-loading-spinner"></div>', e.appendChild(t)
}

function hideUpsellLoading(e) {
    const t = e.querySelector(".bmsm-upsell-loading");
    t && t.remove()
}

function initializeUpsellsFromActiveMetaobjects(e = !1) {
    Array.isArray(window.activeMetaobjects) && 0 !== window.activeMetaobjects.length && ("the-catholic-woodworker.myshopify.com" != window.Shopify.shop || window.location.pathname.includes("/cart")) && ("az-delivery.myshopify.com" != window.Shopify.shop || window.location.pathname.includes("/cart")) && "d06409-1b.myshopify.com" != window.Shopify.shop && window.activeMetaobjects.forEach((t => {
        try {
            const o = t.discountId;
            if (!o || !t.placementStyles.upsell) return;
            let i = "";
            if (t.placementStyles.upsell.productPageEnabled && t.placementStyles.upsell.cartPageEnabled) i = `.bmsm-tier-timeline[id="${o}"]`;
            else if (t.placementStyles.upsell.productPageEnabled) i = `.bmsm-product-page-block .bmsm-tier-timeline[id="${o}"]`;
            else {
                if (!t.placementStyles.upsell.cartPageEnabled) return;
                i = `.bmsm-cart-drawer-block .bmsm-tier-timeline[id="${o}"]`
            }
            "w2vjns-k2.myshopify.com" != window.Shopify.shop && "yvxd2k-1p.myshopify.com" != window.Shopify.shop || (i = ".drawer__footer"), "smaltosw.myshopify.com" == window.Shopify.shop && (i = "cart-items");
            const n = document.querySelectorAll(i);
            if (!n || 0 === n.length) return;
            n.forEach(((i, n) => {
                const s = `bmsm-upsellCarousel-${o}-${n}`,
                    r = i.closest(".bmsm-cart-drawer-block, .bmsm-product-page-block") || i;
                let l = document.getElementById(s) || r.querySelector(`#${s}`) || i.querySelector(`#${s}`);
                !l && r.nextElementSibling && r.nextElementSibling.id === s && (l = r.nextElementSibling), l || (l = document.createElement("div"), l.id = s, l.className = "bmsm-upsell-carousel", "w2vjns-k2.myshopify.com" == window.Shopify.shop || "yvxd2k-1p.myshopify.com" == window.Shopify.shop ? r.prepend(l) : "smaltosw.myshopify.com" == window.Shopify.shop ? r.children[0] ? .after(l) : r.insertAdjacentElement("afterend", l), renderUpsellCarousel(t, 100, l)), e && renderUpsellCarousel(t, 100, l)
            }))
        } catch (e) {}
    }))
}
async function fetchUpsellProducts(e, t) {
    const {
        upsell_type: o,
        selection: i
    } = e;
    try {
        let e = [];
        switch (o) {
            case "selected_product":
                i && i.length > 0 && (e = await fetchProductsByHandles(i));
                break;
            case "selected_collections":
                i && i.length > 0 && (e = await fetchProductsByCollections(i));
                break;
            case "ai":
                e = await fetchAIRecommendations(t);
                break;
            default:
                return []
        }
        return e.filter((e => e && e.id))
    } catch (e) {
        return []
    }
}
async function fetchProductsByHandles(e) {
    const t = [];
    for (const o of e) try {
        const e = await fetch(`/products/${o}.js`);
        if (e.ok) {
            const o = await e.json();
            o && o.id && t.push(o)
        }
    } catch (e) {}
    return t
}
async function fetchProductsByCollections(e) {
    const t = [];
    for (const o of e) try {
        const e = await fetch(`/collections/${o}/products.json`);
        if (e.ok) {
            const o = await e.json();
            o.products && Array.isArray(o.products) && t.push(...o.products.slice(0, 10))
        }
    } catch (e) {}
    return t
}
async function fetchAIRecommendations(e) {
    try {
        let e = window.productId || window.product ? .id || "";
        if (!e) try {
            const t = await fetch("/cart.js");
            if (t.ok) {
                const o = await t.json();
                o && Array.isArray(o.items) && o.items.length > 0 && (e = o.items[0].product_id)
            }
        } catch (e) {}
        if (!e) return [];
        const t = await fetch(`/recommendations/products.json?product_id=${e}&limit=8`);
        if (t.ok) {
            return (await t.json()).products || []
        }
    } catch (e) {}
    return []
}

function createUpsellProductCard(e, t, o, i) {
    let n = "";
    e.featured_image ? n = e.featured_image : e.images && e.images.length > 0 && (n = "string" == typeof e.images[0] ? e.images[0] : e.images[0].src);
    const s = e.variants || [],
        r = s.length > 1,
        l = s.length > 0 ? s[0] : null;
    var a = l ? (l.price / 100).toFixed(2) : "0.00",
        c = l && l.compare_at_price ? (l.compare_at_price / 100).toFixed(2) : null;
    "yvxd2k-1p.myshopify.com" != window.Shopify.shop && "sz0efx-qg.myshopify.com" != window.Shopify.shop && "the-catholic-woodworker.myshopify.co" != window.Shopify.shop && "w2vjns-k2.myshopify.com" != window.Shopify.shop && "kreative-cutters.myshopify.com" != window.Shopify.shop || (a = l.price, c = l.compare_at_price);
    let p = "";
    if (r) {
        const t = s.filter((e => e.available)).map((e => {
            let t = "";
            e.option1 ? (t = e.option1, e.option2 && (t += ` / ${e.option2}`), e.option3 && (t += ` / ${e.option3}`)) : t = e.title && "Default Title" !== e.title ? e.title : `Variant ${e.id}`;
            const o = (e.price / 100).toFixed(2);
            return `<option value="${e.id}" data-price="${o}" data-compare-price="${e.compare_at_price||""}">${t}</option>`
        })).join("");
        t && (p = `\n        <select class="bmsm-upsell-variant-select" data-product-id="${e.id}">\n          ${t}\n        </select>\n      `)
    }
    o = replaceUpcomingTierText(o, i, t.tiers, final_cart_total_upsell.toFixed(2), final_cart_quantity_upsell, t.discountType, a, 1);
    window.moneyFormat;
    var d = formatMoney1(a, 0),
        m = formatMoney1(c, 0);
    "chhapa.myshopify.com" != window.Shopify.shop && "8e4f20.myshopify.com" != window.Shopify.shop || (d = a, m = "");
    const y = t.placementStyles.upsell ? .upsellBackgroundColor ? `background-color: ${applyColor(t.placementStyles.upsell.upsellBackgroundColor)};` : "",
        u = t.placementStyles.upsell ? .upsellProductTitleColor ? `color: ${applyColor(t.placementStyles.upsell.upsellProductTitleColor)};` : "",
        f = t.placementStyles.upsell ? .upsellProductPriceColor ? `color: ${applyColor(t.placementStyles.upsell.upsellProductPriceColor)};` : "",
        h = t.placementStyles.upsell ? .upsellCompareColor ? `color: ${applyColor(t.placementStyles.upsell.upsellCompareColor)};` : "";
    return `\n  \n    <div class="bmsm-upsell-product-card" data-product-id="${e.id}" style="${y}">\n   \n      <div class="bmsm-upsell-product-image">\n        <img src="${n}" alt="${e.title}" loading="lazy" onerror="this.style.display='none'">\n      </div>\n      <div class="bmsm-upsell-product-info">\n        <h4 class="bmsm-upsell-product-title" title="${e.title}" style="${u}">\n          <a href="${e.handle?"/products/"+e.handle:"#"}" target="_blank" rel="noopener" style="color: inherit !important; cursor: pointer; text-decoration: none;">${e.title}</a>\n        </h4>\n        <div class="bmsm-upsell-product-price" style="${f}">\n          ${c?`<span class="bmsm-upsell-compare-price" style="${h}">${m}</span>`:""}\n          <span class="bmsm-upsell-current-price" style="${f}">${d}</span>\n        </div>\n        <div class="bmsm-upsell-variant-cart-row">\n          ${p}\n                <button \n              class="bmsm-upsell-add-to-cart" \n              data-product-id="${e.id}" \n              data-selected-variant-id="${l?l.id:""}"\n              style="background-color: rgba(${t.placementStyles.upsell.upsellButtonColor.r}, ${t.placementStyles.upsell.upsellButtonColor.g}, ${t.placementStyles.upsell.upsellButtonColor.b}, ${t.placementStyles.upsell.upsellButtonColor.a}); \n                    color: rgba(${t.placementStyles.upsell.buttonTextColor.r}, ${t.placementStyles.upsell.buttonTextColor.g}, ${t.placementStyles.upsell.buttonTextColor.b}, ${t.placementStyles.upsell.buttonTextColor.a});"\n            >\n              <span class="label">${o}</span>\n              <span class="spinner" aria-hidden="true"></span>\n            </button>\n        </div>\n      </div>\n    </div>\n  `
}

function initUpsellCardInteractions(e, t) {
    if (!e) return;
    const o = e.querySelector(".bmsm-upsell-products") || e;
    "true" !== o.dataset.bmsmUpsellBound && (o.dataset.bmsmUpsellBound = "true", o.addEventListener("change", (e => {
        const o = e.target.closest(".bmsm-upsell-variant-select");
        if (!o) return;
        const i = e.target.closest(".bmsm-upsell-product-card");
        if (!i) return;
        const n = o.options[o.selectedIndex],
            s = n.value,
            r = n.getAttribute("data-price"),
            l = n.getAttribute("data-compare-price"),
            a = t.placementStyles.upsell ? .upsellProductPriceColor ? `color: ${applyColor(t.placementStyles.upsell.upsellProductPriceColor)};` : "",
            c = t.placementStyles.upsell ? .upsellCompareColor ? `color: ${applyColor(t.placementStyless.upsell.upsellCompareColor)};` : "",
            p = i.querySelector(".bmsm-upsell-product-price"),
            d = (window.moneyFormat, formatMoney1(r, 0)),
            m = formatMoney1(l, 0),
            y = l && "" !== l ? `<span class="bmsm-upsell-compare-price" style="${c}">${(m/100).toFixed(2)}</span>` : "";
        p.innerHTML = `${y}<span class="bmsm-upsell-current-price" style="${a}">${d}</span>`;
        const u = i.querySelector(".bmsm-upsell-add-to-cart");
        u && u.setAttribute("data-selected-variant-id", s)
    })), o.addEventListener("click", (e => {
        const t = e.target.closest(".bmsm-upsell-add-to-cart");
        if (!t) return;
        const o = t.closest(".bmsm-upsell-product-card");
        if (!o) return;
        const i = t.getAttribute("data-product-id"),
            n = (t.getAttribute("data-selected-variant-id"), o.querySelector(".bmsm-upsell-product-title"));
        addUpsellProductToCart({
            id: i,
            title: n ? n.textContent : "Product",
            handle: void 0
        }, o)
    })))
}

function addUpsellProductToCart(e, t) {
    const o = t.querySelector(".bmsm-upsell-add-to-cart"),
        i = o.getAttribute("data-selected-variant-id");
    if (!i) return void showUpsellErrorMessage();
    o.disabled = !0, o.classList.add("loading");
    const n = {
        id: "string" == typeof i ? i.replace("gid://shopify/ProductVariant/", "") : i,
        quantity: 1,
        properties: {
            _added_by: "bmsm_upsell",
            _upsell_product: e.handle || e.id
        }
    };
    fetch("/cart/add.js", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            items: [n]
        })
    }).then((e => {
        if (!e.ok) throw new Error(`HTTP error! status: ${e.status}`);
        return e.json()
    })).then((e => {
        fetchAndUpdateMultipleSections("add", e, window.pageType), o.disabled = !1, o.classList.remove("loading");
        o.querySelector(".label")
    })).catch((e => {
        o.disabled = !1, o.classList.remove("loading");
        o.querySelector(".label")
    }))
}

function getOptionsForContainer(e) {
    const t = e.offsetWidth;
    let o = 2;
    t < 640 ? o = 1 : (t < 900 || t < 1280) && (o = 2), "az-delivery.myshopify.com" == window.Shopify.shop && t > 1e3 && (o = 3), "confetti-gifts-co.myshopify.com" == window.Shopify.shop && t > 1e3 && (o = 3), "the-catholic-woodworker.myshopify.com" == window.Shopify.shop && (o = 1);
    var i = 15,
        n = 30;
    return "chhapa.myshopify.com" == window.Shopify.shop && (i = 0), t < 800 && "confetti-gifts-co.myshopify.com" == window.Shopify.shop && (i = {
        right: "40%"
    }, n = 0), {
        type: "loop",
        gap: n,
        padding: i,
        pagination: !1,
        perPage: o
    }
}

function setupUpsellCarousel(e) {
    const t = e.querySelector(".bmsm-upsell-splide");
    if (!t) return;
    if (t._bmsmSplide) return;
    if (t.style.width = "100%", e.style.display = "block", e.style.visibility = "visible", e.offsetWidth > 800) e.style.padding = "0 10%", "az-delivery.myshopify.com" == window.Shopify.shop && (e.style.padding = "0 15%");
    else if (e) {
        const t = e.querySelectorAll(".bmsm-upsell-add-to-cart"),
            i = e.offsetWidth;
        var o = .425 * i;
        screen.width < 700 && (o = .32 * i), t.forEach((e => {
            e.style.maxWidth = `${o}px`
        }))
    }
    const i = () => {
        if (!t._bmsmSplide) try {
            const o = new Splide(t, getOptionsForContainer(e));
            t._bmsmSplide = o, o.mount()
        } catch (e) {}
    };
    "undefined" == typeof Splide ? loadSplide().then(i).catch((e => {})) : i()
}

function setupobserver_ambrosia() {
    const e = document.getElementById("pgbar_response");
    if (e) {
        let t = e.innerHTML.trim();
        new MutationObserver((() => {
            const o = e.innerHTML.trim();
            o !== t && (t = o, amrosia_custom_quantity = t, refreshCartData(0))
        })).observe(e, {
            childList: !0,
            subtree: !0
        })
    }
}
document.addEventListener("DOMContentLoaded", (async function() {
    if (window.activeMetaobjects && window.activeMetaobjects.length > 0) {
        if (observeCartChanges(), "doukissa-nomikou.myshopify.com" !== window.Shopify.shop || !window.location.href.startsWith("https://www.doukissanomikou.com/apps/bundles/bundle/")) {
            window.activeMetaobjects.some((e => !0 === e.placementStyles ? .cartDrawerBlock ? .enable)) && observeCustomDivRemoval()
        }
        var e = 1100;
        if ("the-catholic-woodworker.myshopify.com" == window.Shopify.shop && (e = 2700), "b6f6ed-34.myshopify.com" == window.Shopify.shop && (e = 3e3), "2b2641-3.myshopify.com" != window.Shopify.shop && setTimeout((() => {
                initializeUpsellsFromActiveMetaobjects()
            }), e), "m7ukgu-0z.myshopify.com" == window.Shopify.shop) {
            if ("true" === localStorage.getItem("open_cart_drawer")) {
                localStorage.setItem("open_cart_drawer", !1);
                const e = document.querySelector("#cart-icon-bubble");
                e && e.click()
            }
        }
        if ("company-co-thirtysix.myshopify.com" == window.Shopify.shop) {
            if ("true" === localStorage.getItem("open_cart_drawer")) {
                localStorage.setItem("open_cart_drawer", !1);
                const e = document.querySelector(".cart-drawer-button");
                e && e.click()
            }
        }
        const t = document.querySelector(".js-minicart-link");
        if ("tots-bubbles.myshopify.com" === window.Shopify.shop) {
            "true" === localStorage.getItem("open_cart_drawer") && (localStorage.setItem("open_cart_drawer", "false"), window.location.href.includes("/cart") || t && t.click())
        }
        if ("equidae-botanical-horse-care.myshopify.com" == window.Shopify.shop || "mg-naturals.myshopify.com" == window.Shopify.shop) try {
            if ("/cart" !== window.location.pathname) {
                const e = $("[data-cart-quantity-input]").first();
                e.val(e.val()), e.trigger("change")
            } else {
                const e = await fetch("/?sections=cart-template"),
                    t = await e.json(),
                    o = (new DOMParser).parseFromString(t["cart-template"], "text/html").querySelector(".container.main.content") ? .innerHTML,
                    i = document.querySelector(".container.main.content");
                o && i && (i.innerHTML = o)
            }
            return (() => {
                window.tlCartGoalEmbed ? (window.tlCartGoalEmbed.renderAllCartGoals ? .(), "undefined" != typeof needInitialize && needInitialize && window.tlCartGoalEmbed.initializeLocalStorage ? .()) : setTimeout((() => {
                    window.tlCartGoalEmbed && (window.tlCartGoalEmbed.renderAllCartGoals ? .(), "undefined" != typeof needInitialize && needInitialize && window.tlCartGoalEmbed.initializeLocalStorage ? .())
                }), 200)
            })(), document.addEventListener("shopify:section:load", (() => {
                window.tlCartGoalEmbed ? .renderAllCartGoals ? .()
            })), void document.addEventListener("page:load", (() => {
                window.tlCartGoalEmbed ? .renderAllCartGoals ? .()
            }))
        } catch (e) {}
        refreshCartData(0), "ambrosia-nutraceuticals.myshopify.com" == window.Shopify.shop && setupobserver_ambrosia()
    }
}));